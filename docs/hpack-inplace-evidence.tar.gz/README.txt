Portable HPACK evidence. Original evidence bytes and absolute-path provenance are preserved.
Use docs/hpack-inplace-tools/verify.py against this archive for the portable raw-data audit.
Full original analysis-audit.py verifies external frozen inventory, git identity and binary classes;
it requires the original binaries/paths (jars, classes, Maven dependencies), deliberately excluded here.
freeze.json and source-proof/audit.json retain their hashes. OMITTED-BINARIES.json records local omissions.
Commands are in schedule.json and ledger.jsonl; readiness/build/test logs retain provenance and failures.
No new performance measurements or test executions were performed for packaging.
Archive: sorted names, uid/gid 0, empty owner names, mtime 0, gzip mtime 0, no original gzip filename.
