"""Bounded functional readiness, exclusive append-only logs. Never runs JMH timings."""
import hashlib,json,re,subprocess
from pathlib import Path
import campaign as c
R=Path(__file__).resolve().parent
m=c.config(); out=R/'runtime-proof';out.mkdir(exist_ok=True)
commands=[];rows=[]
def run(name,args):
 p=out/(name+'.log')
 with p.open('x') as f: result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 commands.append(dict(argv=args,returncode=result.returncode,log=str(p),sha256=c.digest(p)))
 c.write_json(out/'commands.json',commands)
 c.require(result.returncode==0,'Failure preserved: '+str(p))
 return p.read_text()
classes=out/'classes';classes.mkdir(exist_ok=True)
run('compile',[str(Path(m['java']).with_name('javac')),'-cp',m['stages']['inplace']['jar'],'-d',str(classes),str(R/'RuntimeReadinessProbe.java'),str(R/'RuntimeProof.java')])
for v in c.VERSIONS:
 jar=m['stages'][v]['jar'];cp=str(classes)+':'+jar
 run(v+'-runtime',[m['java'],'-cp',cp,'io.netty.handler.codec.http2.RuntimeProof',v])
 if v!='upstream':run(v+'-retention',[m['java'],'-cp',cp,'io.netty.handler.codec.http2.RuntimeReadinessProbe','retention'])
 for size in ([4096] if v=='upstream' else [4096,65536]):
  for workload in ['NORMAL','AUTHENTICATED']:
   for policy in ['NEVER','INDEX_COOKIES']:
    text=run(f'{v}-{size}-{workload}-{policy}',[m['java'],'-cp',jar,'io.netty.handler.codec.http2.HpackBrowserBenchmark',workload,policy,'true',str(size),'--manifest'])
    for mode,method in [('persistent','persistentSession'),('new','newConnectionSession')]:
     blocks=re.findall(r'^wire '+mode+r' .* bytes=(\d+) .* hex=([0-9a-f]+)$',text,re.M)
     h=hashlib.sha256();total=0
     for n,hexdata in blocks:
      data=bytes.fromhex(hexdata);assert len(data)==int(n);total+=len(data);h.update(len(data).to_bytes(4,'big'));h.update(data)
     summary=re.search(r'^summary '+mode+r' blocks=(\d+) bytes=(\d+) .* lengthDelimitedWireSha256=([0-9a-f]+)$',text,re.M)
     assert summary and int(summary[1])==len(blocks) and int(summary[2])==total and summary[3]==h.hexdigest()
     rows.append(dict(version=v,cell='browser-'+method+'-'+workload+'-'+policy,size=size,requested_size=size,actual_size=size,wire_bytes=total,wire_sha256=h.hexdigest()))
  if size==4096:
   for scenario in c.SYNTH:
    text=run(f'{v}-{size}-{scenario}',[m['java'],'-cp',cp,'io.netty.handler.codec.http2.RuntimeReadinessProbe','synthetic',str(size),scenario])
    match=re.search(r'SUMMARY (\d+) ([0-9a-f]{64}) 2048 (\d+)',text);assert match and int(match[3])==size
    rows.append(dict(version=v,cell='synthetic-'+scenario,size=size,requested_size=size,actual_size=int(match[3]),wire_bytes=int(match[1]),wire_sha256=match[2]))
c.write_json(out/'wire-rows.json',rows)
for size in [4096,65536]:
 cells={x['cell'] for x in rows if x['size']==size}
 for cell in cells:
  selected=[x for x in rows if x['size']==size and x['cell']==cell]
  assert len(selected)==(3 if size==4096 else 2)
  assert len({(x['wire_bytes'],x['wire_sha256']) for x in selected})==1
print('PASS',len(rows),'wire rows;',len(commands),'functional processes, no timings')
