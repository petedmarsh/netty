import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.util.*;
public class ActualRootLayoutProbe {
    public static void premain(String args, Instrumentation inst) throws Exception {
        Class<?> c = Class.forName("io.netty.handler.codec.http2.HpackEncoder");
        Class<?> wrapperClass = Class.forName("io.netty.handler.codec.http2.DefaultHttp2HeadersEncoder");
        Object wrapper = wrapperClass.getConstructor().newInstance();
        Field root = wrapperClass.getDeclaredField("hpackEncoder");
        root.setAccessible(true);
        Object encoder = root.get(wrapper);
        System.out.println("root=actual-public-wrapper-hpackEncoder (not wrapper graph; not allocation/op)");
        List<String> fields = new ArrayList<>();
        for (Field f : c.getDeclaredFields()) {
            if (!Modifier.isStatic(f.getModifiers())) fields.add(f.getName() + ":" + f.getType().getName());
        }
        Collections.sort(fields);
        System.out.println(fields);
        Set<Object> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        ArrayDeque<Object> queue = new ArrayDeque<>();
        queue.add(encoder);
        long bytes = 0;
        while (!queue.isEmpty()) {
            Object o = queue.remove();
            if (!seen.add(o)) continue;
            bytes += inst.getObjectSize(o);
            if (o instanceof Object[]) {
                for (Object value : (Object[]) o) if (value != null) queue.add(value);
            } else if (!o.getClass().isArray()) {
                for (Class<?> type = o.getClass(); type != null; type = type.getSuperclass()) {
                    for (Field f : type.getDeclaredFields()) {
                        if (Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue;
                        f.setAccessible(true);
                        Object value = f.get(o);
                        if (value != null) queue.add(value);
                    }
                }
            }
        }
        System.out.println("encoder=" + inst.getObjectSize(encoder) + " graph=" + bytes + " objects=" + seen.size());
    }
    public static void main(String[] args) { }
}
