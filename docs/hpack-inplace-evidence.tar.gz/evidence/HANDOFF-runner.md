# Runner preparation handoff — NOT authorization to run

Prepared campaign.py (schedule/run/resume/report), readiness.py (offline gates),
input.template.json, readiness.template.json, PLAN.md, test_campaign.py and an
unchanged copy of the series ReadinessProbe.java. Analyzer is `campaign.py report`.

Offline preparation audit: all 407 original freeze entries match; six upstream/
replacement fixture sources and 48 corresponding classes match. See
preparation-audit.json. Candidate remains unverified and unspecified until code
agent HANDOFF. No input.json/readiness.json/freeze.json is created by preparation.
No Java, JMH timings, builds, production edits, commits or pushes were performed.

Next: main obtains candidate HANDOFF, completes provenance/protected sources and
readiness evidence per PLAN.md, validates and freezes, then returns for explicit
main GO. Main—not a worker—owns the eventual long-lived background process.

Do not run the historical four-stage readiness_probes.py unmodified. Reuse its
public browser manifest approach and the copied probe source against each exact
jar, with authorization, and attach hashed output/class files as readiness
evidence. Preserve any original failures before freeze. No candidate timing or
readiness claim has been made by this preparation.
