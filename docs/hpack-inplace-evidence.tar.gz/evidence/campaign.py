#!/usr/bin/env python3
"""Preparation is safe: generate/freeze/report never launch a benchmark or build."""
import argparse
import csv
import datetime
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
VERSIONS = ['upstream', 'replacement', 'inplace']
ORDERS = ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA']
SYNTH = ['REPEATED', 'WORKING_SET', 'MIXED', 'CHURN', 'NAME_HIT', 'COLLISION', 'STATIC', 'SENSITIVE', 'HUFFMAN']
CAP = ['WORKING_SET128', 'WORKING_SET384', 'WORKING_SET', 'WORKING_SET768', 'CHURN', 'COLLISION']

def require(ok, message):
    if not ok:
        raise ValueError(message)

def load(p):
    return json.loads(Path(p).read_text())

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def encoded(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()

def write_json(p, obj):
    Path(p).write_text(json.dumps(obj, indent=2) + '\n')

def config():
    return load(ROOT / 'input.json')

def cells(m):
    browser = m['browser_cases']
    require(len(browser) == 8, 'Exactly eight browser cells required')
    synthetic = [dict(id='synthetic-' + s, benchmark=m['synthetic_benchmark'],
                      params={'scenario': s, 'growThenShrink': 'false'}) for s in SYNTH]
    init = dict(id='init', benchmark=m['init_benchmark'], params={})
    require(len({c['id'] for c in browser + synthetic + [init]}) == 18, 'Duplicate cell IDs')
    require(all(re.fullmatch(r'[\w-]+', c['id']) for c in browser + synthetic), 'Unsafe cell ID')
    return browser, synthetic, init

def schedule(m):
    browser, synthetic, init = cells(m)
    # Fixed preregistered 384-fork design.
    out = []
    def add(group, cell, r, v, size):
        ident = f'{group}-{cell["id"]}-r{r}-{v}-{size}'
        params = dict(cell['params'], tableSize=str(size))
        target = ROOT / 'raw' / (ident + '.json')
        argv = [m['java'], '-jar', m['stages'][v]['jar'], '^' + re.escape(cell['benchmark']) + '$']
        for k, value in sorted(params.items()):
            argv += ['-p', f'{k}={value}']
        argv += ['-f', '1', '-wi', '5', '-w', '1s', '-i', '5', '-r', '1s', '-t', '1',
                 '-bm', 'avgt', '-tu', 'ns', '-prof', 'gc', '-foe', 'true',
                 '-jvmArgs', '-Xms512m -Xmx512m', '-rf', 'json', '-rff', str(target)]
        out.append(dict(id=ident, group=group, cell=cell['id'], round=r, version=v,
                        size=size, benchmark=cell['benchmark'], params=params, argv=argv))
    primary = browser + synthetic + [init]
    for r in range(1, 7):
        indices = list(range(18))
        indices = indices[r-1:] + indices[:r-1]
        for i in indices:
            for letter in ORDERS[(r-1+i) % 6]:
                add('primary', primary[i], r, VERSIONS[ord(letter)-ord('A')], 4096)
    # AB, BA, AB pairs (ABBA sequence); alternate starting side across cells.
    # Odd three-pair browser count cannot balance each cell exactly; eight cells
    # balance globally. Initialization uses six pairs and balances exactly.
    for r in range(1, 7):
        for i, cell in enumerate(browser + [init]):
            if i < 8 and r > 3:
                continue
            order = ['replacement', 'inplace']
            if (r + i) % 2 == 0:
                order.reverse()
            for v in order:
                add('capacity', cell, r, v, 65536)
    require(len(out) == 384, 'Wrong fork count')
    require(len({x['id'] for x in out}) == len(out), 'Duplicate fork IDs')
    return out

def inventory(m, require_main_review=True):
    from readiness import inventory as checked_inventory
    return checked_inventory(m, require_main_review)


def freeze():
    require(not (ROOT / 'freeze.json').exists(), 'Freeze already exists; never overwrite')
    m = config()
    inv = inventory(m)
    jobs = schedule(m)
    write_json(ROOT / 'schedule.json', jobs)
    inv[str(ROOT / 'schedule.json')] = digest(ROOT / 'schedule.json')
    write_json(ROOT / 'freeze.json', dict(files=inv, schedule_sha256=hashlib.sha256(encoded(jobs)).hexdigest()))

def verify_freeze():
    f = load(ROOT / 'freeze.json')
    for p, h in f['files'].items():
        require(digest(p) == h, 'Frozen artifact changed: ' + p)
    jobs = load(ROOT / 'schedule.json')
    require(hashlib.sha256(encoded(jobs)).hexdigest() == f['schedule_sha256'], 'Schedule mismatch')
    from readiness import verify_identity
    verify_identity(config())
    return jobs

def parse(job):
    data = load(ROOT / 'raw' / (job['id'] + '.json'))
    require(len(data) == 1, 'Expected exactly one JMH result')
    d = data[0]
    require(d['benchmark'] == job['benchmark'] and d['params'] == job['params'], 'Wrong benchmark/params')
    require(d['forks'] == 1 and d['measurementIterations'] == 5 and d['warmupIterations'] == 5, 'Wrong JMH configuration')
    require(d['mode'] == 'avgt' and d['threads'] == 1 and
            d['warmupTime'] == d['measurementTime'] == '1 s' and
            d['warmupBatchSize'] == d['measurementBatchSize'] == 1, 'Wrong measurement settings')
    secondary = {k.replace('\u00b7', '').split(':')[-1].strip(): v for k, v in d['secondaryMetrics'].items()}
    require(len(secondary) == len(d['secondaryMetrics']), 'Ambiguous normalized metrics')
    result = {}
    for name, metric, unit in [('ns', d['primaryMetric'], 'ns/op'), ('bytes', secondary['gc.alloc.rate.norm'], 'B/op')]:
        raw = metric['rawData']
        require(metric['scoreUnit'] == unit and len(raw) == 1 and len(raw[0]) == 5, 'Wrong units/raw shape')
        require(all(math.isfinite(x) for x in raw[0]), 'Nonfinite result')
        result[name] = statistics.mean(raw[0])
    return result

def ledger():
    p = ROOT / 'ledger.jsonl'
    rows = []
    previous = digest(ROOT / 'freeze.json')
    if p.exists():
        for line in p.read_text().splitlines():
            event = json.loads(line)
            h = event.pop('hash')
            require(event['previous'] == previous and hashlib.sha256(encoded(event)).hexdigest() == h, 'Broken ledger chain')
            event['hash'] = h
            rows.append(event)
            previous = h
    return rows, previous

def record(**event):
    _, previous = ledger()
    event['previous'] = previous
    event['timestamp_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    event['hash'] = hashlib.sha256(encoded(event)).hexdigest()
    with (ROOT / 'ledger.jsonl').open('a') as f:
        f.write(json.dumps(event) + '\n')
        f.flush()
        os.fsync(f.fileno())

def competing_jvms(output):
    # jps -l only: never collect VM arguments, which may contain credentials.
    return [line for line in output.splitlines()
            if re.search(r'jmh|ForkedMain|microbenchmarks?\.jar|benchmarks\.jar', line, re.I)]


def run(go):
    require(go, 'Explicit --main-go required; main-session authorization first')
    with (ROOT / 'runner.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        jobs = verify_freeze()
        m = config()
        (ROOT / 'raw').mkdir(exist_ok=True)
        expected = {j['id'] + ext for j in jobs for ext in ('.json', '.log')}
        require(all(p.name in expected for p in (ROOT / 'raw').iterdir()), 'Unknown orphan raw output')
        events, _ = ledger()
        require(all(e.get('id', e.get('job_id')) in {j['id'] for j in jobs} for e in events), 'Unknown ledger job')
        for job in jobs:
            verify_freeze()
            events, _ = ledger()
            prior = [e for e in events if e.get('id') == job['id']]
            if prior:
                for e in prior:
                    for p, h in e.get('outputs', {}).items():
                        require(digest(p) == h, 'Raw output changed')
                require([e['event'] for e in prior] == ['started', 'process-finished', 'parsed'], 'Interrupted/failed/parser-failed case: manual investigation required; never auto rerun')
                require(prior[1]['returncode'] == 0 and set(prior[1]['outputs']) ==
                        {str(ROOT / 'raw' / (job['id'] + ext)) for ext in ('.json', '.log')}, 'Incomplete output hashes')
                require(parse(job) == prior[-1]['values'], 'Parsed ledger values differ')
                continue
            target = ROOT / 'raw' / (job['id'] + '.json')
            log = target.with_suffix('.log')
            require(not target.exists() and not log.exists(), 'Orphan output; never overwrite')
            check = subprocess.run([m['jps'], '-l'], capture_output=True, text=True)
            competitors = competing_jvms(check.stdout)
            record(event='preflight', job_id=job['id'], jps=check.stdout, stderr=check.stderr,
                   returncode=check.returncode, competitors=competitors, host='shared-not-isolated')
            require(check.returncode == 0, 'jps failed; preflight preserved')
            require(not competitors, 'Competing HPACK/JMH JVM detected: ' + '\n'.join(competitors))
            record(event='started', id=job['id'], argv=job['argv'], host='shared-not-isolated')
            with log.open('xb') as f:
                proc = subprocess.run(job['argv'], stdout=f, stderr=subprocess.STDOUT, cwd=ROOT)
            outputs = {str(p): digest(p) for p in [log, target] if p.exists()}
            record(event='process-finished', id=job['id'], returncode=proc.returncode, outputs=outputs)
            require(proc.returncode == 0, 'Process failed; preserved, no retry')
            try:
                values = parse(job)
            except Exception as exc:
                record(event='parser-failed', id=job['id'], error=str(exc))
                raise
            verify_freeze()
            record(event='parsed', id=job['id'], values=values)

def report():
    jobs = verify_freeze()
    events, _ = ledger()
    values = {}
    for j in jobs:
        done = [e for e in events if e.get('id') == j['id'] and e['event'] == 'process-finished']
        require(len(done) == 1 and done[0]['returncode'] == 0, 'Incomplete/failed campaign: ' + j['id'])
        for p, h in done[0]['outputs'].items():
            require(digest(p) == h, 'Changed raw result')
        states = [e['event'] for e in events if e.get('id') == j['id']]
        require(states == ['started', 'process-finished', 'parsed'], 'Incomplete/failed ledger state')
        expected = {str(ROOT / 'raw' / (j['id'] + ext)) for ext in ('.json', '.log')}
        require(set(done[0]['outputs']) == expected, 'Incomplete output hashes')
        values[j['id']] = parse(j)  # Offline reparsing never launches JVMs.
    with (ROOT / 'raw-forks.csv').open('w') as f:
        w = csv.writer(f)
        w.writerow(['group', 'cell', 'round', 'version', 'size', 'ns/op', 'B/op'])
        for j in jobs:
            v = values[j['id']]
            w.writerow([j[k] for k in ['group', 'cell', 'round', 'version', 'size']] + [v['ns'], v['bytes']])
    comparisons = [('inplace', 'upstream'), ('inplace', 'replacement'), ('replacement', 'upstream')]
    rows = []
    for group in ['primary', 'capacity']:
        for cell in sorted({j['cell'] for j in jobs if j['group'] == group}):
            subset = [j for j in jobs if j['group'] == group and j['cell'] == cell]
            index = {(j['round'], j['version'], j['size']): values[j['id']] for j in subset}
            rounds = sorted({j['round'] for j in subset})
            for candidate, reference in (comparisons if group == 'primary' else [('inplace', 'replacement')]):
                cs, rs = (4096, 4096) if group == 'primary' else (65536, 65536)
                for metric in ['ns', 'bytes']:
                    a = [index[r, candidate, cs][metric] for r in rounds]
                    b = [index[r, reference, rs][metric] for r in rounds]
                    diff = [x-y for x, y in zip(a, b)]
                    mean = statistics.mean(diff)
                    half = {3: 4.30265273, 6: 2.57058184}[len(diff)] * statistics.stdev(diff) / math.sqrt(len(diff))
                    ref = statistics.mean(b)
                    rows.append([group, cell, f'{candidate}/{cs} - {reference}/{rs}', metric, len(diff), statistics.mean(a), ref, mean, mean-half, mean+half, 100*mean/ref if ref else 'undefined'])
    with (ROOT / 'comparisons.csv').open('w') as f:
        w = csv.writer(f)
        w.writerow(['group', 'cell', 'comparison', 'metric', 'pairs', 'candidate_mean', 'reference_mean', 'paired_delta', 'ci95_low', 'ci95_high', 'percent_delta'])
        w.writerows(rows)
    write_json(ROOT / 'summary.json', dict(forks=len(jobs), host='shared-not-isolated',
               comparisons=rows, comparison_columns=['group', 'cell', 'comparison', 'metric', 'pairs',
               'candidate_mean', 'reference_mean', 'paired_delta', 'ci95_low', 'ci95_high', 'percent_delta']))
    wire = load(ROOT / 'readiness.json')['wire_rows']
    with (ROOT / 'wire.csv').open('w') as f:
        w = csv.DictWriter(f, fieldnames=sorted(set().union(*(r.keys() for r in wire))))
        w.writeheader()
        w.writerows(wire)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['generate', 'validate', 'freeze', 'run', 'report'])
    parser.add_argument('--main-go', action='store_true')
    args = parser.parse_args()
    if args.action == 'generate':
        require(not (ROOT / 'freeze.json').exists(), 'Already frozen')
        jobs = schedule(config())
        write_json(ROOT / 'schedule.preview.json', jobs)
        print(f'{len(jobs)} forks; estimated {len(jobs)*10.7/60:.1f} minutes plus validation/variable overhead; NO execution')
    elif args.action == 'validate':
        inv = inventory(config(), require_main_review=False)
        print(f'PASS {len(inv)} immutable inputs; readiness verified; main review/GO separate')
    elif args.action == 'freeze':
        freeze()
    elif args.action == 'run':
        run(args.main_go)
    else:
        report()

if __name__ == '__main__':
    main()
