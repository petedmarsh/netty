# INPLACE readiness — ready for main review, NOT frozen or authorized to time

`input.json` and `readiness.json` are populated. `reviewed_by_main=false`.
No freeze, JMH timing, commit, push or long-lived process was started. Existing
packaging logs remain historical; focused and full paranoid HTTP/2 tests were rerun after the test-only review fix. All functional subprocesses
launched here have completed. No claim of host-wide JVM exclusivity is made.

## Identity and build evidence

- Candidate HEAD: `7369225ffe91d9afd75a5b168c1687ef3a96f71f` plus uncommitted
  `protected-source.patch`, byte-identical to code-agent `candidate.patch`.
- Candidate jar SHA256:
  `c5f0f55d8471f8ba2f0656846a57d61ad74a2066037102bea4c1f1bd6cc80640`.
- `source-proof/audit.json`: twelve protected source hashes/snapshots, six changed
  production/test files plus six benchmark fixtures. Five encoder/wrapper class
  files in the jar match current build output byte-for-byte.
- Offline readiness independently checks all six fixture sources and all **48**
  associated nested/generated class entries across upstream/replacement/inplace.
  Code-agent broader audit additionally reports **77** HPACK benchmark classes.
- Fresh `review-focused.log`: **148**, zero failures/errors/skips.
  Fresh `review-full-paranoid.log`: **1664**, zero failures/errors, **5** selected skips.
  Current full Surefire reports are in `source-proof/review-surefire-reports/`.
  Original logs/reports remain preserved; package run is historical (148 tests).
  Only HpackEncoderTest.java changed: two existing methods now assert no-growth
  capacity/pending updates/bucket identity and post-growth FIFO eviction/indexing.
  Initial String/AsciiString assertion mismatch is preserved in
  `review-focused-initial-failure.log`; both successful runs follow the fix.
- Source checks: setter is void, wrapper reference final, no
  `withMaxHeaderTableSize`; relinking uses cached `entry.hash`, not callbacks,
  and does not assign counters. New reflection tests verify cached hash/counter,
  FIFO links, head/latest and exact name/pair node identities through growth.

## Completed functional proof

`runtime-proof-v2/commands.json` records 53 successful subprocesses (one javac,
52 Java functional processes), **no timing**. Raw manifests are retained.

| Matrix | Cells | Versions | Exact-wire rows |
|---|---:|---:|---:|
| 4K browser | 8 | 3 | 24 |
| 4K synthetic | 9 | 3 | 27 |
| 64K browser | 8 | 2 | 16 |
| **Total** | | | **67** |

Each matching group has identical length-delimited SHA256 and wire-byte count.
Initialization is checked separately; it has no encode-wire row.

Public default getter is 4096 in all three jars. After request 65536:
- upstream getter remains **4096**, expected unsupported baseline behavior;
- replacement and inplace getters are **65536**;
- initialization fixture supports 4K in all three, 64K only in replacement/inplace.
  Upstream 64K initialization deliberately throws the fixture's clamp exception:
  **expected rejection, not a required pass**. Upstream is absent from 64K timings.
- Public wrapper root changes for replacement and stays identical for inplace.

Both replacement and inplace, in both same-name and distinct-name distributions:
**64,887 retained bytes; 1,120 entries; 1,120 bucket entries; max chain 7;
1,120 successful indexed replays; max dynamic index 1,181.**

`runtime-proof-v2/inplace-runtime.log` contains assertion-backed snapshots:

| Growth | Bytes / entries | Name/pair nodes | Both arrays | Encoder root |
|---|---|---|---|---|
| Empty | 0 / 0 | 0 / 0 | 64→1024, identities changed | identical |
| Populated | 2240 / 50 | 10 / 50 | 64→1024, identities changed | identical |

Cached hashes/counters and FIFO identity are unchanged. Both arrays retain their
identities on subsequent 64K→0→64K high-water reuse. Tests use reflection for
private HpackEncoder access; original ReadinessProbe.java is retained unchanged,
and no benchmark source/bytecode was modified.

`actual-root-layout/*-opened.log`: all three initial encoder roots are **72 bytes**,
**2160 reachable bytes / 13 objects**. This is the actual `hpackEncoder` reference
read from a public wrapper, **not** the entire wrapper graph and **not B/op**.
Candidate and replacement have identical field schema (upstream mask is byte,
replacement/candidate short); candidate introduces no new fields. Root identity
through growth is a separate runtime observation, not inferred from equal sizes.

## Preserved preflight failures

1. `runtime-proof/upstream-runtime.log`: original probe incorrectly expected 64K
   initialization to succeed. Original source/classes/command log and outer
   `readiness-execution.log` retained. V2 explicitly checks expected rejection.
2. `actual-root-layout/upstream.log`: instrumentation graph traversal initially
   lacked Java 21 module access to String.value. Original failed log and command
   retained; separate `*-opened.log` runs use
   `--add-opens=java.base/java.lang=ALL-UNNAMED`. No benchmark reruns involved.

## Validation and freeze boundary

- **14 offline tests pass** (`review-offline-tests.log`): 8 runner tests plus
  6 raw-runtime/layout/scope/review-boundary tests.
- `python3 campaign.py validate`: **PASS 811 immutable inputs**;
  **381 evidence entries**. Main review/GO remains separate.
- Schedule: **384 forks = 324 primary + 48 browser 64K + 12 init 64K**.
- Current candidate patch checking is limited to `codec-http2/src/main`,
  `codec-http2/src/test`, `microbench/src/main`; explicit source hashes supplement
  it. Runner/plan/input metadata, immutable snapshots, probe sources/classes and
  evidence are protected. Historical original freeze remains untouched.
  Production source/jar hashes and runtime/wire proof are unchanged; no repackage.
  Prior test source/patch/input/readiness/audit metadata is in `pre-test-review/`.
- This report and future rendered narrative docs are deliberately not freeze
  inputs. Initial `HANDOFF.md` is separately immutable evidence. Do not modify
  frozen original-series artifacts or runner/plan metadata after freeze.

## Exact main commands (only after reviewing raw proof and hashes)

Working directory: `/Users/pmarsh/src/netty/.worktrees/hpack-inplace-evidence`.

Review at least `source-proof/audit.json`, `protected-source.patch`,
`runtime-proof-v2/{upstream,replacement,inplace}-runtime.log`, both retention logs,
`runtime-proof-v2/wire-rows.json`, `actual-root-layout/*-opened.log`, preserved
failures, build logs and `readiness.json` evidence hashes. Then:

```sh
python3 campaign.py validate
shasum -a 256 candidate-benchmarks.jar protected-source.patch
# Main explicitly accepts the reviewed evidence:
python3 - <<'PY'
import json
from pathlib import Path
p = Path('readiness.json')
r = json.loads(p.read_text())
assert r['reviewed_by_main'] is False
r['reviewed_by_main'] = True
p.write_text(json.dumps(r, indent=2) + '\n')
PY
python3 campaign.py freeze
```

STOP after freeze unless main has explicitly authorized timings. Once authorized,
main owns the background tool call (do not launch from a worker):

```sh
(set -C; python3 campaign.py run --main-go > campaign-main-001.log 2>&1)
```

Use that command with the main session's background execution facility. For a
later authorized resume, use a new exclusive log name (`campaign-main-002.log`),
never truncate old logs; the runner refuses failed/orphan states rather than
retrying silently. After all 384 verified forks complete:

```sh
python3 campaign.py report
```

Do not rerun the assembly scripts after main approval/freeze: they are preparation
helpers, not resume commands, and would reset review or alter frozen inputs.
