#!/usr/bin/env python3
"""Offline audit/report only; never invokes Java, builds, tests or campaign.report."""
import sys
sys.dont_write_bytecode = True
import csv, hashlib, itertools, json, math, statistics, zipfile
from collections import Counter, defaultdict
from pathlib import Path
import campaign
R = Path(__file__).resolve().parent
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(x): return json.dumps(x, sort_keys=True, separators=(',', ':')).encode()
def close(a,b): assert math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-8),(a,b)
# Snapshot every existing evidence file, excluding our derived outputs and bytecode cache.
outputs = {'analysis-audit.py','analysis-audit.json','analysis-comparisons.csv','results.md'}
before = {p:sha(p) for p in R.rglob('*') if p.is_file() and p.name not in outputs and '__pycache__' not in p.parts}
f = load(R/'freeze.json'); m=load(R/'input.json')
for p,h in f['files'].items(): assert sha(p)==h,p
jobs=load(R/'schedule.json'); assert len(jobs)==384 and len({j['id'] for j in jobs})==384
assert hashlib.sha256(canonical(jobs)).hexdigest()==f['schedule_sha256']
assert jobs==campaign.schedule(m)
inv=campaign.inventory(m) # read-only hash/ZIP checks and git HEAD/diff; no Java
assert len(inv)==811
for p,h in inv.items(): assert f['files'][p]==h
bycell=defaultdict(list)
for j in jobs: bycell[j['group'],j['cell']].append(j)
assert Counter(j['group'] for j in jobs)=={'primary':324,'capacity':60}
for (g,c),js in bycell.items():
    rounds=sorted({j['round'] for j in js})
    orders=[tuple(j['version'] for j in js if j['round']==r) for r in rounds]
    if g=='primary': assert set(orders)==set(itertools.permutations(['upstream','replacement','inplace']))
    else:
        assert len(rounds)==(6 if c=='init' else 3)
        assert all(set(o)=={'inplace','replacement'} for o in orders)
        assert all(orders[i]!=orders[i+1] for i in range(len(orders)-1))
events=[json.loads(s) for s in (R/'ledger.jsonl').read_text().splitlines()]
assert len(events)==1536
previous=sha(R/'freeze.json')
for e in events:
    body={k:v for k,v in e.items() if k!='hash'}
    assert e['previous']==previous and hashlib.sha256(canonical(body)).hexdigest()==e['hash']
    previous=e['hash']
vals={}; rawhash={}
for i,j in enumerate(jobs):
    es=events[i*4:i*4+4]
    assert [e['event'] for e in es]==['preflight','started','process-finished','parsed']
    assert all(e.get('id',e.get('job_id'))==j['id'] for e in es)
    assert es[0]['returncode']==es[2]['returncode']==0 and es[0]['competitors']==[]
    assert es[1]['argv']==j['argv']
    expected={str(R/'raw'/(j['id']+ext)) for ext in ['.json','.log']}
    assert set(es[2]['outputs'])==expected
    for p,h in es[2]['outputs'].items(): assert sha(p)==h; rawhash[p]=h
    d,=load(R/'raw'/(j['id']+'.json'))
    assert d['benchmark']==j['benchmark'] and d['params']==j['params']
    assert d['forks']==d['threads']==d['measurementBatchSize']==d['warmupBatchSize']==1
    assert d['measurementIterations']==d['warmupIterations']==5
    assert d['measurementTime']==d['warmupTime']=='1 s' and d['mode']=='avgt'
    assert d['jvmArgs']==['-Xms512m','-Xmx512m']
    alloc=[v for k,v in d['secondaryMetrics'].items() if k.replace('·','').split(':')[-1].strip()=='gc.alloc.rate.norm']
    assert len(alloc)==1
    v={}
    for metric,unit,data in [('ns','ns/op',d['primaryMetric']),('bytes','B/op',alloc[0])]:
        assert data['scoreUnit']==unit and len(data['rawData'])==1 and len(data['rawData'][0])==5
        assert all(math.isfinite(x) for x in data['rawData'][0])
        v[metric]=statistics.mean(data['rawData'][0]); close(v[metric],es[3]['values'][metric])
    vals[j['group'],j['cell'],j['round'],j['version']]=v
assert set(rawhash)=={str(p) for p in (R/'raw').iterdir()} and len(rawhash)==768
rawcsv=list(csv.DictReader((R/'raw-forks.csv').open())); assert len(rawcsv)==384
for row,j in zip(rawcsv,jobs):
    for k in ['group','cell','round','version','size']: assert row[k]==str(j[k])
    for metric,col in [('ns','ns/op'),('bytes','B/op')]: close(row[col],vals[j['group'],j['cell'],j['round'],j['version']][metric])
rows=[]
for g in ['primary','capacity']:
    for c in sorted(c for gg,c in bycell if gg==g):
        rounds=sorted({j['round'] for j in bycell[g,c]}); size=4096 if g=='primary' else 65536
        for a,b in ([('inplace','upstream'),('inplace','replacement'),('replacement','upstream')] if g=='primary' else [('inplace','replacement')]):
            for metric in ['ns','bytes']:
                av=[vals[g,c,r,a][metric] for r in rounds]; bv=[vals[g,c,r,b][metric] for r in rounds]
                ds=[x-y for x,y in zip(av,bv)]; n=len(ds); delta=statistics.mean(ds)
                # Independent arithmetic; same preregistered rounded Student-t quantiles.
                half={6:2.57058184,3:4.30265273}[n]*math.sqrt(sum((x-delta)**2 for x in ds)/(n-1)/n)
                rows.append([g,c,f'{a}/{size} - {b}/{size}',metric,n,statistics.mean(av),statistics.mean(bv),delta,delta-half,delta+half,100*delta/statistics.mean(bv)])
s=load(R/'summary.json'); assert s['forks']==384 and len(rows)==len(s['comparisons'])==126
csvrows=list(csv.reader((R/'comparisons.csv').open())); assert csvrows[0]==s['comparison_columns'] and len(csvrows)==127
for actual,reported,cr in zip(rows,s['comparisons'],csvrows[1:]):
    assert actual[:4]==reported[:4]==cr[:4]
    for a,b,c in zip(actual[4:],reported[4:],cr[4:]): close(a,b); close(a,c)
ready=load(R/'readiness.json'); wire=list(csv.DictReader((R/'wire.csv').open()))
assert len(wire)==len(ready['wire_rows'])==67
assert wire==[{k:str(v) for k,v in x.items()} for x in ready['wire_rows']]
audit=load(R/'source-proof/audit.json')
with zipfile.ZipFile(m['stages']['inplace']['jar']) as z:
    for p,h in audit['production_classes'].items(): assert hashlib.sha256(z.read(p)).hexdigest()==h
for p,h in audit['sources'].items(): assert sha(Path(m['candidate_identity']['repo'])/p)==h
counts={}
for g in ['primary','capacity']:
    for comp in sorted({r[2] for r in rows if r[0]==g}):
        for metric in ['ns','bytes']:
            rs=[r for r in rows if r[0]==g and r[2]==comp and r[3]==metric]
            counts[f'{g}: {comp}: {metric}']={'lower':sum(r[9]<0 for r in rs),'higher':sum(r[8]>0 for r in rs),'includes_zero':sum(r[8]<=0<=r[9] for r in rs)}
with (R/'analysis-comparisons.csv').open('w') as out:
    w=csv.writer(out); w.writerow(s['comparison_columns']); w.writerows(rows)
result=dict(status='PASS',forks=384,measurement_iterations=1920,events=1536,raw_files=768,readiness_inputs=811,freeze_entries=len(f['files']),comparison_rows=126,wire_rows=67,counts=counts,first_event=events[0]['timestamp_utc'],last_event=events[-1]['timestamp_utc'],frozen_sha256=sha(R/'freeze.json'),ledger_tail=previous)
# Readable report, all contrasts and both metrics retained.
text=['# Complete in-place HPACK campaign — audited results','',
'## Answer',
'**64K initialization improved; universal 4K preservation/improvement is not established.** The stable void setter reduces 64K initialization from 374.145 to 334.628 ns/op (−39.516 ns, 95% paired CI [−46.057, −32.976], −10.562%) and allocation from 9192.000152 to 8992.000136 B/op (−200.000016 B, CI [−200.000018, −200.000013], −2.176%). These are pointwise significant versus replacement; upstream does not support 64K and was not measured there.',
'At 4K all 54 timing contrasts (18 cells × three comparisons) include zero. This means no detected timing improvement/regression, NOT equivalence or non-inferiority. The frozen plan has no non-inferiority margin or decision rule; no NI pass count is justified. Broad uncertainty leaves meaningful slowdowns possible. 4K init is 36.088 / 36.419 / 38.172 ns/op (upstream / replacement / inplace), with about 768 B/op in all three.',
'', '## Audit and provenance',
'- COMPLETE: 384 unique scheduled forks, 324 at 4K + 48 browser at 64K + 12 initialization at 64K; all completed once, exit 0. 1920 measurement iterations, averaged within forks (not 1920 independent samples).',
'- 1536 hash-chained events: exactly preflight/start/process-finished/parsed per scheduled fork, in schedule order; 768 raw hashes = 384 JSON + 384 logs. No orphan or missing raw file. All preflights report no competing JMH JVM, but the host was shared, not isolated.',
'- All 811 readiness inventory inputs unchanged; freeze.json contains **812 entries**, because freeze adds schedule.json. Candidate HEAD and exact protected git patch rechecked; all 12 protected source hashes, three jar identities, six fixture sources/48 nested/generated classes, and five candidate production class hashes verified offline. Broader historical hash-verification reports 77 HPACK benchmark classes.',
'- 126 comparison rows independently recalculated from raw JSON and matched against both comparisons.csv and summary.json; all 384 raw-forks.csv records matched. All 67 exact-wire rows match readiness and wire.csv: 24 browser + 27 synthetic at 4K, 16 browser at 64K. Matched wire lengths/hashes and requested/actual capacity checked by the read-only readiness gate.',
'- Existing reviewed focused tests: 148, 0 failures/errors/skips. Full paranoid HTTP/2: 1664, 0 failures/errors, 5 skips. Package history: success, focused tests enabled. These are preserved historical results, NOT new test executions. Original probe/test failures remain preserved, followed by corrected successful evidence.',
'- Candidate jar SHA256: `'+m['stages']['inplace']['sha256']+'`. Candidate base `'+m['candidate_identity']['head']+'` plus frozen protected patch (not a clean committed identity).',
'- No timing, tests, builds, Java probes, source edits, commit or push in this audit. Existing artifacts are hashed before/after and preserved. Only analysis-audit.py/json, analysis-comparisons.csv and this report are added.',
'', '## Source change and functional scope',
'Two production files replace the replacement-return API/copy constructor with void setMaxHeaderTableSize and a final wrapper encoder reference. Mutable bucket arrays/short mask grow at their high-water mark; both arrays are allocated before relinking existing nodes via cached hashes. FIFO links, counters, representatives, raw hash/admission/collision policy and pending minimum behavior are retained. Four test/support files adapt callers and cover empty/populated growth, identity, cached hash/counters, validation, eviction/indexing and high-water reuse. No benchmark source change.',
'Existing runtime proof: root identity stable for inplace, replaced for old implementation; empty and populated arrays grow 64→1024. Populated proof retains 50 pair and 10 name nodes, 2240 bytes. Both implementations retain 64,887 bytes/1120 entries with max chain 7 and max dynamic index 1181 in both tested distributions. Initial encoder root is 72 bytes, reachable graph 2160 bytes/13 objects for all three; graph footprint is not allocation per operation.',
'', '## Method and notation',
'U = unchanged upstream; O = old replacement implementation; N = new inplace setter. Means are raw ns/op or normalized B/op. Browser operations are already normalized per header block (64 blocks/invocation); do not divide again. Synthetic and initialization retain their fixture operation definitions. NEVER is primary policy; INDEX_COOKIES is supporting, not a substitute.',
'For each cell and metric, average five measurements within each fork, pair versions by round, then compute arithmetic differences dᵣ = candidate − reference. CI = mean(d) ± t(.975,n−1)·sd(d)/√n, with n=6/df=5 for all 4K and 64K init, n=3/df=2 for 64K browser; t=2.57058184 and 4.30265273. Negative favors candidate. Percent delta is delta/reference mean, not mean ratios. No pooling across cells, no outlier deletion, no cross-capacity paired claim.',
'4K uses each of six three-version permutations once per cell; 64K alternates AB/BA, browser starting sides balance globally (three pairs cannot balance within one cell), initialization has three pairs each direction. Intervals are descriptive, unadjusted pointwise 95% paired-t intervals on a shared host. Distribution/host effects and multiplicity limit generalization. Tiny allocation differences can reflect normalized profiler overhead; near-zero allocation denominators make percent changes misleading.',
'Each contrast below is **delta [95% CI low, high]; percent**. Full precision is in analysis-comparisons.csv; very small allocation values use scientific notation rather than rounding away uncertainty.','']
def num(x): return f'{x:.6g}' if abs(x)<.01 else f'{x:.3f}'
def contrast(r): return f'{num(r[7])} [{num(r[8])}, {num(r[9])}]; {r[10]:+.3f}%'
def short(c): return c.replace('browser-','').replace('persistentSession','persistent').replace('newConnectionSession','new').replace('AUTHENTICATED','AUTH').replace('INDEX_COOKIES','INDEX').replace('synthetic-','')
for g,label in [('primary','4K'),('capacity','64K — inplace versus replacement only')]:
    for subset,title in [(lambda c:c.startswith('browser'),'browser (all eight cells)'),(lambda c:c.startswith('synthetic'),'synthetic (all nine cells)'),(lambda c:c=='init','initialization')]:
        cells=sorted(c for gg,c in bycell if gg==g and subset(c))
        if not cells: continue
        for metric,unit in [('ns','ns/op'),('bytes','B/op')]:
            text += [f'## {label}: {title} — {unit}', '']
            if g=='primary': text += ['| Cell | U mean | O mean | N mean | N−U [CI]; % | N−O [CI]; % | O−U [CI]; % |','|---|---:|---:|---:|---|---|---|']
            else: text += ['| Cell | O mean | N mean | N−O [CI]; % |','|---|---:|---:|---|']
            for c in cells:
                rs=[r for r in rows if r[0]==g and r[1]==c and r[3]==metric]
                if g=='primary': text.append('| '+ ' | '.join([short(c),num(rs[0][6]),num(rs[1][6]),num(rs[0][5])]+[contrast(r) for r in rs])+' |')
                else: text.append('| '+' | '.join([short(c),num(rs[0][6]),num(rs[0][5]),contrast(rs[0])])+' |')
            text.append('')
text += ['## Pointwise CI counts (lower / higher / includes zero)', '', '| Scope / contrast / metric | Lower | Higher | Includes zero |','|---|---:|---:|---:|']
for k,v in counts.items(): text.append('| '+k+' | '+' | '.join(str(v[x]) for x in ['lower','higher','includes_zero'])+' |')
text += ['', 'Counts are descriptions, not a familywise significance test, an NI decision, or proof over all workloads. At 4K the only allocation CI excluding zero is persistent AUTH/INDEX N−U (−40.000 B/op, CI [−60.565, −19.435]); none excludes zero against O. At 64K timing only initialization excludes zero; allocation excludes zero for initialization and three new-connection cells.','', '## Counterexamples and limits',
'- 4K CHURN is slower in point estimate: U/O/N 1540.779/1512.810/1653.074 ns. N−O +140.264 ns (+9.272%), CI [−264.763, +545.290]; N−U +112.295 ns (+7.288%), CI [−362.078, +586.668]. Allocation approximately 336 B/op throughout. Neither improvement nor regression established.',
'- 4K new NORMAL/NEVER: U/O/N 633.190/927.691/1210.756 ns. N−U +577.565 [−936.948, +2092.078]; N−O +283.065 [−537.177, +1103.307]. Large positive point estimate cannot be dismissed, nor called significant. All forks are retained.',
'- 64K steady persistent AUTH/NEVER: old/new 565.629/598.386 ns, +32.757 (+5.791%), CI [−111.968, +177.482]; allocation old/new 0.000230/16.000243 B/op, delta +16.000013 [−52.842489, +84.842515]. Persistent NORMAL/INDEX: 395.158→415.872 ns, +20.714 [−89.356, +130.783]; allocation 16.000161→48.000169 B/op, +32.000008 [−36.842480, +100.842497]. These disprove a blanket point-estimate improvement narrative, not establish regressions.',
'- The 64K init allocation saving is not a universal steady-state allocation saving. Near-zero baseline ratios (millions of percent) are mathematically computable but not useful engineering effect sizes. Use absolute B/op and intervals.',
'- Initialization measures construction plus empty default-4K→64K configuration, not populated late SETTINGS growth or steady-state resize latency. Functional tests cover populated semantics, not its performance. No 64K synthetic/churn timings exist in this matrix; 64K steady browser results are the available counterexamples.',
'', '## Reproduce this audit (offline only)', '`python3 -B analysis-audit.py` from this evidence directory. Reads existing raw evidence and read-only git identity; writes only the four derived analysis/report artifacts. Never run preparation, freeze, run, build, or test commands for this interpretation.', '']
(R/'results.md').write_text('\n'.join(text))
for p,h in before.items(): assert sha(p)==h, 'Pre-existing artifact changed: '+str(p)
result['preexisting_files_unchanged']=len(before)
(R/'analysis-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
