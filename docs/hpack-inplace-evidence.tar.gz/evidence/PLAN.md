# Prepared only: in-place / replacement / unchanged upstream

No timings, builds, Java probes, production edits, commit or push during preparation.
Candidate jar and identity MUST come from the code agent's HANDOFF; placeholders
are intentionally not runnable. Main owns the eventual background process. No
worker should wait on a 600-second foreground tool timeout. Explicit main GO is
required; preparing, validating, or freezing is NOT permission to measure.

## Preregistered matrix (384 forks, approximately 70 minutes plus overhead)

* 4K: 8 browser + 9 synthetic encode + initialization = 18 cells × 6 rounds ×
  3 versions = 324 forks. Every cell sees all six ABC permutations, once each.
  A=unchanged 3eaff upstream, B=series step3 replacement, C=in-place setter.
* 64K: 8 browser × 3 pairs × 2 versions = 48 forks; initialization × 6 pairs ×
  2 versions = 12 forks. Replacement and in-place only, SAME 65536 capacity.
  Alternating AB/BA pairs form ABBA blocks; three browser pairs necessarily
  leave an odd pair per cell. Starting side alternates across the eight cells
  for global balance. Initialization has exactly 3 pairs in either direction.
* Every fork: one thread, avgt ns, gc profiler, 5 × 1s warmup, 5 × 1s measurement,
  one fork per invocation, fixed -Xms512m -Xmx512m (same as series).
* Preserve NORMAL/AUTHENTICATED × NEVER/INDEX_COOKIES × persistent/new browser
  cells. NEVER remains primary; indexed-policy results are supporting evidence,
  not a substitute. Six original benchmark/support sources and complete nested
  and generated classes must match in all jars. No new benchmarks.
* Browser annotations normalize 64 header blocks per invocation: report ns/op
  and B/op as per header-block, NOT per session and do NOT divide by 64 again.
  Synthetic encode and initialization use their existing operation definitions.

## Readiness, identity and freeze (later, main-owned)

1. Copy input.template.json to input.json and readiness.template.json to
   readiness.json. Fill candidate jar/commit/hash and six candidate source paths
   ONLY from HANDOFF. Original step0/step3 paths and hashes are pinned.
2. Save exact `git diff --binary HEAD -- codec-http2/src/main codec-http2/src/test microbench/src/main` bytes for the candidate checkout to a
   patch file, set patch_sha256, repo and HEAD. A dirty candidate is supported;
   commit alone does not identify it. Complete protected_sources with absolute
   path/sha256 pairs covering the SAME reviewed production/test/fixture sources
   as the code agent's handoff. Include untracked fixture sources where relevant,
   not every untracked test log. The runner checks this list AND the current
   source-scoped tracked git patch on every resume/before every fork/after every fork.
   Rendered narrative/report docs are not protected; they may be updated after freeze.
   Static initial HANDOFF remains immutable evidence. Freeze also hashes runner,
   plans, templates, jars, source snapshots, Java tools, probe source and evidence.
3. Supply evidence entries {kind,path,sha256}, including build-provenance, wire,
   retention, tests, handoff. Include all probe classes and logs, build logs,
   source inventories, test reports and pre-freeze parser failures as individual
   hashed entries. Review jar-to-source provenance, not just self-declared flags.
   Preserve original parser failures; never rewrite/delete logs to make a gate
   pass. A later parser correction requires separate audited evidence, not a
   silent benchmark rerun.
4. Readiness public probe: existing series ReadinessProbe.java is copied here
   byte-for-byte as historical input. RuntimeReadinessProbe.java adapts private
   implementation size/length access to reflection (no benchmark edits).
   RuntimeProof.java adds public capacity/init and empty/populated identity assertions.
   Existing browser
   fixture main emits exact wire manifests. The series readiness_probes.py is
   a reference only: it assumes four stages and must NOT be run unadapted.
   Execute probes only later under separate main authorization; preparation
   does not compile or launch them. Require exact 4K wire matches for 17 encode
   cells across all three variants and exact 64K browser wire across both
   supporting variants, verified actual/configured capacity, public-wrapper
   retention 60000..65536 bytes for BOTH replacement and in-place, collision/index
   bounds and populated late-SETTINGS tests. Wire rows use version,cell,size,
   requested_size,actual_size,wire_bytes,wire_sha256 (length-delimited stream hash).
   Existing series evidence may be reused for old jars, but candidate evidence
   must use the new jar. Upstream is intentionally not timed at unsupported 64K.
5. `python3 campaign.py generate` previews exactly 384 jobs without Java.
   `python3 campaign.py validate` performs offline readiness/identity checks.
   Main reviews evidence, sets reviewed_by_main=true, then
   `python3 campaign.py freeze`. Do not edit protected files after freeze.
6. STOP and return to main. Only after explicit main GO, main may own a background
   `python3 campaign.py run --main-go > campaign.log 2>&1` (use a new exclusive
   log name when resuming, never truncate prior logs). No implicit execution.
   Resume uses the same command and skips only hash-verified parsed successes.
   It refuses orphan files, started-without-completion, failed processes or
   parser failures; investigate manually, never automatic retries or deletion.
   Preflight uses only `jps -l`, never VM arguments; unrelated Bazel servers are
   not competitors. Only JMH/benchmark JVM names trigger the competing-work gate.
7. `python3 campaign.py report` is the offline analyzer. It requires all 384
   completed forks and intact raw log/JSON hashes, freeze and chained ledger.
   It writes raw-forks.csv, comparisons.csv, summary.json and wire.csv.

## Interpretation

For every 4K cell show in-place minus upstream, in-place minus replacement AND
replacement minus upstream. At 64K show in-place minus replacement only. This
same-capacity comparison isolates the setter/replacement allocation distinction
without conflating supported table size. Average the five measurement iterations
within each fork, pair by cell/round, and report ns and normalized allocation
means, paired mean differences and 95% paired-t intervals (df=5 for six pairs,
df=2 for three pairs). Percent delta is delta/reference mean, undefined for zero
reference allocation. These are descriptive unadjusted per-cell intervals on a
shared, non-isolated host, not multiple-comparison-adjusted population claims.
No pooling iterations as independent samples, no cross-cell pooled speedup.

Candidate 64K vs 4K is optional later descriptive context only. Different matrices
and timing order are NOT paired same-cell trials; this runner intentionally does
not produce cross-matrix paired statistics or infer that comparison.

Initialization measures construction plus empty 4K→64K constructor/configuration
copy cost. It does NOT measure populated late SETTINGS or steady-state resize
latency. Those paths are covered by functional tests, not timed here.

## Offline preparation checks

`python3 -m unittest -v test_campaign` (from this directory) uses fixtures/mocks;
no JVM, build, probe, timing or background worker is started.
