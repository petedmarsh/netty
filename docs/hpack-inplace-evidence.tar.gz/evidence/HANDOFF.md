# Stable in-place HPACK growth candidate

Worktree: `/Users/pmarsh/src/netty/.worktrees/hpack-inplace`
Branch: `perf/hpack-64k-inplace`
Base: `7369225ffe91d9afd75a5b168c1687ef3a96f71f`
Uncommitted changes only to six codec-http2 production/test files; published series untouched.

## Implementation
- Void `setMaxHeaderTableSize`, stable encoder identity, final wrapper reference.
- Mutable bucket arrays and short mask, monotonic high-water allocation, no copy constructor.
- Both arrays allocated before relinking; local mask and cached hashes only. Existing pair/name nodes retained. FIFO links/counters/name representatives unchanged; oldest-first prepend keeps pair lookup newest-first.
- Original uint32 validation before 64KiB clamp/allocation. Pending minimum, header-list validation, raw hashing, collision guards and wire/admission policies unchanged.
- Adapted all internal callers and copy-oriented tests. Coverage includes empty growth, populated retained nodes/config, pending 0->64KiB surviving rejected header list and invalid limits, high-water array reuse, FIFO/counter wrap, collision guards and public near-64KiB indexed replay.

## Test-only review refresh (2026-10-15)
- Only `codec-http2/src/test/java/io/netty/handler/codec/http2/HpackEncoderTest.java` changed in this refresh; two existing methods extended, no added test methods.
- No-growth configuration now checks capacity, both bucket identities, pending minimum wire update, decoder capacity, and update consumption (including no update for an unchanged setting).
- Populated growth now exercises subsequent insertion-driven FIFO eviction: all 99 surviving nodes retain order, both decoder/encoder contents agree, oldest survivor encodes at exact index 161, and the evicted pair is reinserted literally and decoded correctly.
- Fresh `review-focused.log`: 148 tests, zero failures/errors/skips. Fresh `review-full-paranoid.log`: 1664 tests, zero failures/errors, 5 selected skips. Both BUILD SUCCESS; same commands below. Initial test assertion failure comparing String with AsciiString is preserved in `review-focused-initial-failure.log`; corrected to compare content before both successful runs.
- Fresh source/test audit: `review-source-audit.log`, `source-proof/audit.json`, `source-proof/review-surefire-reports/`. Old logs/reports preserved; prior metadata/patch/source snapshot archived in `pre-test-review/`.
- Production source hashes and five encoder/wrapper class bytes remain identical to the existing candidate jar; no packaging required. All jar hashes and six shared fixture sources/48 class entries unchanged. Existing functional runtime, layout, retention and 67-row exact-wire proof remains applicable and untouched.
- Readiness refreshed but remains unfrozen with `reviewed_by_main=false`; offline validation does not authorize measurement. No JMH, commit or push.

## Verification (original build; fresh review runs above)
Homebrew Java21 `/opt/homebrew/opt/openjdk@21`; writable Maven cache `/Users/pmarsh/src/netty/.worktrees/hpack-series-evidence/m2`.
All commands use `./mvnw -B -Dmaven.repo.local=<cache>`:
- `-pl codec-http2 -am -Dtest='Hpack*Test,DefaultHttp2HeadersEncoderTest' -Dsurefire.failIfNoSpecifiedTests=false test`: 148 tests, zero failures/errors/skips (`focused.log`).
- `-pl codec-http2 -am -Dio.netty.leakDetection.level=paranoid -Dio.netty.util.LeakPresenceDetector.trackCreationStack=true -Dtest='io.netty.handler.codec.http2.*Test' -Dsurefire.failIfNoSpecifiedTests=false test`: 1664 tests, zero failures/errors, 5 suite-selected skips (`full-paranoid.log`).
- `-pl microbench -am -Pbenchmark-jar,!mac -Dtest='Hpack*Test,DefaultHttp2HeadersEncoderTest' -Dsurefire.failIfNoSpecifiedTests=false package`: success, focused tests enabled, 148 tests (`package.log`).
- `git diff --check`: clean.
- `LayoutProbe.java` instrumentation agent compared initial 4KiB context against all four prior stage jars. Candidate and step3 identical field schema, 72-byte encoder, 2160-byte initial reachable graph / 13 objects. See `layout-*.log`; no additional fields.
- All HPACK benchmark Java sources unchanged against base and prior source manifests (includes requested six). All 77 HPACK benchmark class files, including nested/generated classes, identical to each step0..step3 jar. See `hash-verification.json`.

## Artifacts
Directory: `/Users/pmarsh/src/netty/.worktrees/hpack-inplace-evidence`
- Candidate jar: `candidate-benchmarks.jar`
- SHA256: `c5f0f55d8471f8ba2f0656846a57d61ad74a2066037102bea4c1f1bd6cc80640`
- Patch: `candidate.patch`; checkout status: `status.txt`.
- Build logs, source/jar/class hash checks and reproducible instrumentation probe alongside this handoff.

No long JMH timing, commit or push performed. No speed claim: this establishes semantics, layout, and comparable fixtures, not performance. Next step is review and separately authorized measurement.
