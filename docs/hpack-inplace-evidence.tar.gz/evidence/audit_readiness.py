"""Offline provenance audit; no build or timing."""
import hashlib,json,re,shutil,subprocess,zipfile
from pathlib import Path
import campaign as c
R=c.ROOT;m=c.config();repo=Path(m['candidate_identity']['repo']);out=R/'source-proof';out.mkdir(exist_ok=True)
result={'sources':{},'production_classes':{},'tests':{},'fixture_class_count':sum(len(s['class_entries']) for s in m['shared_sources'])}
assert (R/'candidate.patch').read_bytes()==(R/'protected-source.patch').read_bytes()
for item in m['candidate_identity']['protected_sources']:
 p=Path(item['path']);relative=p.relative_to(repo);dest=out/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);assert c.digest(dest)==item['sha256'];result['sources'][str(relative)]=item['sha256']
with zipfile.ZipFile(m['stages']['inplace']['jar']) as z:
 for name in ['HpackEncoder','DefaultHttp2HeadersEncoder']:
  for p in (repo/'codec-http2/target/classes/io/netty/handler/codec/http2').glob(name+'*.class'):
   entry='io/netty/handler/codec/http2/'+p.name
   assert hashlib.sha256(z.read(entry)).hexdigest()==c.digest(p)
   result['production_classes'][entry]=c.digest(p)
for label,file in [('focused','review-focused.log'),('full','review-full-paranoid.log'),('package','package.log')]:
 text=(R/file).read_text();matches=re.findall(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+)',text)
 assert 'BUILD SUCCESS' in text and matches
 counts=list(map(int,matches[-1]));assert counts[1:3]==[0,0];result['tests'][label]=dict(zip(['tests','failures','errors','skipped'],counts))
reports=repo/'codec-http2/target/surefire-reports'
for p in reports.glob('*'):
 if p.is_file(): dest=out/'review-surefire-reports'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(p,dest)
source=(repo/'codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java').read_text()
wrapper=(repo/'codec-http2/src/main/java/io/netty/handler/codec/http2/DefaultHttp2HeadersEncoder.java').read_text()
assert 'public void setMaxHeaderTableSize(long maxHeaderTableSize)' in source
assert 'withMaxHeaderTableSize' not in source+wrapper
assert 'private final HpackEncoder hpackEncoder;' in wrapper
body=source.split('private void growBuckets(int buckets) {')[1].split('\n    /**')[0]
assert 'entry.hash & newMask' in body and 'hashCode(' not in body and 'entry.counter =' not in body
result['source_contract']={'void_setter':True,'no_withMaxHeaderTableSize':True,'final_wrapper_reference':True,'relink_uses_cached_hashes':True,'relink_does_not_assign_counters':True}
c.write_json(out/'audit.json',result)
print(json.dumps(result,indent=2))
