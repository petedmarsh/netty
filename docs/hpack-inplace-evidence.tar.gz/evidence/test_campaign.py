"""Offline tests only; never execute Java or builds."""
import csv
import itertools
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import campaign as c


def manifest():
    return c.load(Path(__file__).parent / 'input.template.json')


class Tests(unittest.TestCase):
    def test_schedule(self):
        jobs = c.schedule(manifest())
        self.assertEqual(len(jobs), 384)
        self.assertEqual(len({j['id'] for j in jobs}), 384)
        self.assertEqual(sum(j['group'] == 'primary' for j in jobs), 324)
        self.assertEqual(sum(j['group'] == 'capacity' and j['cell'] != 'init' for j in jobs), 48)
        self.assertEqual(sum(j['group'] == 'capacity' and j['cell'] == 'init' for j in jobs), 12)
        for cell in {j['cell'] for j in jobs if j['group'] == 'primary'}:
            orders = [tuple(j['version'] for j in jobs if j['group'] == 'primary' and j['cell'] == cell and j['round'] == r) for r in range(1, 7)]
            self.assertEqual(set(orders), set(itertools.permutations(c.VERSIONS)))
        capacity = [j for j in jobs if j['group'] == 'capacity']
        self.assertTrue(all(j['size'] == 65536 and j['version'] != 'upstream' for j in capacity))
        firsts = []
        for cell in {j['cell'] for j in capacity}:
            orders = [[j['version'] for j in capacity if j['cell'] == cell and j['round'] == r] for r in range(1, 7 if cell == 'init' else 4)]
            self.assertTrue(all(a == b[::-1] for a, b in zip(orders, orders[1:])))
            firsts.extend(x[0] for x in orders)
        self.assertEqual(firsts.count('replacement'), firsts.count('inplace'))

    def test_parser(self):
        job = c.schedule(manifest())[0]
        data = dict(benchmark=job['benchmark'], params=job['params'], forks=1,
                    measurementIterations=5, warmupIterations=5, mode='avgt', threads=1,
                    warmupTime='1 s', measurementTime='1 s', warmupBatchSize=1, measurementBatchSize=1,
                    primaryMetric=dict(scoreUnit='ns/op', rawData=[[10, 11, 12, 13, 14]]),
                    secondaryMetrics={'·gc.alloc.rate.norm': dict(scoreUnit='B/op', rawData=[[1, 2, 3, 4, 5]])})
        with tempfile.TemporaryDirectory() as tmp, patch.object(c, 'ROOT', Path(tmp)):
            (Path(tmp) / 'raw').mkdir()
            p = Path(tmp) / 'raw' / (job['id'] + '.json')
            p.write_text(json.dumps([data]))
            self.assertEqual(c.parse(job), {'ns': 12, 'bytes': 3})
            data['params'] = {}
            p.write_text(json.dumps([data]))
            with self.assertRaises(ValueError):
                c.parse(job)

    def test_analysis(self):
        jobs = c.schedule(manifest())
        vals = {'upstream': 10, 'replacement': 20, 'inplace': 15}
        with tempfile.TemporaryDirectory() as tmp, patch.object(c, 'ROOT', Path(tmp)), \
                patch.object(c, 'verify_freeze', return_value=jobs), patch.object(c, 'digest', return_value='h'), \
                patch.object(c, 'parse', side_effect=lambda j: {'ns': vals[j['version']] + j['round'], 'bytes': 0}):
            events = []
            for j in jobs:
                events.extend([dict(id=j['id'], event='started'), dict(id=j['id'], event='process-finished', returncode=0,
                    outputs={str(Path(tmp) / 'raw' / (j['id'] + ext)): 'h' for ext in ('.json', '.log')}), dict(id=j['id'], event='parsed')])
            c.write_json(Path(tmp) / 'readiness.json', {'wire_rows': [{'cell': 'example'}]})
            with patch.object(c, 'ledger', return_value=(events, 'hash')):
                c.report()
            with (Path(tmp) / 'comparisons.csv').open() as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(len(rows), 18 * 3 * 2 + 9 * 2)
            for row in rows:
                if row['metric'] == 'bytes':
                    self.assertEqual(row['percent_delta'], 'undefined')
                else:
                    expected = 10 if row['comparison'].startswith('replacement') else 5 if 'upstream' in row['comparison'] else -5
                    self.assertEqual(float(row['paired_delta']), expected)
                    self.assertEqual(float(row['ci95_low']), expected)
                    self.assertEqual(float(row['ci95_high']), expected)

    def test_refuse_go(self):
        with patch.object(c.subprocess, 'run') as run:
            with self.assertRaises(ValueError):
                c.run(False)
            run.assert_not_called()

    def test_failed_and_orphan_never_rerun(self):
        m = manifest()
        job = c.schedule(m)[0]
        for state in ('started', 'parser-failed', 'orphan'):
            with tempfile.TemporaryDirectory() as tmp, patch.object(c, 'ROOT', Path(tmp)), \
                    patch.object(c, 'verify_freeze', return_value=[job]), patch.object(c, 'config', return_value=m), \
                    patch.object(c, 'ledger', return_value=([] if state == 'orphan' else [dict(id=job['id'], event=state)], 'h')), \
                    patch.object(c.subprocess, 'run') as run:
                if state == 'orphan':
                    (Path(tmp) / 'raw').mkdir()
                    (Path(tmp) / 'raw' / (job['id'] + '.log')).write_text('preserve')
                with self.assertRaises(ValueError):
                    c.run(True)
                run.assert_not_called()

    def test_competitors_only(self):
        self.assertEqual(c.competing_jvms('1 bazel.server.Main\n2 io.netty.HpackProbe\n3 sun.tools.jps.Jps'), [])
        self.assertEqual(len(c.competing_jvms('4 org.openjdk.jmh.runner.ForkedMain\n5 /tmp/benchmarks.jar')), 2)

    def test_ledger_integrity(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(c, 'ROOT', Path(tmp)):
            (Path(tmp) / 'freeze.json').write_text('{}')
            c.record(event='started', id='test')
            c.record(event='parser-failed', id='test')
            self.assertEqual(len(c.ledger()[0]), 2)
            p = Path(tmp) / 'ledger.jsonl'
            p.write_text(p.read_text().replace('parser-failed', 'parsed'))
            with self.assertRaises(ValueError):
                c.ledger()

    def test_templates_fail_closed(self):
        with self.assertRaises((KeyError, FileNotFoundError, ValueError)):
            c.inventory(manifest())


if __name__ == '__main__':
    unittest.main()
