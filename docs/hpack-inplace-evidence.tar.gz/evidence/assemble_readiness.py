"""Assemble readiness from completed raw proof. Does not authorize review/freeze/run."""
import re
import campaign as c
R=c.ROOT;r=c.load(R/'readiness.template.json');m=c.config()
for key in r:
 if isinstance(r[key],bool) and key!='reviewed_by_main':r[key]=True
r['wire_rows']=c.load(R/'runtime-proof-v2/wire-rows.json')
r['runtime_proof']={}
for v in c.VERSIONS:
 text=(R/('runtime-proof-v2/'+v+'-runtime.log')).read_text()
 p=re.search(r'PUBLIC initialDefault=(\d+) requested=(\d+) actual=(\d+) rootSame=(\w+)',text);assert p
 assert 'PASS RuntimeProof '+v in text
 r['runtime_proof'][v]=dict(initial_default=int(p[1]),requested=int(p[2]),actual=int(p[3]),root_same=p[4]=='true',initialization_4k='INITIALIZATION requested=4096 actual=4096 supported=true' in text,initialization_64k_supported='INITIALIZATION requested=65536 actual=65536 supported=true' in text)
 if v!='upstream':
  t=(R/('runtime-proof-v2/'+v+'-retention.log')).read_text();values=re.findall(r'RETENTION distinct=(false|true) retained_bytes=(\d+) entries=(\d+) bucketEntries=(\d+) maxChain=(\d+) indexedReplays=(\d+) maxDynamicIndex=(\d+)',t);assert len(values)==2
  for x in values:assert int(x[1])>=60000 and int(x[4])<=16 and x[2]==x[3]==x[5]
  r['retention'][v]=dict(configured_size=65536,retained_bytes=int(values[0][1]),public_wrapper=True,distributions=[dict(zip(['distinct','retained_bytes','entries','bucket_entries','max_chain','indexed_replays','max_dynamic_index'],[x[0]=='true']+list(map(int,x[1:])))) for x in values])
r['growth_snapshots']=[]
text=(R/'runtime-proof-v2/inplace-runtime.log').read_text()
for populated in [False,True]:
 line=next(x for x in text.splitlines() if x.startswith('GROWTH populated='+str(populated).lower()))
 assert 'rootSame=true namesSame=false pairsSame=false' in line and 'cachedHashCounterSame=true fifoSame=true' in line
 values={k:int(v) for k,v in re.findall(r'(retainedBytes|entries|nameNodes|pairNodes)=(\d+)',line)}
 r['growth_snapshots'].append(dict(populated=populated,root_same=True,names_same=False,pairs_same=False,before_buckets=64,after_buckets=1024,cached_hash_counter_same=True,fifo_same=True,high_water_arrays_same=True,retained_bytes=values['retainedBytes'],entries=values['entries'],name_nodes=values['nameNodes'],pair_nodes=values['pairNodes']))
r['layout']=dict(encoder_bytes=72,reachable_graph_bytes=2160,objects=13,root='actual HpackEncoder reference from public wrapper',allocation_B_per_op=False)
r['evidence']=[]
def add(p,kind):r['evidence'].append(dict(kind=kind,path=str(p),sha256=c.digest(p)))
for dirname,kind in [('runtime-proof','tests'),('runtime-proof-v2','wire'),('source-proof','build-provenance'),('actual-root-layout','tests')]:
 for p in sorted((R/dirname).rglob('*')):
  if p.is_file():add(p,kind)
for name,kind in [('HANDOFF.md','handoff'),('candidate.patch','build-provenance'),('hash-verification.json','build-provenance'),('focused.log','tests'),('full-paranoid.log','tests'),('package.log','build-provenance'),('runtime-proof-v2/inplace-retention.log','retention')]:
 if not any(e['path']==str(R/name) for e in r['evidence']):add(R/name,kind)
# Retention logs also occur in wire inventory: preserve one entry/path, distinct kind.
for e in r['evidence']:
 if e['path'].endswith('-retention.log'):e['kind']='retention'
for pattern in ['*.java','*.class','layout-*.log','layout-agent.jar','*MANIFEST.MF','readiness-execution*.log','source-audit.log','*-validation.log']:
 for p in sorted(R.glob(pattern)):
  if not any(e['path']==str(p) for e in r['evidence']):add(p,'tests')
for name in ['run_readiness.py','audit_readiness.py','assemble_readiness.py','test_readiness.py']:
 add(R/name,'tests')
c.write_json(R/'readiness.json',r)
print('Assembled',len(r['evidence']),'hashed evidence entries; main review remains false')
