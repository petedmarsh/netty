package io.netty.handler.codec.http2;
import io.netty.buffer.*;
import java.lang.reflect.*;
import java.security.MessageDigest;
import java.util.Random;
public final class RuntimeReadinessProbe {
 static Object field(Object o,String n) throws Exception { Class<?> c=o.getClass(); while(c!=null){try {Field f=c.getDeclaredField(n); f.setAccessible(true); return f.get(o);}catch(NoSuchFieldException e){c=c.getSuperclass();}} throw new NoSuchFieldException(n); }
 static long number(Object o,String n) throws Exception { Method m=o.getClass().getDeclaredMethod(n);m.setAccessible(true);return ((Number)m.invoke(o)).longValue(); }
 static void check(boolean b) {if(!b)throw new AssertionError();}
 public static void main(String[] a) throws Exception {
  if(a[0].equals("synthetic")) {
   HpackStateBenchmark b=new HpackStateBenchmark(); b.tableSize=Integer.parseInt(a[1]); b.scenario=HpackStateBenchmark.Scenario.valueOf(a[2]);
   try { b.setup(); MessageDigest hash=MessageDigest.getInstance("SHA-256"); long bytes=0; int blocks=0;
    for(ByteBuf w:(ByteBuf[])field(b,"wire")){int n=w.writerIndex(); bytes+=n; blocks++; for(int s=24;s>=0;s-=8)hash.update((byte)(n>>>s)); byte[] data=new byte[n];w.getBytes(0,data);hash.update(data);}
    for(int i=0;i<4096;i++)b.encode();
    System.out.println("SUMMARY "+bytes+" "+ByteBufUtil.hexDump(hash.digest())+" "+blocks+" "+((DefaultHttp2HeadersEncoder)field(b,"encoder")).configuration().maxHeaderTableSize());
   } finally {b.tearDown();} return;
  }
  for(boolean distinct:new boolean[]{false,true}) {
   DefaultHttp2HeadersEncoder e=new DefaultHttp2HeadersEncoder(); DefaultHttp2HeadersDecoder d=new DefaultHttp2HeadersDecoder(); ByteBuf out=Unpooled.buffer();
   try {e.configuration().maxHeaderTableSize(65536);d.configuration().maxHeaderTableSize(65536);check(e.configuration().maxHeaderTableSize()==65536);
    Random r=new Random(194); Http2Headers[] hs=new Http2Headers[1120];long expected=0;
    for(int i=0;i<hs.length;i++){String t=Long.toHexString(r.nextLong()),n=distinct?"x-field-"+t:"x-retained",v=distinct?"v1":t; expected+=32+n.length()+v.length();hs[i]=new DefaultHttp2Headers().add(n,v);e.encodeHeaders(3,hs[i],out);check(hs[i].equals(d.decodeHeaders(3,out)));out.clear();}
    Object table=field(e,"hpackEncoder");check(number(table,"size")==expected && expected>=60000 && expected<=65536);check(number(table,"length")==1120);
    int maxChain=0,total=0;for(Object bucket:(Object[])field(table,"nameValueEntries")){int chain=0;for(Object x=bucket;x!=null;x=field(x,"next")){chain++;total++;} maxChain=Math.max(maxChain,chain);}check(maxChain<=16);check(total==number(table,"length"));
    int indexed=0;for(Http2Headers h:hs){e.encodeHeaders(3,h,out);check((out.getUnsignedByte(0)&128)==128 && out.readableBytes()<=3);check(h.equals(d.decodeHeaders(3,out)));out.clear();indexed++;}check(number(table,"size")==expected);
    System.out.println("RETENTION distinct="+distinct+" retained_bytes="+number(table,"size")+" entries="+number(table,"length")+" bucketEntries="+total+" maxChain="+maxChain+" indexedReplays="+indexed+" maxDynamicIndex="+(61+number(table,"length")));
   } finally {out.release();e.close();}
  }
 }
}
