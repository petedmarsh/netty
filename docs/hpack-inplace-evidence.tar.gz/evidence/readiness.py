"""Offline freeze gates. No builds, probes, or benchmark launches."""
import hashlib
import re
import subprocess
import zipfile
from pathlib import Path
import campaign as c


def verify_identity(m):
    ident = m['candidate_identity']
    repo = Path(ident['repo'])
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    c.require(head == ident['head'] == m['stages']['inplace']['commit'], 'Candidate HEAD changed')
    patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--'] + ident['patch_paths'], cwd=repo)
    c.require(hashlib.sha256(patch).hexdigest() == ident['patch_sha256'], 'Protected production/test/benchmark patch changed')
    c.require(c.digest(ident['patch']) == ident['patch_sha256'], 'Saved patch mismatch')
    protected = ident['protected_sources']
    c.require(protected and len({x['path'] for x in protected}) == len(protected), 'Explicit protected-source inventory required')
    c.require(any(x['path'].endswith('/HpackEncoder.java') for x in protected), 'Encoder source missing')
    c.require(any(x['path'].endswith('/DefaultHttp2HeadersEncoder.java') for x in protected), 'Public wrapper missing')
    c.require(any(x['path'].endswith('/HpackEncoderTest.java') for x in protected), 'Encoder tests missing')
    for x in protected:
        c.require(c.digest(x['path']) == x['sha256'], 'Protected source changed: ' + x['path'])


def inventory(m, require_main_review=True):
    r = c.ROOT
    ready = c.load(r / 'readiness.json')
    if require_main_review:
        c.require(ready['reviewed_by_main'] is True, 'Main must review readiness')
    c.require(ready['fixtures_unchanged'] is True, 'Fixtures must be unchanged')
    verify_identity(m)
    runtime = ready['runtime_proof']
    for v in c.VERSIONS:
        p = runtime[v]
        c.require(p['initial_default'] == 4096 and p['requested'] == 65536 and
                  p['actual'] == (4096 if v == 'upstream' else 65536), 'Runtime getter capacity mismatch')
        c.require(p['initialization_4k'] and p['initialization_64k_supported'] == (v != 'upstream'),
                  'Initialization support mismatch')
    for p in ready['growth_snapshots']:
        c.require(p['root_same'] and not p['names_same'] and not p['pairs_same'] and
                  p['before_buckets'] == 64 and p['after_buckets'] == 1024 and
                  p['cached_hash_counter_same'] and p['fifo_same'] and p['high_water_arrays_same'],
                  'In-place identity/cached hash/counter proof missing')
    c.require([p['populated'] for p in ready['growth_snapshots']] == [False, True], 'Empty and populated proofs required')
    c.require(ready['growth_snapshots'][1]['pair_nodes'] == 50 and
              ready['growth_snapshots'][1]['name_nodes'] == 10, 'Populated node evidence missing')
    paths = [r / name for name in ['campaign.py', 'readiness.py', 'test_campaign.py', 'PLAN.md',
             'input.json', 'input.template.json', 'readiness.json', 'readiness.template.json', 'ReadinessProbe.java']]
    paths += [Path(m['java']), Path(m['jps']), Path(m['candidate_identity']['patch'])]
    paths += [Path(x['path']) for x in m['candidate_identity']['protected_sources']]
    original_root = r.parent / 'hpack-series-evidence'
    original = c.load(original_root / 'input.json')
    original_freeze = c.load(original_root / 'freeze.json')
    paths.append(original_root / 'freeze.json')
    for p, h in original_freeze['files'].items():
        c.require(c.digest(p) == h, 'Original frozen artifact changed: ' + p)
        paths.append(Path(p))
    sources = m['shared_sources']
    c.require({s['name'] for s in sources} == {s['name'] for s in original['shared_sources']}, 'Original six fixtures required')
    c.require(len(sources) == 6 and sum(bool(s['public_wrapper']) for s in sources) >= 1, 'Six shared fixtures/public wrapper required')
    for s in sources:
        old = next(x for x in original['shared_sources'] if x['name'] == s['name'])
        c.require(s['sha256'] == old['sha256'] and s['class_entries'] == old['class_entries'], 'Original fixture identity changed')
        files = [Path(s['paths'][v]) for v in c.VERSIONS]
        c.require(all(c.digest(p) == s['sha256'] for p in files), 'Shared source differs: ' + s['name'])
        paths += files
        c.require(s['class_entries'], 'Class inventory missing')
        stem = s['name'].removesuffix('.java')
        inventories = []
        for v in c.VERSIONS:
            with zipfile.ZipFile(m['stages'][v]['jar']) as z:
                entries = sorted(n for n in z.namelist() if n.endswith('.class') and
                                 (n.split('/')[-1].split('$')[0] == stem + '.class' or
                                  n.split('/')[-1].startswith(stem + '$') or
                                  '/jmh_generated/' in n and n.split('/')[-1].startswith(stem + '_')))
                c.require(entries == sorted(s['class_entries']), 'Incomplete fixture classes: ' + stem)
                inventories.append({n: hashlib.sha256(z.read(n)).hexdigest() for n in entries})
        c.require(inventories[0] == inventories[1] == inventories[2], 'Fixture bytecode mismatch')
    for v in c.VERSIONS:
        stage = m['stages'][v]
        c.require(re.fullmatch('[0-9a-f]{40}', stage['commit']), 'Full commit required')
        c.require(c.digest(stage['jar']) == stage['sha256'], 'Jar hash mismatch')
        paths.append(Path(stage['jar']))
    c.require(m['stages']['upstream']['commit'] == '3eaff63caf06a582cc3df72422aa1124734b46c6', 'Wrong upstream')
    for v, old in [('upstream', 'baseline'), ('replacement', 'stage3')]:
        c.require(all(m['stages'][v][k] == original['stages'][old][k] for k in ['jar', 'sha256', 'commit']), 'Original artifact identity changed')
    paths.append(r.parent / 'hpack-series-evidence/input.json')
    evidence = ready['evidence']
    c.require({e['kind'] for e in evidence} >= {'build-provenance', 'wire', 'retention', 'tests', 'handoff'}, 'Missing evidence')
    for e in evidence:
        c.require(c.digest(e['path']) == e['sha256'], 'Evidence hash mismatch')
        paths.append(Path(e['path']))
    for flag in ['public_probe_verified', 'candidate_jar_matches_sources', 'protected_source_list_reviewed',
                 'collision_bound_verified', 'index_limit_verified', 'populated_late_settings_tests_passed']:
        c.require(ready[flag] is True, 'Missing readiness: ' + flag)
    browser, synth, _ = c.cells(m)
    c.require(len(ready['wire_rows']) == 67, 'Exactly 67 wire rows required')
    for size, versions, cells in [(4096, c.VERSIONS, browser + synth), (65536, c.VERSIONS[1:], browser)]:
        for cell in cells:
            rows = []
            for v in versions:
                found = [x for x in ready['wire_rows'] if (x['version'], x['cell'], x['size']) == (v, cell['id'], size)]
                c.require(len(found) == 1, 'Missing/duplicate exact-wire row')
                x = found[0]
                c.require(x['actual_size'] == x['requested_size'] == size and x['wire_bytes'] > 0 and
                          re.fullmatch('[0-9a-f]{64}', x['wire_sha256']), 'Invalid/clamped wire row')
                rows.append((x['wire_sha256'], x['wire_bytes']))
            c.require(len(set(rows)) == 1, 'Exact wire differs')
    for v in c.VERSIONS[1:]:
        p = ready['retention'][v]
        c.require(p['configured_size'] == 65536 and 60000 <= p['retained_bytes'] <= 65536 and
                  p['public_wrapper'] is True, 'Near-64K public retention not demonstrated')
    return {str(p.resolve()): c.digest(p) for p in paths}
