"""Formal offline assertions over the completed raw functional proof; no JVMs."""
import unittest
from pathlib import Path
from unittest.mock import patch
import campaign as c
import readiness

class RuntimeEvidenceTests(unittest.TestCase):
 def test_empty_populated_identity_and_cached_counters(self):
  log=(c.ROOT/'runtime-proof-v2/inplace-runtime.log').read_text()
  for populated, counts in [('false','retainedBytes=0 entries=0 nameNodes=0 pairNodes=0'),('true','retainedBytes=2240 entries=50 nameNodes=10 pairNodes=50')]:
   line=next(x for x in log.splitlines() if x.startswith('GROWTH populated='+populated))
   for text in ['rootSame=true namesSame=false pairsSame=false','nameBuckets=64->1024 pairBuckets=64->1024', counts,'cachedHashCounterSame=true fifoSame=true voidSetter=true finalWrapper=true']:self.assertIn(text,line)
   self.assertIn('HIGH_WATER populated='+populated+' namesSame=true pairsSame=true',log)
 def test_unsupported_baseline_explicit(self):
  text=(c.ROOT/'runtime-proof-v2/upstream-runtime.log').read_text()
  self.assertIn('requested=65536 actual=4096',text)
  self.assertIn('EXPECTED_REJECTION',text)
  self.assertIn('PASS RuntimeProof upstream',text)
 def test_retention_both_distributions_both_versions(self):
  for version in ['replacement','inplace']:
   text=(c.ROOT/('runtime-proof-v2/'+version+'-retention.log')).read_text()
   self.assertEqual(text.count('retained_bytes=64887 entries=1120 bucketEntries=1120 maxChain=7 indexedReplays=1120 maxDynamicIndex=1181'),2)
 def test_actual_root_layout_not_allocation(self):
  for version in c.VERSIONS:
   text=(c.ROOT/('actual-root-layout/'+version+'-opened.log')).read_text()
   self.assertIn('root=actual-public-wrapper-hpackEncoder (not wrapper graph; not allocation/op)',text)
   self.assertIn('encoder=72 graph=2160 objects=13',text)
 def test_source_only_patch_scope(self):
  m=c.config()
  with patch.object(readiness.subprocess,'check_output',side_effect=[m['candidate_identity']['head']+'\n',Path(m['candidate_identity']['patch']).read_bytes()]) as call:
   readiness.verify_identity(m)
   self.assertEqual(call.call_args.args[0],['git','diff','--binary','HEAD','--','codec-http2/src/main','codec-http2/src/test','microbench/src/main'])
 def test_main_review_stays_separate(self):
  self.assertFalse(c.load(c.ROOT/'readiness.json')['reviewed_by_main'])
  with self.assertRaisesRegex(ValueError,'Main must review'):
   readiness.inventory(c.config())

if __name__=='__main__':unittest.main()
