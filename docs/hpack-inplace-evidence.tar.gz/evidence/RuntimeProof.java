package io.netty.handler.codec.http2;
import io.netty.buffer.*;
import java.lang.reflect.*;
import java.util.*;
/** Functional assertions only, no timing. Private implementation accessed reflectively. */
public final class RuntimeProof {
 static Object f(Object o,String n)throws Exception{return RuntimeReadinessProbe.field(o,n);}
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
 static long num(Object o,String n)throws Exception{return RuntimeReadinessProbe.number(o,n);}
 static Set<Object> nodes(Object array)throws Exception {Set<Object>s=Collections.newSetFromMap(new IdentityHashMap<Object,Boolean>());for(Object b:(Object[])array)for(Object e=b;e!=null;e=f(e,"next"))check(s.add(e),"cycle");return s;}
 static String state(Object e)throws Exception {StringBuilder s=new StringBuilder();for(String n:new String[]{"hash","counter"})s.append(n).append('=').append(f(e,n)).append(';');return s.toString();}
 static void growth(boolean populated)throws Exception {
  DefaultHttp2HeadersEncoder e=new DefaultHttp2HeadersEncoder();ByteBuf out=Unpooled.buffer();
  try {
   Object root=f(e,"hpackEncoder");
   if(populated)for(int i=0;i<50;i++){e.encodeHeaders(3,new DefaultHttp2Headers().add("x-proof-"+(i%10),"v-"+i),out);out.clear();}
   Object names=f(root,"nameEntries"),pairs=f(root,"nameValueEntries");
   Set<Object> ns=nodes(names),ps=nodes(pairs);Map<Object,String> states=new IdentityHashMap<>();for(Object n:ns)states.put(n,state(n));for(Object p:ps)states.put(p,state(p));
   Object head=f(root,"head"),latest=f(root,"latest");Map<Object,Object> fifo=new IdentityHashMap<>();fifo.put(head,f(head,"after"));for(Object p:ps)fifo.put(p,f(p,"after"));
   long bytes=num(root,"size"),entries=num(root,"length");
   e.configuration().maxHeaderTableSize(65536);
   check(root==f(e,"hpackEncoder"),"root changed");check(names!=f(root,"nameEntries")&&pairs!=f(root,"nameValueEntries"),"arrays not replaced");
   check(((Object[])f(root,"nameEntries")).length==1024&&((Object[])f(root,"nameValueEntries")).length==1024,"buckets");
   check(ns.equals(nodes(f(root,"nameEntries")))&&ps.equals(nodes(f(root,"nameValueEntries"))),"node identities");
   for(Map.Entry<Object,String>x:states.entrySet())check(x.getValue().equals(state(x.getKey())),"cached hash/counter changed");
   for(Map.Entry<Object,Object>x:fifo.entrySet())check(x.getValue()==f(x.getKey(),"after"),"fifo changed");
   check(head==f(root,"head")&&latest==f(root,"latest"),"head/latest changed");
   check(bytes==num(root,"size")&&entries==num(root,"length"),"counts changed");
   Method setter=root.getClass().getDeclaredMethod("setMaxHeaderTableSize",long.class);check(setter.getReturnType()==void.class,"setter not void");
   check(Modifier.isFinal(e.getClass().getDeclaredField("hpackEncoder").getModifiers()),"wrapper reference not final");
   System.out.println("GROWTH populated="+populated+" rootSame=true namesSame=false pairsSame=false nameBuckets="+((Object[])names).length+"->1024 pairBuckets="+((Object[])pairs).length+"->1024 retainedBytes="+bytes+" entries="+entries+" nameNodes="+ns.size()+" pairNodes="+ps.size()+" cachedHashCounterSame=true fifoSame=true voidSetter=true finalWrapper=true");
   names=f(root,"nameEntries");pairs=f(root,"nameValueEntries");e.configuration().maxHeaderTableSize(0);e.configuration().maxHeaderTableSize(65536);check(names==f(root,"nameEntries")&&pairs==f(root,"nameValueEntries"),"high-water reuse");
   System.out.println("HIGH_WATER populated="+populated+" namesSame=true pairsSame=true");
  }finally{out.release();e.close();}
 }
 public static void main(String[] args)throws Exception {
  boolean inplace=args[0].equals("inplace"),up=args[0].equals("upstream");
  DefaultHttp2HeadersEncoder e=new DefaultHttp2HeadersEncoder();try{Object before=f(e,"hpackEncoder");check(e.configuration().maxHeaderTableSize()==4096,"default");e.configuration().maxHeaderTableSize(65536);long actual=e.configuration().maxHeaderTableSize();check(actual==(up?4096:65536),"capacity");System.out.println("PUBLIC initialDefault=4096 requested=65536 actual="+actual+" rootSame="+(before==f(e,"hpackEncoder"))+" supported="+!up);}finally{e.close();}
  for(int requested:new int[]{4096,65536}){HpackInitializationBenchmark b=new HpackInitializationBenchmark();b.tableSize=requested;if(up&&requested==65536){try{b.setup();throw new AssertionError("unsupported initialization accepted");}catch(IllegalArgumentException expected){check(expected.getMessage().contains("clamped to 4096"),"unexpected init failure");System.out.println("INITIALIZATION requested=65536 actual=4096 supported=false EXPECTED_REJECTION "+expected.getMessage());}continue;}b.setup();Object value=b.encoder();try{DefaultHttp2HeadersEncoder enc=(DefaultHttp2HeadersEncoder)value;long actual=enc.configuration().maxHeaderTableSize();check(actual==(up?4096:requested),"init capacity");System.out.println("INITIALIZATION requested="+requested+" actual="+actual+" supported="+(actual==requested));}finally{((DefaultHttp2HeadersEncoder)value).close();}}
  if(inplace){growth(false);growth(true);}
  System.out.println("PASS RuntimeProof "+args[0]);
 }
}
