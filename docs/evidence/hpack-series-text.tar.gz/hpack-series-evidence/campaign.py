#!/usr/bin/env python3
"""Preparation is safe: generate/freeze/report never launch a benchmark or build."""
import argparse
import csv
import datetime
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
VERSIONS = ['baseline', 'stage1', 'stage2', 'stage3']
ORDERS = ['ABCD', 'DCBA', 'BCDA', 'ADCB', 'CDAB', 'BADC']
SYNTH = ['REPEATED', 'WORKING_SET', 'MIXED', 'CHURN', 'NAME_HIT', 'COLLISION', 'STATIC', 'SENSITIVE', 'HUFFMAN']
CAP = ['WORKING_SET128', 'WORKING_SET384', 'WORKING_SET', 'WORKING_SET768', 'CHURN', 'COLLISION']

def require(ok, message):
    if not ok:
        raise ValueError(message)

def load(p):
    return json.loads(Path(p).read_text())

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def encoded(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()

def write_json(p, obj):
    Path(p).write_text(json.dumps(obj, indent=2) + '\n')

def config():
    return load(ROOT / 'input.json')

def cells(m):
    browser = m['browser_cases']
    require(len(browser) == 8, 'Exactly eight browser cells required')
    synthetic = [dict(id='synthetic-' + s, benchmark=m['synthetic_benchmark'],
                      params={'scenario': s, 'growThenShrink': 'false'}) for s in SYNTH]
    init = dict(id='init', benchmark=m['init_benchmark'], params={})
    require(len({c['id'] for c in browser + synthetic + [init]}) == 18, 'Duplicate cell IDs')
    require(all(re.fullmatch(r'[\w-]+', c['id']) for c in browser + synthetic), 'Unsafe cell ID')
    return browser, synthetic, init

def schedule(m):
    browser, synthetic, init = cells(m)
    require(m['init_rounds'] in (3, 6), 'init_rounds must be 3 or 6')
    out = []
    def add(group, cell, r, v, size):
        ident = f'{group}-{cell["id"]}-r{r}-{v}-{size}'
        params = dict(cell['params'], tableSize=str(size))
        target = ROOT / 'raw' / (ident + '.json')
        argv = [m['java'], '-jar', m['stages'][v]['jar'], '^' + re.escape(cell['benchmark']) + '$']
        for k, value in sorted(params.items()):
            argv += ['-p', f'{k}={value}']
        argv += ['-f', '1', '-wi', '5', '-w', '1s', '-i', '5', '-r', '1s', '-t', '1',
                 '-bm', 'avgt', '-tu', 'ns', '-prof', 'gc', '-foe', 'true',
                 '-jvmArgs', '-Xms512m -Xmx512m', '-rf', 'json', '-rff', str(target)]
        out.append(dict(id=ident, group=group, cell=cell['id'], round=r, version=v,
                        size=size, benchmark=cell['benchmark'], params=params, argv=argv))
    primary = browser + synthetic + [init]
    for r in range(1, 7):
        indices = list(range(18))
        indices = indices[r-1:] + indices[:r-1]
        for i in indices:
            if i == 17 and r > m['init_rounds']:
                continue
            for letter in ORDERS[(r-1+i) % 6]:
                add('primary', primary[i], r, VERSIONS[ord(letter)-ord('A')], 4096)
    extra = browser + [dict(id='synthetic-' + s, benchmark=m['synthetic_benchmark'],
                           params={'scenario': s, 'growThenShrink': 'false'}) for s in CAP]
    for r in range(1, 4):
        for i in list(range(r-1, 14)) + list(range(r-1)):
            for size in ([4096, 65536] if (r+i) % 2 else [65536, 4096]):
                add('capacity', extra[i], r, 'stage3', size)
    require(len(out) == (516 if m['init_rounds'] == 6 else 504), 'Wrong fork count')
    require(len({x['id'] for x in out}) == len(out), 'Duplicate fork IDs')
    return out

def inventory(m, require_main_review=True):
    paths = [ROOT / x for x in ['PLAN.md', 'README-runner.md', 'campaign.py', 'test_campaign.py', 'input.json', 'readiness.json', 'ReadinessProbe.java', 'readiness_probes.py', 'audit_readiness.py']]
    paths += [Path(m['java']), Path(m['jps'])]
    ready = load(ROOT / 'readiness.json')
    if require_main_review:
        require(ready['reviewed_by_main'] is True, 'Main must review evidence')
    require(ready['fixtures_unchanged'] is True, 'Fixture changes prohibited')
    require(len(m['shared_sources']) == 6 and any(s['public_wrapper'] for s in m['shared_sources']), 'Six sources including public wrapper required')
    for s in m['shared_sources']:
        files = [Path(s['paths'][v]) for v in VERSIONS]
        require(len({digest(p) for p in files}) == 1, 'Shared source mismatch: ' + s['name'])
        require(s['class_entries'], 'Missing complete class inventory')
        paths += files
        for entry in s['class_entries']:
            hashes = []
            for v in VERSIONS:
                with zipfile.ZipFile(m['stages'][v]['jar']) as z:
                    hashes.append(hashlib.sha256(z.read(entry)).hexdigest())
            require(len(set(hashes)) == 1, 'Shared class mismatch: ' + entry)
    for i, v in enumerate(VERSIONS):
        stage = m['stages'][v]
        require(re.fullmatch('[0-9a-f]{40}', stage['commit']), 'Full commit SHA required')
        require(i != 0 or stage['commit'].startswith('3eaff'), 'Wrong baseline')
        if i:
            require(stage['parent'] == m['stages'][VERSIONS[i-1]]['commit'], 'Noncumulative parent')
        require(digest(stage['jar']) == stage['sha256'], 'Jar hash mismatch')
        paths.append(Path(stage['jar']))
    for e in ready['evidence']:
        require(digest(e['path']) == e['sha256'], 'Evidence hash mismatch')
        paths.append(Path(e['path']))
    require({e['kind'] for e in ready['evidence']} >= {'build-provenance', 'wire', 'unsupported-64k', 'stage3-runtime', 'stage3-tests'}, 'Missing evidence kinds')
    browser, synthetic, _ = cells(m)
    wire = ready['wire_rows']
    def row(v, cell, size):
        found = [x for x in wire if (x['version'], x['cell'], x['size']) == (v, cell, size)]
        require(len(found) == 1, f'Missing/duplicate wire row {v}/{cell}/{size}')
        x = found[0]
        require(re.fullmatch('[0-9a-f]{64}', x['wire_sha256']) and x['wire_bytes'] > 0, 'Invalid wire row')
        require(x['requested_size'] == size and x['actual_size'] == size, 'Runtime clamp in supported case')
        return x
    for c in browser + synthetic:
        rows = [row(v, c['id'], 4096) for v in VERSIONS]
        require(len({(x['wire_sha256'], x['wire_bytes']) for x in rows}) == 1, '4K exact-wire mismatch')
    for c in browser + [dict(id='synthetic-' + s) for s in CAP]:
        for size in (4096, 65536):
            row('stage3', c['id'], size)
    for v in VERSIONS[:3]:
        p = ready['unsupported_64k'][v]
        require(p['requested_size'] == 65536 and
                (p['guard_asserted'] is True or 0 <= p['actual_size'] < 65536), 'Missing unsupported runtime guard/clamp')
    p = ready['stage3_retention']
    require(p['configured_size'] == 65536 and 60000 <= p['retained_bytes'] <= 65536, 'Near-64K retention not demonstrated')
    require(all(p[k] is True for k in ['runtime_verified', 'test_verified', 'collision_bound_verified', 'index_limit_verified', 'state_counters_verified']), 'Incomplete stage3 checks')
    return {str(p.resolve()): digest(p) for p in paths}

def freeze():
    require(not (ROOT / 'freeze.json').exists(), 'Freeze already exists; never overwrite')
    m = config()
    inv = inventory(m)
    jobs = schedule(m)
    write_json(ROOT / 'schedule.json', jobs)
    inv[str(ROOT / 'schedule.json')] = digest(ROOT / 'schedule.json')
    write_json(ROOT / 'freeze.json', dict(files=inv, schedule_sha256=hashlib.sha256(encoded(jobs)).hexdigest()))

def verify_freeze():
    f = load(ROOT / 'freeze.json')
    for p, h in f['files'].items():
        require(digest(p) == h, 'Frozen artifact changed: ' + p)
    jobs = load(ROOT / 'schedule.json')
    require(hashlib.sha256(encoded(jobs)).hexdigest() == f['schedule_sha256'], 'Schedule mismatch')
    return jobs

def parse(job):
    data = load(ROOT / 'raw' / (job['id'] + '.json'))
    require(len(data) == 1, 'Expected exactly one JMH result')
    d = data[0]
    require(d['benchmark'] == job['benchmark'] and d['params'] == job['params'], 'Wrong benchmark/params')
    require(d['forks'] == 1 and d['measurementIterations'] == 5 and d['warmupIterations'] == 5, 'Wrong JMH configuration')
    secondary = {k.replace('\u00b7', '').split(':')[-1].strip(): v for k, v in d['secondaryMetrics'].items()}
    result = {}
    for name, metric, unit in [('ns', d['primaryMetric'], 'ns/op'), ('bytes', secondary['gc.alloc.rate.norm'], 'B/op')]:
        raw = metric['rawData']
        require(metric['scoreUnit'] == unit and len(raw) == 1 and len(raw[0]) == 5, 'Wrong units/raw shape')
        require(all(math.isfinite(x) for x in raw[0]), 'Nonfinite result')
        result[name] = statistics.mean(raw[0])
    return result

def ledger():
    p = ROOT / 'ledger.jsonl'
    rows = []
    previous = digest(ROOT / 'freeze.json')
    if p.exists():
        for line in p.read_text().splitlines():
            event = json.loads(line)
            h = event.pop('hash')
            require(event['previous'] == previous and hashlib.sha256(encoded(event)).hexdigest() == h, 'Broken ledger chain')
            event['hash'] = h
            rows.append(event)
            previous = h
    return rows, previous

def record(**event):
    _, previous = ledger()
    event['previous'] = previous
    event['timestamp_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    event['hash'] = hashlib.sha256(encoded(event)).hexdigest()
    with (ROOT / 'ledger.jsonl').open('a') as f:
        f.write(json.dumps(event) + '\n')
        f.flush()
        os.fsync(f.fileno())

def competing_jvms(output):
    # jps -l only: never collect VM arguments, which may contain credentials.
    return [line for line in output.splitlines()
            if re.search(r'hpack|jmh|ForkedMain|microbenchmarks?\.jar|benchmarks\.jar', line, re.I)]


def run(go):
    require(go, 'Explicit --main-go required; main-session authorization first')
    with (ROOT / 'runner.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        jobs = verify_freeze()
        m = config()
        (ROOT / 'raw').mkdir(exist_ok=True)
        for job in jobs:
            verify_freeze()
            events, _ = ledger()
            prior = [e for e in events if e.get('id') == job['id']]
            if prior:
                for e in prior:
                    for p, h in e.get('outputs', {}).items():
                        require(digest(p) == h, 'Raw output changed')
                require(prior[-1]['event'] == 'parsed', 'Interrupted/failed/parser-failed case: manual investigation required; never auto rerun')
                continue
            target = ROOT / 'raw' / (job['id'] + '.json')
            log = target.with_suffix('.log')
            require(not target.exists() and not log.exists(), 'Orphan output; never overwrite')
            check = subprocess.run([m['jps'], '-l'], capture_output=True, text=True)
            competitors = competing_jvms(check.stdout)
            record(event='preflight', job_id=job['id'], jps=check.stdout, stderr=check.stderr,
                   returncode=check.returncode, competitors=competitors, host='shared-not-isolated')
            require(check.returncode == 0, 'jps failed; preflight preserved')
            require(not competitors, 'Competing HPACK/JMH JVM detected: ' + '\n'.join(competitors))
            record(event='started', id=job['id'], argv=job['argv'], host='shared-not-isolated')
            with log.open('xb') as f:
                proc = subprocess.run(job['argv'], stdout=f, stderr=subprocess.STDOUT, cwd=ROOT)
            outputs = {str(p): digest(p) for p in [log, target] if p.exists()}
            record(event='process-finished', id=job['id'], returncode=proc.returncode, outputs=outputs)
            require(proc.returncode == 0, 'Process failed; preserved, no retry')
            try:
                values = parse(job)
            except Exception as exc:
                record(event='parser-failed', id=job['id'], error=str(exc))
                raise
            record(event='parsed', id=job['id'], values=values)

def report():
    jobs = verify_freeze()
    events, _ = ledger()
    values = {}
    for j in jobs:
        done = [e for e in events if e.get('id') == j['id'] and e['event'] == 'process-finished']
        require(len(done) == 1 and done[0]['returncode'] == 0, 'Incomplete/failed campaign: ' + j['id'])
        for p, h in done[0]['outputs'].items():
            require(digest(p) == h, 'Changed raw result')
        values[j['id']] = parse(j)  # Offline reparsing never launches JVMs.
    with (ROOT / 'raw-forks.csv').open('w') as f:
        w = csv.writer(f)
        w.writerow(['group', 'cell', 'round', 'version', 'size', 'ns/op', 'B/op'])
        for j in jobs:
            v = values[j['id']]
            w.writerow([j[k] for k in ['group', 'cell', 'round', 'version', 'size']] + [v['ns'], v['bytes']])
    comparisons = [('stage1', 'baseline'), ('stage2', 'baseline'), ('stage3', 'baseline'), ('stage2', 'stage1'), ('stage3', 'stage2')]
    rows = []
    for group in ['primary', 'capacity']:
        for cell in sorted({j['cell'] for j in jobs if j['group'] == group}):
            subset = [j for j in jobs if j['group'] == group and j['cell'] == cell]
            index = {(j['round'], j['version'], j['size']): values[j['id']] for j in subset}
            rounds = sorted({j['round'] for j in subset})
            for candidate, reference in (comparisons if group == 'primary' else [('stage3', 'stage3')]):
                cs, rs = (4096, 4096) if group == 'primary' else (65536, 4096)
                for metric in ['ns', 'bytes']:
                    a = [index[r, candidate, cs][metric] for r in rounds]
                    b = [index[r, reference, rs][metric] for r in rounds]
                    diff = [x-y for x, y in zip(a, b)]
                    mean = statistics.mean(diff)
                    half = {3: 4.30265273, 6: 2.57058184}[len(diff)] * statistics.stdev(diff) / math.sqrt(len(diff))
                    ref = statistics.mean(b)
                    rows.append([group, cell, f'{candidate}/{cs} - {reference}/{rs}', metric, len(diff), statistics.mean(a), ref, mean, mean-half, mean+half, 100*mean/ref if ref else 'undefined'])
    with (ROOT / 'comparisons.csv').open('w') as f:
        w = csv.writer(f)
        w.writerow(['group', 'cell', 'comparison', 'metric', 'pairs', 'candidate_mean', 'reference_mean', 'paired_delta', 'ci95_low', 'ci95_high', 'percent_delta'])
        w.writerows(rows)
    write_json(ROOT / 'summary.json', dict(forks=len(jobs), host='shared-not-isolated',
               comparisons=rows, comparison_columns=['group', 'cell', 'comparison', 'metric', 'pairs',
               'candidate_mean', 'reference_mean', 'paired_delta', 'ci95_low', 'ci95_high', 'percent_delta']))
    wire = load(ROOT / 'readiness.json')['wire_rows']
    with (ROOT / 'wire.csv').open('w') as f:
        w = csv.DictWriter(f, fieldnames=sorted(set().union(*(r.keys() for r in wire))))
        w.writeheader()
        w.writerows(wire)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['generate', 'validate', 'freeze', 'run', 'report'])
    parser.add_argument('--main-go', action='store_true')
    args = parser.parse_args()
    if args.action == 'generate':
        require(not (ROOT / 'freeze.json').exists(), 'Already frozen')
        jobs = schedule(config())
        write_json(ROOT / 'schedule.preview.json', jobs)
        print(f'{len(jobs)} forks; estimated {len(jobs)*10.7/60:.1f} minutes plus validation/variable overhead; NO execution')
    elif args.action == 'validate':
        inv = inventory(config(), require_main_review=False)
        print(f'PASS {len(inv)} immutable inputs; readiness verified; main review/GO separate')
    elif args.action == 'freeze':
        freeze()
    elif args.action == 'run':
        run(args.main_go)
    else:
        report()

if __name__ == '__main__':
    main()
