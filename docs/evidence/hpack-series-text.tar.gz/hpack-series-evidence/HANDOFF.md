# HPACK incremental series — ready for timing

Review checkout: `/Users/pmarsh/src/netty/.worktrees/hpack-series`
Branch: `perf/hpack-64k-series` (clean)
Evidence root: `/Users/pmarsh/src/netty/.worktrees/hpack-series-evidence`
Preserved old branch: `perf/hpack-64k-browser` at `95c9eb3d06fa02f34c17cc356964f7b2cda53476`.
Main checkout and its untracked reports were not changed. No push, PR, JMH timing run, or report commit.

| Stage | Exact commit | Focused tests | Full HTTP/2 tests | Public/custom limit after requesting 64K |
|---|---|---:|---:|---|
| 0 baseline | `3eaff63caf06a582cc3df72422aa1124734b46c6` | 115 | 1631 | 4096 / 8192 |
| 1 replacement-aware API | `76b8b0b72f156d5524ac9a5317f22f8563d107c6` | 116 | 1632 | 4096 / 8192 |
| 2 pre-eviction admission defense | `5a9c64318d3489f11042971014f2398614c32548` | 122 | 1638 | 4096 / 8192 |
| 3 immutable cold growth | `ec00a0f50d989f9c53b30256d93e8f0dcaf1983d` | 147 | 1663 | 65536 / 65536 |

All listed test runs have zero failures/errors. Full suites have five existing skips; focused suites have none. Stages 1–3 full runs use paranoid leak detection and creation stacks. Final full suite was rerun after restoring the final branch; see `step3/final-confirmation.log`. “Full” means the entire HTTP/2 test package, not every Netty module. The initial baseline whole-reactor test attempt exceeded the bounded 480-second command limit in unrelated handler/SSL tests; retained as `step0/reactor-timeout.log`. Baseline full HTTP/2 passed separately. Stage1 initially reported a possible resource leak in Http2MultiplexTransportTest; its initial failure log is retained, and the full diagnostic rerun passed without production/test workarounds.

## Frozen runnable jars

Paths below are relative to the evidence root:

| Jar | SHA-256 |
|---|---|
| `step0/benchmarks.jar` | `d93ebee32b357c9e098a2bd14b67ae8564ad8404786e079dd9f9187557bd7f64` |
| `step1/benchmarks.jar` | `22710d234a9f53adf7ac4b19762625b8ee885ea5c20ee328bcaf63ad90ca2ca2` |
| `step2/benchmarks.jar` | `eee38ba5c7bfdc737d797e9e8bc15c306406e25a76139c2247871bdcb25f59af` |
| `step3/benchmarks.jar` | `05b85e9356d19d978c799dfe594072aae569d1027f31c6a4fbe5ac915172bfcd` |

All stages were packaged sequentially before the next commit. The original evidence-copy command mistakenly selected the thin module jar, not Maven's runnable `microbench/target/microbenchmarks.jar`. The baseline/final runnable artifacts were recovered directly from their unchanged build targets. Stages1/2 were clean-packaged again from their exact detached commits, sequentially, to recover their runnable jars; see `package-frozen.log`. Original thin middle-stage artifacts are explicitly named `thin-benchmarks.jar` and are NOT timing inputs. No benchmarks ran against either artifact type.

Independent verification confirms:
- All six benchmark Java sources match `95c9eb3d06` and each other at every stage, including baseline's fixture-only overlay.
- All packaged HTTP/2 benchmark classes (including JMH generated classes) and HpackDecoder classes match across all four runnable jars.
- Each runnable jar contains JMH Main; a separate Java probe loads each jar and checks the public default, configured public/custom limits, immutable bucket array and bucket count.
- Stage3's packaged HpackEncoder and DefaultHttp2HeadersEncoder classes match freshly recompiled final checkout classes byte-for-byte.
- The final production tree is identical to `95c9eb3d06`: no clarity changes and no round5 miss helper. Only additional tests differ from that reference: six standalone 8K admission tests and one no-growth identity test.

## Evidence and reproduction

`stages.json` is the machine-readable handoff, including exact latest report directories (repeated early copies created nested report directories; use the recorded paths). Every stage includes logs, source snapshots, source hashes, complete cumulative patches, commit metadata, jar hashes, fixture-class hashes and runtime-limit results. Precommit `source.patch`/`status.txt` are historical working-state observations; `from-base.patch`, committed `sources/`, and `commit.txt` describe the frozen committed state. Stage0 deliberately has fixture changes only.

Run `python3 verify.py` from this directory to recheck artifacts, source hashes, shared fixture/class identities and runtime limits without building or timing. `RuntimeLimits.java` and `probe-classes/` are external audit artifacts, not production code.

Build environment: Homebrew OpenJDK21 (`/opt/homebrew/opt/openjdk@21`), repository `./mvnw`, `-Pbenchmark-jar,!mac`. The devex `mvn` shim has no underlying executable. New writes to the default Maven repository were denied, so `m2/` is a persistent APFS copy of the dependency cache; use `MAVEN_OPTS=-Dmaven.repo.local=/Users/pmarsh/src/netty/.worktrees/hpack-series-evidence/m2`. `build-stage.sh` records reproducible focused/full/package commands. Benchmark packaging uses `-DskipTests` only after both test suites pass; no test/check failures were bypassed.

Next: run the controlled timing matrix against these frozen jars. Restrict cross-stage comparisons to supported limits; baseline/stages1–2 clamp default encoders at4K and custom128-bucket encoders at8K. 64K is supported only by stage3. Keep future HTML/documentation in a separate explicitly non-runtime commit.
