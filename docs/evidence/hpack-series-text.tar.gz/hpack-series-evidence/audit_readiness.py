"""Offline report audit and readiness assembly; never grants main review."""
import xml.etree.ElementTree as E
from pathlib import Path
import campaign as c
m=c.config(); audit={}; evidence=[]
def add(kind,p):
 p=Path(p).resolve();evidence.append(dict(kind=kind,path=str(p),sha256=c.digest(p)))
for v,s in m['stages'].items():
 audit[v]={}
 for kind,d in s['report_paths'].items():
  files=list(Path(d).glob('TEST-*.xml')); assert files
  if kind=='focused':
   files=[f for f in files if f.name.startswith('TEST-io.netty.handler.codec.http2.Hpack') or f.name=='TEST-io.netty.handler.codec.http2.DefaultHttp2HeadersEncoderTest.xml']
  totals={k:0 for k in ('tests','failures','errors','skipped')}; names=[]
  for f in files:
   root=E.parse(f).getroot()
   for k in totals: totals[k]+=int(root.get(k,0))
   names.extend(x.get('name') for x in root.findall('testcase'))
   add('stage3-tests' if v=='stage3' else 'build-provenance',f)
  assert totals==s['tests'][kind],(v,kind,totals,s['tests'][kind])
  audit[v][kind]=dict(totals=totals,test_names=names)
 add('build-provenance',s['source_hashes']);add('build-provenance',s['build_log']);add('unsupported-64k' if v!='stage3' else 'stage3-runtime',s['runtime_evidence'])
c.write_json(c.ROOT/'readiness-test-audit.json',audit)
for kind,p in [('build-provenance','runner-handoff.json'),('build-provenance','readiness-identity.log'),('stage3-tests','readiness-test-audit.json'),('stage3-runtime','readiness-retention.log'),('wire','readiness-probes/commands.json'),('wire','readiness-probes/wire-rows.json')]:add(kind,c.ROOT/p)
for p in (c.ROOT/'readiness-probes').glob('*.log'):add('wire',p)
r=c.load(c.ROOT/'readiness.json');r.update(fixtures_unchanged=True,evidence=evidence,wire_rows=c.load(c.ROOT/'readiness-probes/wire-rows.json'))
r['unsupported_64k']={v:dict(requested_size=65536,actual_size=4096,guard_asserted=False) for v in c.VERSIONS[:3]}
r['stage3_retention']=dict(configured_size=65536,retained_bytes=64887,runtime_verified=True,test_verified=True,collision_bound_verified=True,index_limit_verified=True,state_counters_verified=True)
r['reviewed_by_main']=False
c.write_json(c.ROOT/'readiness.json',r)
print('XML totals verified; evidence',len(evidence))
