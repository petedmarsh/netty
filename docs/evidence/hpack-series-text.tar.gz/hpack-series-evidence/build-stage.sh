#!/bin/bash
set -euo pipefail
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
export PATH="$JAVA_HOME/bin:$PATH"
export MAVEN_OPTS="-Dmaven.repo.local=/Users/pmarsh/src/netty/.worktrees/hpack-series-evidence/m2"
stage=$1
root=/Users/pmarsh/src/netty/.worktrees
out=$root/hpack-series-evidence/$stage
mkdir -p "$out"
git rev-parse HEAD > "$out/commit.txt"
git diff > "$out/source.patch"
git status --short > "$out/status.txt"
./mvnw -B -pl codec-http2 -am -Dtest='Hpack*Test,DefaultHttp2HeadersEncoderTest' -Dsurefire.failIfNoSpecifiedTests=false test > "$out/focused.log" 2>&1
mkdir -p "$out/focused-reports"
cp -R codec-http2/target/surefire-reports/. "$out/focused-reports/"
./mvnw -B -pl codec-http2 -am -Dio.netty.leakDetection.level=paranoid -Dio.netty.util.LeakPresenceDetector.trackCreationStack=true -Dtest='io.netty.handler.codec.http2.*Test' -Dsurefire.failIfNoSpecifiedTests=false test > "$out/full.log" 2>&1
mkdir -p "$out/full-reports"
cp -R codec-http2/target/surefire-reports/. "$out/full-reports/"
./mvnw -B -pl microbench -am -Pbenchmark-jar,!mac -DskipTests package > "$out/package.log" 2>&1
cp microbench/target/microbenchmarks.jar "$out/benchmarks.jar"
shasum -a 256 "$out/benchmarks.jar" > "$out/jar.sha256"
git diff --binary 3eaff63caf > "$out/from-base.patch"
git ls-files '*Hpack*Benchmark.java' | while read -r f; do shasum -a 256 "$f"; done > "$out/benchmark-sources.sha256"
echo COMPLETE > "$out/COMPLETE"
