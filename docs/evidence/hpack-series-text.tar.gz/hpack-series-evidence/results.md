# Staged HPACK: final data audit and results

## Outcome and scope

**Evidence audit PASS; requested incremental branch constructed, not acceptance of a new optimization.** This task only audits existing measurements and adds evidence documentation. No new timing, production changes, commit or push. The shared host does **not** establish universal 4K parity: none of the 90 primary timing comparisons excludes zero, but several estimates and intervals are large. Failure to detect a difference is not equivalence.

| Stage / commit | Faithful commit summary | Capacity and interpretation |
|---|---|---|
| Baseline `3eaff63caf06` | Existing “Reject Redis lines that start with LF (#17793)” base; identical benchmark fixture overlay | Production unchanged; public 4K, existing custom 128-bucket 8K |
| 1 `76b8b0b72f15` | “Prepare HPACK configuration for encoder replacement”: return and retain configured encoder | No capacity increase or storage change; compare with baseline (also parent) |
| 2 `5a9c64318d34` | “Bound admission to large HPACK collision chains before eviction” | Protect existing custom 8K policy: pair/new-name chain limit 16, existing/static-name exemptions; rejection before eviction. No capacity increase; shared public-wrapper timings remain 4K, not an 8K policy benchmark |
| 3 `ec00a0f50d98` | “Grow immutable HPACK buckets on configuration up to 64 KiB” | Cold-path replacement/copy with independently owned nodes; preserve protocol state, pending minimum update, configuration/counters and final arrays. Public/custom configured 64K supported; default still 4K |

**Final production exactly matches `95c9eb3d06fa02f34c17cc356964f7b2cda53476`, source-only proof:** `git diff 95c9eb3d06 perf/hpack-64k-series -- '*/src/main/**'` is empty. This does not claim commit/tree or build-output identity with that reference: tests and historical docs/archives differ. No new miss-helper tuning was introduced by this audit.

## Integrity and methodology

- 516 scheduled forks = 432 primary (18 cells × 4 versions × 6 rounds) + 84 capacity (14 cells × 2 sizes × 3 rounds). Every fork has **five measured iterations: 2,580 total** (plus five warmups/fork). `summary.json` correctly says `forks: 516`; it has **no measured-iterations field**. The 2,580 count was independently checked in raw JSON, not inferred from a mislabeled summary count.
- All 2,064 chained ledger events match schedule order exactly: preflight → started → process-finished → parsed for each fork; exit 0 throughout, correct command lines, no missing/duplicate/failed/orphan jobs. All 1,032 raw JSON/log files match ledger hashes; exact directory-set equality shows no orphan output files. All 407 freeze-indexed files and the canonical schedule digest pass.
- All 516 cases reparsed with frozen parser: exact benchmark/params, units, 1 fork, 5 warmups/measurements, finite five-sample timing and allocation arrays, matching ledger and CSV values. All 208 comparison rows and every summary comparison match. Independent calculations from `raw-forks.csv` reproduce means, paired deltas, percentages and CIs (within 1e-6 absolute / 1e-7 relative tolerance); Student-t quantiles were separately obtained by numerical density integration, not the runner's constants.
- CI unit is the **paired fork mean**, not 30/15 independent iteration samples: six pairs at 4K (df=5), three capacity pairs (df=2). 95% intervals are pointwise, unadjusted for multiple comparisons; lower ns/op and allocated B/op are better. Allocation is **not wire bytes**. Values below are rounded; full-precision raw and comparison CSVs remain unchanged.
- `final-verification.log`: source/jar hashes, all six common fixture sources, packaged benchmark/generated and decoder classes, and runtime limits reverified; eight offline runner tests pass. Existing frozen test evidence records focused 115/116/122/147 and full HTTP/2 1631/1632/1638/1663, zero failures/errors, five existing full-suite skips. These suites were not rerun in this audit. Readiness evidence records all 17 primary wire cases identical across stages at 4K, 85 total wire rows including capacity/extra working sets, and near-capacity retention/roundtrip checks; frozen hashes protect those prior checks.
- Shared, non-isolated host; unrelated Bazel JVMs permitted. Every recorded preflight had no HPACK/JMH competitor; current `jps -l` likewise showed none. This is not proof of CPU isolation or absence of all external load. No campaign reruns or cherry-picked fork exclusions.

Freeze SHA-256: `6f8ea62d29339823fa8296a7bb26317f9507e336b1cb369d3f0c105f92c2a6a8`.
Ledger final hash: `8b6a823c2a16486663ebdf31e9c9d05c67c9068b36569227f7a3b05be0d77609`.
Campaign UTC: `2026-10-15T08:51:07.193344+00:00` through `2026-10-15T10:23:33.993221+00:00`.
Machine audit: [final-audit.json](final-audit.json). Original evidence remains unchanged.

## 4K browser, synthetic and initialization

Each entry is **ns/op / allocated B/op**, mean of six fork means. Browser names: new/persistent connection session; N=Normal, A=Authenticated; I=INDEX_COOKIES, V=NEVER; splitCookies=true. WS=WORKING_SET512. All means use the primary cohort only.

| Case | Unchanged baseline | Stage 1 | Stage 2 | Stage 3 |
|---|---:|---:|---:|---:|
| new/A/I | 676.57 / 135.75 | 740.56 / 159.75 | 800.30 / 151.75 | 707.53 / 151.75 |
| new/A/V | 718.17 / 133.88 | 714.52 / 125.88 | 717.75 / 133.88 | 724.62 / 133.88 |
| new/N/I | 528.11 / 138.13 | 515.35 / 130.13 | 529.53 / 138.13 | 525.87 / 138.13 |
| new/N/V | 545.74 / 134.38 | 537.17 / 134.38 | 546.35 / 134.38 | 526.17 / 126.38 |
| persistent/A/I | 715.95 / 131.02 | 719.24 / 139.02 | 657.20 / 131.02 | 639.92 / 123.02 |
| persistent/A/V | 806.70 / 119.63 | 812.39 / 119.63 | 795.54 / 111.63 | 807.19 / 119.63 |
| persistent/N/I | 625.25 / 122.69 | 637.80 / 114.69 | 604.71 / 114.69 | 606.89 / 114.69 |
| persistent/N/V | 618.12 / 118.00 | 625.54 / 118.00 | 596.88 / 110.00 | 625.95 / 118.00 |
| init | 67.80 / 768.00 | 56.71 / 768.00 | 39.08 / 768.00 | 57.21 / 768.00 |
| CHURN | 1560.87 / 336.00 | 1912.70 / 336.00 | 1653.25 / 336.00 | 1506.17 / 336.00 |
| COLLISION | 1330.43 / 168.00 | 1338.21 / 176.00 | 1158.58 / 176.00 | 1130.36 / 176.00 |
| HUFFMAN | 3854.23 / 208.00 | 3881.03 / 208.00 | 3832.81 / 208.00 | 3917.38 / 208.00 |
| MIXED | 577.22 / 208.00 | 626.32 / 208.00 | 613.41 / 208.00 | 560.16 / 208.00 |
| NAME_HIT | 1330.74 / 208.00 | 1370.40 / 208.00 | 959.39 / 208.00 | 962.38 / 208.00 |
| REPEATED | 54.31 / 32.00 | 50.47 / 24.00 | 63.17 / 44.00 | 54.03 / 40.00 |
| SENSITIVE | 60.95 / 48.00 | 102.20 / 40.00 | 57.72 / 32.00 | 61.43 / 40.00 |
| STATIC | 228.25 / 48.00 | 134.75 / 48.00 | 96.37 / 48.00 | 137.55 / 48.00 |
| WS | 883.76 / 208.00 | 903.39 / 208.00 | 883.72 / 208.00 | 842.12 / 208.00 |

**Every per-stage vs baseline and vs parent delta/CI:** [results-details.md](results-details.md) (90 paired rows, both ns and B); [comparisons.csv](comparisons.csv) contains full precision. Stage 1 vs parent is the baseline comparison, not a separate experiment.

### 4K per-step anomalies, not a parity guarantee

- Stage 1 vs baseline: browser timing estimates range −2.42% to +9.46%; all eight CIs include zero. Synthetic SENSITIVE +67.67%, STATIC −40.96%, CHURN +22.54% illustrate unstable point estimates, not established improvements/regressions.
- Stage 2 vs baseline: browser −8.21% to +18.29%; vs stage 1 −8.63% to +8.07%. All include zero. Initialization is −42.36% vs baseline and −31.09% vs parent; NAME_HIT −27.91% vs baseline; none significant pointwise.
- Stage 3 vs baseline: browser −10.62% to +4.58%; vs stage 2 −11.59% to +4.87%. All include zero. Initialization +46.39% and STATIC +42.74% vs parent look concerning as estimates, but their CIs also cross zero. Do not silently call these all parity.
- **No pointwise significant 4K timing regression or improvement**, and no meaningful demonstrated allocation change. The sole primary allocation CI excluding zero is stage3 CHURN vs baseline: −0.0000639208 B/op [−0.0001268703, −0.0000009712], about −0.000019%; too small to call a practical optimization. Browser allocation means vary in roughly 8-byte increments across cohorts with wide paired intervals; this campaign does not identify the cause.

## Stage 3 capacity only: 64K vs its own 4K

Separate three-pair cohort; **never compare these 64K values with a fictitious baseline/stage1/stage2 64K**. Those public encoders clamp to 4K (custom constructor to 8K). Capacity-cohort 4K means differ from primary-cohort means: use their own paired reference, not pooled or substituted primary values. WS without suffix means 512.

Entries: reference → candidate mean; Δ [95% CI].

| Case | ns/op, 4K → 64K | Δ ns/op [CI] | B/op, 4K → 64K | Δ B/op [CI] |
|---|---:|---:|---:|---:|
| new/A/I | 577.63 → 537.25 | -40.38 [-184.42, 103.66] | 127.75 → 230.13 | 102.37 [-16.40, 221.15] |
| new/A/V | 663.90 → 603.95 | -59.95 [-288.35, 168.45] | 133.88 → 225.75 | 91.87 [23.57, 160.18] |
| new/N/I | 473.03 → 427.61 | -45.43 [-85.87, -4.98] | 138.13 → 242.25 | 104.12 [35.82, 172.43] |
| new/N/V | 495.99 → 450.80 | -45.19 [-124.40, 34.01] | 134.38 → 256.25 | 121.87 [121.87, 121.88] |
| persistent/A/I | 663.03 → 523.80 | -139.23 [-169.02, -109.44] | 139.02 → 0.000212 | -139.02 [-139.02, -139.02] |
| persistent/A/V | 662.48 → 602.69 | -59.79 [-254.31, 134.73] | 119.63 → 16.00 | -103.63 [-172.47, -34.78] |
| persistent/N/I | 504.30 → 373.39 | -130.91 [-137.08, -124.74] | 122.69 → 0.000151 | -122.69 [-122.69, -122.69] |
| persistent/N/V | 536.16 → 453.84 | -82.32 [-157.95, -6.69] | 118.00 → 48.00 | -70.00 [-70.00, -70.00] |
| CHURN | 1529.89 → 147.51 | -1382.39 [-1459.79, -1304.98] | 336.00 → 48.00 | -288.00 [-288.00, -288.00] |
| COLLISION | 1069.12 → 271.36 | -797.76 [-1089.17, -506.35] | 176.00 → 48.00 | -128.00 [-196.84, -59.16] |
| WS | 819.07 → 131.26 | -687.81 [-784.13, -591.49] | 208.00 → 48.00 | -160.00 [-160.00, -160.00] |
| WS128 | 513.86 → 103.96 | -409.90 [-502.41, -317.40] | 208.00 → 48.00 | -160.00 [-160.00, -160.00] |
| WS384 | 759.23 → 129.23 | -630.00 [-707.99, -552.01] | 208.00 → 48.00 | -160.00 [-160.00, -160.00] |
| WS768 | 901.60 → 131.98 | -769.62 [-792.99, -746.24] | 208.00 → 48.00 | -160.00 [-160.00, -160.00] |

**Pointwise capacity findings:** 10/14 timing CIs exclude zero, all improvements: new N/I −9.60%; persistent A/I −21.00%, N/I −25.96%, N/V −15.35%; CHURN −90.36%, COLLISION −74.62%, WS128/384/512/768 −79.77/−82.98/−83.97/−85.36%. The other four browser timing intervals cross zero; no significant timing regression was observed.

Allocation tradeoff is real in this cohort: new A/V **+91.875 B/op**, new N/I **+104.125 B/op**, new N/V **+121.875 B/op** have positive CIs (regressions). All four persistent browser and all six synthetic capacity cases have negative allocation CIs (improvements). New A/I allocation is inconclusive. These are capacity/configuration tradeoffs, not evidence that stage 3 accelerates unchanged 4K workloads.

## Disposition

The user-requested staged construction and its evidence are complete. Performance acceptance of a new optimization is **not** asserted. Keep shared-host uncertainty, pointwise multiplicity and new-connection allocation costs attached to these results. Historical anomalies remain preserved: baseline whole-reactor timeout in unrelated SSL/handler tests, initial stage1 possible leak followed by passing diagnostic rerun, and initial thin-jar selection corrected before timing. No timing fork used a thin jar. No frozen files were edited by this final audit.
