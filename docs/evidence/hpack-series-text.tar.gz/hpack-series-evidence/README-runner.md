# Staged HPACK campaign readiness handoff

Readiness/probes completed; NO timing forks launched. Main review and explicit GO remain separate gates. All paths in input.json are absolute frozen stage snapshots from runner-handoff.json, not live build targets. No production source edits, commits or pushes in this readiness task.

## Exact matrix

Eight browser **encode** cells: persistentSession/newConnectionSession × NORMAL/AUTHENTICATED × NEVER/INDEX_COOKIES, splitCookies=true, tableSize=4096. Earlier README encode/decode wording was wrong. Nine synthetic encode cells; initialization encoder six rounds. Default remains **516 forks** (432 primary +84 capacity). Capacity: eight browser + WORKING_SET128/384/512/768, CHURN, COLLISION, stage3 only at4096/65536, three paired rounds. WORKING_SET means512.

Six shared source records: Browser, State, Initialization, Util, Encoder, Decoder. `public_wrapper=true` on Browser means **this benchmark uses DefaultHttp2HeadersEncoder's public wrapper API**, NOT that its source is the production wrapper implementation or that other fixtures never use public APIs. Complete packaged class inventories include generated/nested classes.

## Proof

- readiness-identity.log: verify.py validated jar hashes, source hashes, six shared fixture sources, packaged benchmark/decoder classes and runtime configured limits for all stages.
- readiness-test-audit.json: XML counts agree with handoff: focused115/116/122/147, full1631/1632/1638/1663; zero failures/errors; full five skips each. Focused directories include historical unrelated reports: audit filters the exact build selector, uses direct XML only, not nested historical copies.
- readiness-probes/commands.json: sequential readiness commands, exit status, immutable log hashes. Browser manifests retain every exact block; independently rehashed 4-byte big-endian length followed by wire bytes. Synthetic probe hashes captured steady-state2048 blocks with identical framing, validates setup/replay and exercises encode outside timing.
- readiness-probes/wire-rows.json:85 unique rows. All17 primary cells match byte-for-byte at4K across four stages; all14 capacity cells pass at4K/64K stage3. Three additional4K synthetic working sets make85 total.
- readiness-retention.log: public default constructor configured64K, test fixture Random(194),1120 entries; actual64887 bytes for repeated and distinct names,1120 bucket entries, max value chain7,1120 indexed replays, maximum dynamic index1181. Public decoder roundtrips every insertion/replay. State occupancy equals independently summed HPACK sizes; replay preserves occupancy. Collision/index-limit adversarial coverage is also in indexed stage3 test XML/source snapshots.
- baseline/stage1/stage2 public64K requests actually clamp4096; custom128-bucket constructor clamps8192. Neither is supported64K. stage2_8k_supported=false for shared public-wrapper fixtures.
- readiness-offline-tests.log: offline schedule, order balance, middle-dot GC metric normalization, paired Student-t confidence intervals, report outputs, JVM competitor filter and no implicit timing checks.

The initial offline audit expected focused directories to contain only focused XML; its diagnostic is preserved in readiness-preflight-failures.log. No Java probe failed. Existing historical build/test failure logs are untouched.

## Readiness commands (no scores)

```
python3 campaign.py generate
python3 campaign.py validate
python3 -m unittest discover -s . -p test_campaign.py -v
```

`validate` checks actual evidence/identity without granting main approval. `readiness.json reviewed_by_main` remains false until main inspects this handoff. Only after that review, set it true and execute:

```
python3 campaign.py freeze
```

Freeze is one-shot and offline. Record freeze.json SHA256 at that point. Do not change frozen metadata, scripts, docs, source snapshots, jars or indexed evidence afterward. Analysis outputs (summary.json/CSVs), validation logs and this handoff's future external discussion must not be added as self-referential freeze inputs. readiness.json does not hash itself. Audit/probe source files are freeze inputs; compiled probes are not used during timing. Do not rerun audit assembly after approval: it deliberately resets reviewed_by_main=false.

## Only after explicit main-session GO

Working directory: /Users/pmarsh/src/netty/.worktrees/hpack-series-evidence

```
python3 campaign.py run --main-go
python3 campaign.py report
```

The flag acknowledges authorization; it does not grant it. Confirm all build/test/probe agents are done before running; do not overlap timing with builds/tests. Runner is foreground/parent-owned, no auto-background.

Host is **shared, not isolated**. Runner records `jps -l` only (no VM arguments), permits unrelated JVMs such as Bazel, refuses HPACK/JMH/ForkedMain/benchmark-jar competitors, never kills JVMs. Append-only chained preflight events preserve output, stderr, return code and competitor details even on refusal. Directory flock prevents concurrent same-directory runners, not external launch races. No CPU isolation is claimed.

Reports require every planned fork: raw-forks.csv, comparisons.csv (paired95% Student-t intervals), wire.csv, summary.json (structured comparisons and host disclosure). Original JMH JSON preserves five samples per fork. Parser middle-dot normalization is regression tested. Exit-zero parse failure preserves outputs and blocks automatic rerun; interrupted/nonzero forks also block automatic rerun. Fix later analysis separately without changing frozen runner inputs.
