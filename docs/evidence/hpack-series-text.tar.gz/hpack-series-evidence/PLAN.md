# Staged HPACK evidence — pre-score plan

Status: READINESS VERIFIED, main review/GO pending. User authorized lightweight correctness probes only; no timing forks. Baseline + three cumulative commits and frozen jars came from the completed build agent. Do not edit their code, fixtures, commits, or jars. input.json uses actual metadata and immutable snapshot paths. The parent session owns any eventual background runner; do not leave an idle worker.

## Matrix and budget

A=unchanged baseline commit 3eaff (record full SHA), B=stage1, C=stage2, D=stage3. All primary measurements use 4096 bytes: eight individually named browser cases, nine synthetic encode cases (REPEATED, WORKING_SET [512], MIXED, CHURN, NAME_HIT, COLLISION, STATIC, SENSITIVE, HUFFMAN), and encoder initialization. Default: all 18 cells × six rounds × four versions = **432 forks**. No user budget was supplied, so do not silently reduce coverage.

Additional stage3-only capacity comparison: the same eight browser cells × three paired rounds × {4096,65536} = 48 forks; six synthetic cells WORKING_SET128/384/512/768, CHURN, COLLISION × three paired rounds × two sizes = 36 forks. Total default **516 forks**, approximately **92 minutes** at 10.7 seconds/fork; minimum timed intervals 86 minutes, plus JVM startup, GC/profiling and validation overhead. This is an estimate, not a cutoff.

Explicit pre-freeze alternative: init_rounds=3 reduces primary to 420 and total to **504 forks (~90 minutes)**. That alternative sacrifices init precision only; document the decision before scores. The generator defaults to six initialization rounds. Neither alternative silently removes meaningful code stages or cases.

## Ordering and inference

Six primary four-version blocks are ABCD, DCBA, BCDA, ADCB, CDAB, BADC. Each rotation is paired with its reverse: directional pair ordering is balanced, but six blocks cannot perfectly balance four version positions (eight blocks would). Rotate case start position each round; rotate version-order selection by cell index to spread position imbalance. Keep each cell/round's four forks contiguous. Capacity pairs alternate 4K/64K and 64K/4K, with case-dependent alternation; three pairs cannot perfectly balance order. Analyze rounds as pairs, never five JMH iterations as independent forks.

Report each stage vs the same A AND vs its immediate parent: B−A, C−A, D−A, C−B, D−C (B−A serves both). Labels are explicit stage names, not arithmetic array indices. For each case report all raw fork ns/op and gc.alloc.rate.norm B/op, per-version means, paired mean difference with two-sided 95% Student-t CI (df=5, or df=2 for three rounds), plus percent difference relative to the reference mean. Positive means slower/more allocation. Capacity comparisons are D64K−D4K, separately labeled; never compare unsupported baseline 64K. CIs are descriptive, unadjusted for multiple comparisons; avoid win claims on noisy intervals.

## Readiness gates, BEFORE any timing

The code agent must supply full commit/parent provenance, artifact paths and SHA256, actual java/jps executables, exact selectors/parameters for eight browser cases, and six shared benchmark source inventories including the public wrapper. Source bytes must match across all four builds; class entries for those sources (including nested classes) must be inventoried and byte-identical in the frozen jars. Build provenance must establish those inventories are complete. Additional stage3 tests must not change shared fixtures. Freeze their evidence too.

readiness.json is a structured index of completed correctness evidence, not permission to run tests. Every evidence file path and hash is frozen. Require: all eight browser and nine synthetic 4K exact-wire SHA256 rows match across all four versions (persistent/new browser encode rows distinct; no browser decode timing cells); actual requested/retained table sizes from runtime probes; baseline/stage1/stage2 64K guard assertion or observed clamp before timing; stage3 65536 configured and actual near-64K retained bytes (>=60000) demonstrated by runtime and test evidence. Stage3 runtime evidence must include collision-chain bound, index-limit checks, and state counters; allocation B/op is not retained heap. Do not introduce new retained-heap claims. Include stage3 capacity-case wire rows for both sizes and report byte counts/hashes, without requiring equal hashes across sizes.

Stage2 custom 8K correctness probe is optional, supported=false by default. No major 8K timing matrix is included; any extension requires a new pre-score plan and freeze, never a mid-campaign opportunistic add-on.

## Execution contract (future, explicit main-session GO only)

1. Populate input.json and readiness.json from code-agent metadata/evidence. Readiness evidence must be reviewed by the main session; a boolean alone does not establish correctness.
2. `python3 campaign.py generate` writes the deterministic schedule/commands without executing them (works with the template placeholders).
3. After artifacts and correctness evidence exist, `python3 campaign.py freeze` validates them and freezes hashes for plan, scripts, manifest, readiness, source inventories, Java/jps executables, evidence and jars. It does not launch Java.
4. Only on explicit main-session authorization: `python3 campaign.py run --main-go`. The parent may own this long-running process. Sequential one-fork invocations, 5×1s warmup, 5×1s measurement, one thread, average-time ns/op, GC profiler, -Xms512m -Xmx512m. Exact argv logged before launch. Exclusive file lock plus jps -l before every fork; record no VM arguments, refuse only competing HPACK/JMH/ForkedMain/benchmark-jar processes. Unrelated Java such as Bazel is allowed; never kill user JVMs. Host is shared, not isolated. All build/test/probe agents must be done before timing; external launchers must coordinate because jps cannot atomically prevent another process starting afterward. Preserve preflight failures in the ledger.
5. `python3 campaign.py report` parses existing outputs only. No reruns. Preserve exit-zero results even when parsing fails, raw stdout, JSON, ledger, hashes and commands. A failed/interrupted process stops the campaign; do not drop it or silently retry. Investigate and predeclare recovery manually. Exit-zero/parser-failed rows can be reparsed offline after diagnosis; runner itself remains frozen.

The hash-bound append-only ledger records started/process-finished/parsed events and output hashes. Resume skips only verified parsed cases. Interrupted and failed cases block automatic continuation. A process that succeeded but whose parser failed is never run again automatically. Output parsing normalizes the JMH middle-dot secondary-metric prefix, validates exactly one result, five measurements in one fork, ns/op and B/op, and the expected benchmark/parameters. No fixture changes, production edits, commits or pushes are part of this task.
