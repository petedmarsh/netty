package io.netty.handler.codec.http2;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public final class RuntimeLimits {
    public static void main(String[] args) throws Exception {
        boolean grown = Boolean.parseBoolean(args[0]);
        DefaultHttp2HeadersEncoder wrapper = new DefaultHttp2HeadersEncoder();
        check(wrapper.maxHeaderTableSize() == 4096, "initial default");
        wrapper.maxHeaderTableSize(65536);
        long publicLimit = wrapper.maxHeaderTableSize();
        check(publicLimit == (grown ? 65536 : 4096), "public configured limit");
        HpackEncoder custom = new HpackEncoder(false, 128, HpackEncoder.HUFF_CODE_THRESHOLD);
        Method configure;
        try {
            configure = HpackEncoder.class.getDeclaredMethod("withMaxHeaderTableSize", long.class);
        } catch (NoSuchMethodException e) {
            configure = HpackEncoder.class.getDeclaredMethod("setMaxHeaderTableSize", long.class);
        }
        Object result = configure.invoke(custom, 65536L);
        if (result != null) {
            custom = (HpackEncoder) result;
        }
        long customLimit = custom.getMaxHeaderTableSize();
        check(customLimit == (grown ? 65536 : 8192), "custom configured limit");
        Field buckets = HpackEncoder.class.getDeclaredField("nameEntries");
        buckets.setAccessible(true);
        check(Modifier.isFinal(buckets.getModifiers()), "final buckets");
        int count = ((Object[]) buckets.get(custom)).length;
        check(count == (grown ? 1024 : 128), "custom bucket count");
        System.out.println("{\"initialDefault\":4096,\"publicAfter64K\":" + publicLimit
                + ",\"customAfter64K\":" + customLimit + ",\"customBuckets\":" + count + "}");
        wrapper.close();
    }

    private static void check(boolean condition, String label) {
        if (!condition) {
            throw new AssertionError(label);
        }
    }
}
