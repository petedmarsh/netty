"""Readiness only: no JMH timings; append-only command logs, exact wire manifests."""
import hashlib,json,re,subprocess
from pathlib import Path
import campaign as c
R=Path(__file__).resolve().parent
m=c.config(); out=R/'readiness-probes';out.mkdir(exist_ok=True)
rows=[];commands=[]
def run(name,args):
 p=out/(name+'.log')
 with p.open('x') as f:
  result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 commands.append(dict(argv=args,returncode=result.returncode,log=str(p),sha256=c.digest(p)))
 c.write_json(out/'commands.json',commands)
 c.require(result.returncode==0,'Probe failed; preserved '+str(p))
 return p.read_text()
def row(v,cell,size,h,n):
 rows.append(dict(version=v,cell=cell,size=size,requested_size=size,actual_size=size,wire_sha256=h,wire_bytes=int(n)))
for v in c.VERSIONS:
 jar=m['stages'][v]['jar']
 # JMH metadata listing is not a measurement run.
 run(v+'-metadata',[m['java'],'-jar',jar,'Hpack(Browser|State|Initialization)Benchmark','-lp'])
 for size in ([4096,65536] if v=='stage3' else [4096]):
  for workload in ['NORMAL','AUTHENTICATED']:
   for policy in ['NEVER','INDEX_COOKIES']:
    text=run(f'{v}-{size}-{workload}-{policy}',[m['java'],'-cp',jar,'io.netty.handler.codec.http2.HpackBrowserBenchmark',workload,policy,'true',str(size),'--manifest'])
    for mode,method in [('persistent','persistentSession'),('new','newConnectionSession')]:
     blocks=re.findall(r'^wire '+mode+r' .* bytes=(\d+) .* hex=([0-9a-f]+)$',text,re.M)
     h=hashlib.sha256();total=0
     for n,hexdata in blocks:
      data=bytes.fromhex(hexdata);assert len(data)==int(n);total+=len(data);h.update(len(data).to_bytes(4,'big'));h.update(data)
     summary=re.search(r'^summary '+mode+r' blocks=(\d+) bytes=(\d+) .* lengthDelimitedWireSha256=([0-9a-f]+)$',text,re.M)
     assert summary and int(summary[1])==len(blocks) and int(summary[2])==total and summary[3]==h.hexdigest()
     row(v,'browser-'+method+'-'+workload+'-'+policy,size,h.hexdigest(),total)
  scenarios=list(dict.fromkeys(c.SYNTH+c.CAP)) if v=='stage3' and size==4096 else c.CAP if size==65536 else c.SYNTH
  for scenario in scenarios:
   text=run(f'{v}-{size}-{scenario}',[m['java'],'-cp',str(R/'readiness-classes')+':'+jar,'io.netty.handler.codec.http2.ReadinessProbe','synthetic',str(size),scenario])
   match=re.search(r'SUMMARY (\d+) ([0-9a-f]{64}) 2048 (\d+)',text);assert match and int(match[3])==size
   row(v,'synthetic-'+scenario,size,match[2],match[1])
c.write_json(out/'wire-rows.json',rows)
print('PASS',len(rows),'wire rows;',len(commands),'readiness processes; no timings')
