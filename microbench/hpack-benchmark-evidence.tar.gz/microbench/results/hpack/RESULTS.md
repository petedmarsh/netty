# HPACK measured results

## Current source: linkedMixed64 retained — ring rejected on performance

Root is original iteration2 plus the exact measured one-line uniform-mixing change,
not ring. All 276 rebuilt codec classes match both measured linkedMixed jars.
Full HTTP/2: 1643 tests (five existing skips); paranoid HPACK: 125 tests;
zero failures/errors. No new timings or commit; previous evidence is preserved.
[Restoration, provenance and linkedMixed vs upstream](linkedMixed-retained/README.md).

**237 independent forks /1185 measurements completed** with identical benchmark
sources in five isolated reactor-built jars. That campaign did not change root;
the subsequent targeted restoration retained its linkedMixed candidate.
Full evidence and decision: [ring/README.md](ring/README.md),
[ring/ANALYSIS.md](ring/ANALYSIS.md).

Fair ringMixed versus linkedMixed at64 buckets isolates structure from hashing:
CHURN4096 **−10.10% [−17.79,−1.70]**, but REPEATED4096 **+23.10% [6.38,42.45]**,
REPEATED256+19.70%, NAME_HIT256+17.88%, COLLISION256+57.14%. Ring is **not** a
broad payoff beyond mixing. Retain linkedMixed, not ring;
do not claim blanket upstream non-regression.

Ring reduces churn allocation336→48B/block but first fresh block costs1376B
versus992B, and retained memory is not universally better. Populated modeled
CHURN4096 totals5024/6272B (ring/linked), NAME_HIT5024/4104B, COLLISION5024/3448B.
At64KiB CHURN ring is23.14% faster and modeled retained totals76064/99056B;
working-set exact hits have no ring advantage. Explicit array-accounting
assumptions, per-fork exact-hit allocation modes and interval caveats are in
ANALYSIS.md. Upstream65536 is unsupported (clamps4096), not silently timed at4096.

## Historical: iteration2 restored before ring — iteration3 rejected

The iteration3 `encodeHeaderMiss` extraction is reverted, and the complete codec
diff is byte-identical to `/tmp/hpack-candidate-iteration2.patch`. All earlier
improvements, codec tests and all new benchmarks are retained. Encoder SHA256:
`ab96050bc0c247d7fc158631066b1a6eb19c4c19630044916c3c31b697b8f063`.

**Iteration3 results, capacity/history controls and jars below remain historical
artifacts of the rejected experiment, not current-source performance evidence.**
No timings were rerun or relabelled. Iteration2's earlier results still do not
establish blanket non-regression; rejection does not prove extraction causality.

Post-revert full HTTP/2: **1642 tests, 0 failures/errors, 5 existing skips**.
Paranoid HPACK: **124 tests, 0 failures/errors/skips**. `git diff --check` clean.
Logs: `/tmp/hpack-reverted-iteration2-{http2,paranoid}-tests.log`.

**MIXED32768 is excluded as an unsupported periodic corpus in this fixture**:
`Non-periodic HPACK corpus at 0`. It was not timed and supports no mixed-traffic
capacity conclusion. This is not a claim of unsupported codec capacity. The
fixture and validation guard are unchanged; fixing periodicity is deferred.

## Historical: iteration3 — experimental exact-hit performance fix rejected

Completed 2026-10-10 **18:24:25–19:09:04 UTC**, **44m39s timing**, within the
55-minute sequential workflow budget. **255 fresh JVM forks / 1275 measured
iterations**: 180 matched, 45 capacity/init, 18 history, 12 traversal. Each fork
used 5×1s warmup, 5×1s measurement, GC profiling, one thread and a 512MiB heap
on Homebrew OpenJDK21. Six adjacent AB/BA pairs for each of the original nine
encode4096 cases, four key encode256 cases, init4096 and unchanged decode
HUFFMAN4096; three capacity rounds with capacity order rotated; three fresh/grown
history pairs; six matched traversal pairs. No concurrent builds/tests/timings
launched by this session; external host idleness is not certified.

Both baseline and candidate were rebuilt with **identical new benchmark sources**,
using the baseline worktree `/tmp/netty-hpack-baseline`. New isolated jars:
`/tmp/hpack-iteration3-baseline.jar` and `/tmp/hpack-iteration3.jar`. All four
previous jars are hash-preserved. No production or benchmark Java edits made.

### Verdict and exact hits

**Iteration3 is rejected as a performance improvement / non-regression fix;
its extraction is no longer in the current source.** REPEATED4096 has a supported slowdown and
allocation increase versus upstream. The timing lower bound does not establish
that the slowdown exceeds the +5% practical threshold, but this is still adverse
evidence on the intended exact-hit path, not an equivalence result. No matched
case establishes a >5% regression under that stricter interval rule. Ten of15
matched cases support timing NI; five remain unresolved. Lowering the capacity
ceiling does not repair the unchanged256/4096 path. The measurement campaign
made no production edits; the subsequent targeted revert is documented above.

| Case | Baseline → iteration3 ns/op | Change [paired fork95%] | B/op baseline → candidate |
|---|---:|---:|---:|
| REPEATED4096 | 42.65 → 48.84 | +14.53% [+3.99, +27.26] | 24 → 44 |
| REPEATED256 | 47.02 → 47.50 | +1.02% [−9.15, +10.74] | 40 → 40 |
| NAME_HIT256 | 175.47 → 111.73 | −36.32% [−37.56, −35.09] | 208 → 208 |
| COLLISION4096 | 992.36 → 991.73 | −0.06% [−5.52, +3.22] | 168 → 160 |
| HUFFMAN4096 encode | 3502.07 → 3296.92 | −5.86% [−9.22, −2.34] | 208 → 208 |
| INIT4096 | 33.37 → 28.07 | −15.86% [−16.24, −15.47] | 744 → 656 |
| unchanged HUFFMAN decode4096 | 3353.57 → 3705.97 | +10.51% [−3.98, +27.79] | 2768 → 2768 |

REPEATED4096 allocation delta **+20 B/block [4,36]**, beyond the1B tolerance;
baseline allocation fork modes48/0/48/48/0/0 versus candidate48/48/48/48/48/24.
Timing ratios remain positive in both order strata (AB1.126, BA1.166). This is
consistent with differing JIT/iterator escape-analysis modes, not proof of a
new20B object allocation or allocation-stack attribution. No slow fork excluded.
REPEATED256 has strong order sensitivity and unresolved allocation neutrality.
The matched traversal control is **6.15→6.20ns**, +0.69% [−0.47,+2.27], zero
allocation in every fork; do not subtract it from encode. The unchanged decoder
is noisy and is not used to adjust results. All supported matched wire sizes
agree. Historical iteration2 is a separate campaign, so this does **not** prove
extraction itself caused a regression relative to iteration2 or measure its
isolated effect. It does fail to support the intended exact-hit improvement.

### Lower-capacity tradeoff: memory savings versus useful working set

These are **actual negotiated capacities on the same64KiB-cap candidate**, not
separately compiled hard-cap variants. Three independent forks per cell, rotating
16/32/64KiB order. Timing/allocation cells are means; full fork-level exploratory
intervals and raw data are in [iteration3/ANALYSIS.md](iteration3/ANALYSIS.md).

| Working set | Capacity | Wire B/block | ns/block | Alloc B/block |
|---|---:|---:|---:|---:|
|128 (6034 HPACK bytes)|16 /32 /64KiB|5.969 /5.969 /5.969|54.55 /54.43 /54.72|48 /48 /48|
|384 (18322 bytes)|16 /32 /64KiB|46.215 /9.354 /9.354|125.44 /44.73 /49.38|205.5 /0 /16|
|512 (24466 bytes)|16 /32 /64KiB|47.141 /9.984 /9.984|126.11 /55.17 /45.71|208 /32 /0|
|768 (36754 bytes)|16 /32 /64KiB|47.409 /45.087 /10.740|129.88 /125.07 /50.66|208 /198 /16|

**16KiB is sufficient for128, but sacrifices compression, allocation and time
for384/512/768. 32KiB preserves compression at384/512 but loses badly at768.**
Versus64KiB, 16KiB slows384/512/768 by154% [114,181],176% [173,178],156% [115,186];
32KiB slows768 by147% [107,174]. These large effects agree with wire and
allocation evidence.32KiB512 timing +20.70% [0.87,31.41] coincides with32 versus0
B/block allocation modes despite identical wire; do not call it an inherent
capacity penalty isolated from JIT mode proportions. Tiny128 timing differences
are not a general speedup claim. Three-fork bootstrap tails have limited resolution.

Construction/configuration16/32/64KiB costs **176.33 /269.47 /318.67ns** and
**2736 /4784 /8880B per encoder**. Lowering to16KiB saves6144B/context and44.67%
init time;32KiB saves4096B and15.44%. These are allocated bytes, **not measured
retained heap**. Common4096 initialization remains656B; lower ceilings do not
simplify that path. **Retain64KiB capability unless real connection-lifetime,
working-set and memory requirements justify explicitly trading away compression.**
32KiB may be a workload-specific memory policy; it is not a generally superior
replacement. No mixed-traffic knee conclusion is supported (see fixture failure).

### History, fixture validation and verification

Candidate4096 fresh versus65536→4096 **before insertion**, three paired forks:
REPEATED46.73→37.25ns (allocation32→0, mode-sensitive); CHURN1471.56→176.40ns,
−88.01% [−90.02,−86.93], both336B; COLLISION1114.55→1111.63ns, interval
[−7.73,+5.50]%, inconclusive. Wire is identical for these history comparisons.
The large CHURN difference shows backing-structure history matters independently
of negotiated final capacity. It is not a recommendation to grow then shrink:
no retained-heap, populated-resize latency, or real SETTINGS cost measured.

Deterministic fixtures validate three encode cycles and two captured replay
cycles. All requested timing cases passed setup. **MIXED32768 failed with
`Non-periodic HPACK corpus at 0`** after all four requested working-set fixtures
passed; its failure and partial wire report are preserved, and it was not timed.
The validation guard was not weakened. Other reported capacities and history
validate; unsupported baseline16384 fails explicitly rather than clamping.

Fresh builds passed **113 baseline /124 candidate HPACK tests**. Postmeasurement
full HTTP/2: **1642 tests,0 failures/errors,5 skips**; paranoid HPACK: **124 tests,
0 failures/errors/skips**. Initial/final/post-test provenance verifies benchmark
source equality, packaged classes against each tree, codec patch, and old jars.
Baseline SHA256 `ecf23ca140848f43b8f019cda459aa34778f2b54783d6e74f666019bb3838929`;
candidate `90ec9a61187ecb9ba21cdf9dcba719a442d2f00fee106c4e4b48ed1045ac158d`.

[Plan](iteration3/PLAN.md), [analysis](iteration3/ANALYSIS.md), scripts,255 raw
JSON files and compressed logs, exact command manifest, wire CSVs, build/test
logs, source patch and hash provenance: **`iteration3/`**. Bootstrap100000 resamples,
fork means (not iterations), matched order-stratified95% intervals; +5% timing
and max(1B,1% baseline) allocation margins are analysis conventions, not user
acceptance or simultaneous family-wide guarantees.

## Historical premeasurement capacity-knee fixture note

`HpackStateBenchmark` now adds 128/384/768-entry working sets (6034/18322/36754
HPACK bytes), preserving the historical 512-entry `WORKING_SET` (24466 bytes).
It also adds opt-in `growThenShrink=true` (65536→4096 configuration history)
and the diagnostic `traverseHeaders` iterator control. See
[fixture definitions and validation handoff](../../HPACK.md#capacity-knee-fixture-additions-not-yet-measured).
These additions have not been compiled, executed, or measured pending codec-owner
readiness; all results below refer to the earlier fixture/codec artifacts.
Actual 16384/32768/65536 capacities must be supported and verified, not inferred
from requested negotiated sizes on a hard-capped codec. Existing 4096/65536
results do not establish the 16/32/64 KiB capacity knee or justify a cap choice.

## Latest: final iteration2 versus upstream baseline

Completed 2026-10-10 **17:31:30–18:11:25 UTC (39m55s measurement)**: **228 fresh JVM forks / 1140 measured iterations**, all 17 matched cases and four candidate-only 65536 cases. Six alternating AB/BA pairs, 5×1s warmup and measurement, GC profiler, Homebrew JDK21, one thread, 512MiB heap. No production or benchmark Java edits; preserved all previous jars and evidence. New isolated jar: `/tmp/hpack-iteration2.jar`.

**Initialization savings remain; HUFFMAN and NAME_HIT support practical noninferiority, but blanket non-regression is NOT established.** Twelve of 17 matched cases support the predeclared +5% timing margin; five remain unresolved (REPEATED at 0/256/4096, COLLISION4096, decode HUFFMAN control). None establishes a >5% regression, but REPEATED256/4096 and COLLISION4096 have positive timing intervals. This is not universal proof or user acceptance.

Two-sided 95% intervals bootstrap six paired fork means, 100000 resamples stratified by AB/BA; iterations are not independent replicates. Allocation tolerance is max(1 B/op, 1% baseline). These are analysis conventions; intervals are per-case, not simultaneous family-wide guarantees. No forks discarded or historical data pooled. This session launched no concurrent measurement/build/test workloads; external host idleness is not certified.

| Matched case | Baseline → iteration2 ns/op | Change [fork95%] | B/op baseline → iteration2 |
|---|---:|---:|---:|
| encode/HUFFMAN/4096 | 3348.21 → 3268.68 | -2.38% [-4.86, +0.25] | 208.0 → 208.0 |
| encode/REPEATED/4096 | 44.55 → 47.48 | +6.58% [+0.47, +17.34] | 32.0 → 40.0 |
| encode/REPEATED/256 | 42.62 → 47.50 | +11.44% [+0.98, +24.17] | 24.0 → 40.0 |
| encode/REPEATED/0 | 37.30 → 38.35 | +2.81% [-5.96, +14.16] | 4.0 → 8.0 |
| encode/COLLISION/4096 | 970.18 → 1013.41 | +4.46% [+1.77, +8.15] | 168.0 → 168.0 |
| encode/COLLISION/256 | 128.07 → 128.61 | +0.42% [-3.58, +4.54] | 208.0 → 208.0 |
| encode/NAME_HIT/4096 | 835.87 → 793.73 | -5.04% [-6.66, -3.38] | 208.0 → 208.0 |
| encode/NAME_HIT/256 | 173.80 → 110.92 | -36.18% [-37.32, -34.99] | 208.0 → 208.0 |
| encoder/INIT/4096 | 33.11 → 27.98 | -15.50% [-16.01, -15.13] | 744.0 → 656.0 |

INIT saves 88 B/context (11.83%), allocation delta interval [−88,−88]. REPEATED allocation delta intervals: 4096 [0,24], 256 [0,32], zero-table [−8,20] B/op; COLLISION4096 [−24,24]. Thus allocation neutrality is unresolved for these four cases despite equal COLLISION means. Other matched cases are within allocation tolerance. All matched wire sizes agree.

### 65536 capacity results (candidate only)

These compare iteration2 at 65536 with iteration2 at 4096, **not upstream**; no NAME_HIT65536 was in the requested original four-case matrix.

| Case | 4096 → 65536 ns/block | Ratio [fork95%] | B/block 4096 → 65536 |
|---|---:|---:|---:|
| WORKING_SET | 721.18 → 52.78 | 0.0732 [0.0652, 0.0814] | 208.0 → 24.0 |
| MIXED | 506.03 → 100.72 | 0.1990 [0.1910, 0.2061] | 208.0 → 103.0 |
| CHURN | 1450.19 → 199.67 | 0.1377 [0.1340, 0.1421] | 336.0 → 336.0 |
| COLLISION | 1013.41 → 222.58 | 0.2196 [0.2045, 0.2347] | 168.0 → 32.0 |

Capacity ratios are descriptive round-index bootstrap comparisons, not adjacent matched upstream AB/BA experiments. COLLISION wire size still increases 72 → 75.859 B/block; large-table capacity does not improve every compression outcome.

### Historical iteration1 and verification

Iteration1 (`optimized/`) measured HUFFMAN +5.73%, INIT −15.32%, COLLISION4096 −0.87%, NAME_HIT256 +3.26% against its own baseline. Current results are a separate campaign against upstream. They do not measure iteration2 versus iteration1, establish significance between iterations, or isolate the causal effects of Huffman reintegration/fused admission. Particularly large NAME_HIT256 changes warrant this caution. Fork/JIT/allocation modes and the variable unchanged decode control limit attribution.

Fresh reactor benchmark-jar build succeeded (124 HPACK tests). Full HTTP/2: **1642 tests, zero failures/errors, five existing skips**. Paranoid HPACK: **124 tests, zero failures/errors/skips**. Logs archived alongside raw results. Initial/final verification checks source patch, encoder and benchmark hashes, baseline/current packaged classes against compiled outputs, and preservation of earlier jars. `git diff --check` passed.

Iteration2 jar SHA256: `d2598337ee0876c8e44ad178e90825d9fb58c9784ad64bd0b4ed0a7c8149652c`.

Codec patch SHA256: `c9199c0869a31d5835261550d78d2cd91f2debf5ae01e9a706eebebd26cb3105`.

[Complete fork analysis](iteration2/ANALYSIS.md), [plan](iteration2/PLAN.md), raw JSON, compressed logs, exact commands, patch and provenance in `iteration2/`.

## Historical iteration1: optimized candidate versus original upstream baseline

Completed 2026-10-10 **16:43:39–17:23:53 UTC (40m14s measurement campaign)**:
**228 independent JVM forks, 1140 measured iterations**, six forks per case/version,
Homebrew OpenJDK 21.0.12, GC profiler, one thread, 512MiB heap, 5×1s warmup and
5×1s measurement. Sequential AB/BA pairs; all six pairs of COLLISION4096,
NAME_HIT256 and INIT4096 preceded the remaining cases. Build/tests completed before
measurement. No production/benchmark Java edits, no overlapping jobs launched;
host idleness unverified because sandbox denied process inspection.

### Conclusion

* **Initialization regression eliminated:** 33.48→28.35 ns/context,
  **−15.32% [−15.85%,−14.78%]**, **744→656 B/context**. The old candidate measured
  752 B/context; its 8B excess is gone, plus the lazy Huffman graph saves 88B versus
  upstream. This cross-campaign old-candidate allocation comparison is historical,
  not a new paired old-versus-new timing experiment.
* **Prior timing regressions not proven eliminated:** COLLISION4096 now
  **−0.87% [−7.90%,+7.26%]**, NAME_HIT256 **+3.26% [−10.53%,+18.64%]**. Neither has
  a strictly positive slowdown interval, but both upper bounds exceed 5%.
* **9/17 matched cases support timing NI; 8/17 unresolved; none establishes >5%
  regression.** The **+5% margin is an analysis NI threshold, not a user criterion**.
  REPEATED4096 **+3.34% [+0.23%,+8.80%]** and HUFFMAN encode4096
  **+5.73% [+0.34%,+14.68%]** have positive slowdown intervals; no universal
  no-regression claim is warranted.
* Order/fork variation is material: COLLISION4096 AB ratio 0.895 versus BA 1.100;
  NAME_HIT256 0.901 versus 1.182; CHURN256 1.313 versus 0.825. HUFFMAN decode control
  is **+1.41% [−19.41%,+26.35%]**. Allocation also varies by fork on REPEATED controls.
  All forks retained; noise must not be selectively interpreted as a fix or regression.
* All matched wire sizes agree exactly. Large-table WORKING_SET/MIXED benefits
  remain. CHURN wire unchanged; COLLISION65536 expands wire 72→75.859 B/block.

### Method and reproducibility

[Premeasurement plan](optimized/PLAN.md), [full fork-level tables](optimized/ANALYSIS.md),
[machine-readable analysis](optimized/analysis.json), [runner](optimized/run.py),
[analysis script](optimized/analyze.py), [final provenance](optimized/provenance-final.json).
Intervals use 100000 bootstrap resamples of six **fork means**, preserving three AB
and three BA pairs; iterations are not treated as independent samples. Capacity
intervals resample candidate4096/65536 round pairs and are descriptive comparisons,
not upstream implementation speedups. Intervals are pointwise, not multiplicity-adjusted.
Allocation tolerance is max(1B/op,1% upstream allocation), an analysis convention.

New isolated jar `/tmp/hpack-optimized.jar` SHA256
`406df35c4744f1f244f1d9952417ae2446782620b6a78b2e1124f6233bd0edb2`.
Preserved upstream `/tmp/hpack-baseline.jar`
`9f7a3c831fac2339bf22bf3682b1f607f025b2680b9e9add62fd743b70244182`;
preserved old candidate `/tmp/hpack-candidate.jar`
`1b60fc8e7bb74c024f5c15d11863f9a2e7048f456be59fdd9f8eb53c2ea38f88`.
New [patch](optimized/candidate.patch) SHA256
`d98d37d61fbec346eb17cd4fef23d76c2975f05dc113fea71b979e6796f84069`;
encoder SHA256 `f0abf1846eb809fd265765b9848e13d7981545f729387a5e655a57027f857183`.
Both benchmark sources are identical between trees. Verified packaged codec-http2
and microbench classes against compiled targets (1460 baseline, 1476 candidate,
excluding module-info), and rechecked preserved jars and source patch after campaign.
Build command: Homebrew21 `./mvnw -Dmaven.repo.local=/tmp/hpack-maven-repository
-pl microbench -am '-Pbenchmark-jar,!mac' '-Dtest=Hpack*Test'
-Dsurefire.failIfNoSpecifiedTests=false package`; successful log at
`/tmp/hpack-optimized-build.log`. Exact JVM commands in `optimized/commands.jsonl`;
228 raw JSON and 228 compressed logs retained. Run rounds 1–6 with runner argument
`priority`, then rounds 1–6 with `rest`; runner refuses overwriting measurement files.
Prior evidence below is historical and has not been relabeled.

### All matched and capacity results

Time ns/block and allocation B/block; INIT per context. Timing intervals are
percentage change candidate/upstream. Capacity reference is the optimized candidate4096.

| Case | Baseline ns | Candidate ns | Change [95% interval] | Time verdict | B/op baseline → candidate | Δ B/op [95% interval] | Allocation verdict | Wire B/block |
|---|---:|---:|---:|---|---:|---:|---|---:|
| encode/REPEATED/4096 | 44.29 | 45.77 | +3.34% [+0.23, +8.80] | unresolved | 32.000 → 36.000 | [+0.000, +12.000] | unresolved | 4.000 |
| encode/WORKING_SET/4096 | 783.91 | 759.87 | -3.07% [-5.81, -0.95] | NI supported | 208.000 → 208.000 | [-0.000, -0.000] | within tolerance | 47.141 |
| encode/MIXED/4096 | 555.15 | 549.30 | -1.05% [-3.36, +1.34] | NI supported | 208.000 → 208.000 | [-0.000, +0.000] | within tolerance | 48.216 |
| encode/CHURN/4096 | 1423.69 | 1439.96 | +1.14% [-0.69, +2.86] | NI supported | 336.001 → 336.001 | [-0.000, +0.000] | within tolerance | 90.916 |
| encode/NAME_HIT/4096 | 836.93 | 840.95 | +0.48% [-2.09, +3.08] | NI supported | 208.000 → 208.000 | [-0.000, +0.000] | within tolerance | 51.458 |
| encode/COLLISION/4096 | 1047.16 | 1038.07 | -0.87% [-7.90, +7.26] | unresolved | 192.000 → 168.000 | [-48.000, +0.000] | within tolerance | 72.000 |
| encode/STATIC/4096 | 69.20 | 69.76 | +0.81% [-0.09, +1.46] | NI supported | 48.000 → 48.000 | [+0.000, +0.000] | within tolerance | 4.000 |
| encode/SENSITIVE/4096 | 51.71 | 50.98 | -1.40% [-2.68, -0.39] | NI supported | 48.000 → 48.000 | [-0.000, +0.000] | within tolerance | 79.458 |
| encode/HUFFMAN/4096 | 3239.28 | 3424.84 | +5.73% [+0.34, +14.68] | unresolved | 208.001 → 204.001 | [-12.000, +0.000] | within tolerance | 1524.000 |
| encode/REPEATED/256 | 40.48 | 42.95 | +6.10% [-3.38, +17.54] | unresolved | 16.000 → 24.000 | [-8.000, +24.000] | unresolved | 4.000 |
| encode/CHURN/256 | 145.43 | 151.78 | +4.36% [-1.52, +15.97] | unresolved | 336.000 → 336.000 | [-0.000, +0.000] | within tolerance | 90.916 |
| encode/NAME_HIT/256 | 165.20 | 170.58 | +3.26% [-10.53, +18.64] | unresolved | 208.000 → 208.000 | [-0.000, +0.000] | within tolerance | 51.458 |
| encode/COLLISION/256 | 127.15 | 128.03 | +0.69% [-2.22, +2.79] | NI supported | 208.000 → 208.000 | [-0.000, +0.000] | within tolerance | 72.000 |
| encode/REPEATED/0 | 38.33 | 37.68 | -1.71% [-11.30, +7.55] | unresolved | 8.000 → 4.000 | [-20.000, +8.000] | unresolved | 68.000 |
| encode/CHURN/0 | 58.83 | 59.11 | +0.47% [-0.37, +1.31] | NI supported | 48.000 → 48.000 | [-0.000, +0.000] | within tolerance | 90.916 |
| encoder/INIT/4096 | 33.48 | 28.35 | -15.32% [-15.85, -14.78] | NI supported | 744.000 → 656.000 | [-88.000, -88.000] | within tolerance | — |
| decode/HUFFMAN/4096 | 3450.98 | 3499.73 | +1.41% [-19.41, +26.35] | unresolved | 2768.001 → 2768.001 | [-0.000, +0.000] | within tolerance | 1524.000 |

## Capacity (reference is candidate4096, not baseline)

| Scenario | 4096 ns → 65536 ns | Time ratio [95% interval] | B/block 4096 → 65536 | Wire B/block 4096 → 65536 |
|---|---:|---:|---:|---:|
| WORKING_SET | 759.87 → 56.97 | 0.0750 [0.0708, 0.0786] | 208.000 → 40.000 | 47.141 → 9.984 |
| MIXED | 549.30 → 95.95 | 0.1747 [0.1703, 0.1807] | 208.000 → 103.000 | 48.216 → 24.223 |
| CHURN | 1439.96 → 205.35 | 0.1426 [0.1389, 0.1465] | 336.001 → 336.000 | 90.916 → 90.916 |
| COLLISION | 1038.07 → 259.72 | 0.2502 [0.2187, 0.2821] | 168.000 → 40.000 | 72.000 → 75.859 |

## Historical: previous candidate six-round order-balanced campaign

Completed **228 fresh JVM forks / 1140 measurement iterations** on 2026-10-10,
14:51:18–15:31:25 UTC: **40m06s benchmark execution**, slightly above the
40-minute target; provenance, wire reporting and analysis add overhead.
No production or benchmark Java edits, builds, or tests were performed during
this campaign. No competing jobs were launched by this session. Host process
inspection (`ps`) was denied by the sandbox, so external host idleness cannot
be certified.

Each case/version has **six independent forks**, each with **5 × 1s warmup,
5 × 1s measurement**, GC profiling, one thread, fixed 512 MiB heap, Homebrew
OpenJDK 21.0.12, JMH 1.36 on macOS ARM64. For every matched case the adjacent
pair alternates **AB, BA, AB, BA, AB, BA** across rounds (A=baseline).
Cases retain fixed order within each round. Coverage: all nine encode4096;
REPEATED/CHURN/NAME_HIT/COLLISION encode256; REPEATED/CHURN encode0;
encoder initialization4096; unchanged HUFFMAN decode4096 control; candidate
WORKING_SET/MIXED/CHURN/COLLISION encode65536. Decoder initialization and an
exhaustive table0 matrix were not repeated.

### Provenance and reproducibility

Both `/tmp` jar SHA-256 hashes match `environment.json` on all six round starts:

* Baseline: `9f7a3c831fac2339bf22bf3682b1f607f025b2680b9e9add62fd743b70244182`
* Candidate: `1b60fc8e7bb74c024f5c15d11863f9a2e7048f456be59fdd9f8eb53c2ea38f88`

Current encoder source matches the recorded SHA-256 and the entire current
codec diff is byte-identical to `candidate.patch`. Both benchmark sources
match the baseline worktree; source hashes are saved. Packaged codec and
benchmark classes match current reactor outputs, excluding shaded module
metadata. This reuses the previously successful final rebuild, **not a fresh
clean build**. Baseline tracked sources are unchanged at `014ef8d7031f9f1015020095421a659ced36cc8a`.

All evidence is in [`balanced/`](balanced/): predeclared [PLAN.md](balanced/PLAN.md),
`run.py`, `commands.jsonl` (exact argv, shell commands and start times),
`completed.jsonl`, six provenance records, **228 raw JSONs and compressed logs**,
new wire CSVs/logs/commands, `analyze.py`, `analysis.json`, [full tables and
individual fork means](balanced/ANALYSIS.md), `verification.json`, and `SHA256SUMS`.
Validation confirmed all 228 expected cases in exact alternating order, complete
successful logs, five measured iterations per fork, final unchanged provenance,
and reproducible analysis. Exhaustively enumerating all 729 stratified paired
bootstrap resamples checked the Monte Carlo timing endpoints: maximum ratio
endpoint difference was 0.000477 (0.048 percentage points).
Reproduce on the same host with `python3 microbench/results/hpack/balanced/run.py N`
for N=1 through 6 sequentially (first archive the prior campaign outputs while
retaining the scripts at this repository-relative location; existing raw results
are never overwritten). Recompute analysis with
`python3 microbench/results/hpack/balanced/analyze.py` (NumPy 2.5.1 used).

### Analysis convention, not user acceptance criteria

Before execution, declared practical timing noninferiority margin **+5%** and
allocation tolerance **max(1 B/op, 1% of baseline mean)**. The absolute floor
avoids interpreting profiler residue around zero as meaningful allocation;
the relative threshold is deliberately strict. These are analytical conventions,
**not user-specified acceptance criteria**. Raw costs remain reported even below
tolerance. Initialization is per context; other units are per four-field block.

For each fork, average its five iterations. Estimate ratio of arithmetic
candidate/baseline fork means. Bootstrap **100,000 paired round resamples**,
stratified to retain three AB and three BA pairs, seed 20261010; report two-sided
percentile **95% intervals on ratios**, not JMH score-error overlap. Allocation
uses the paired mean-difference interval. Timing NI requires upper ratio bound
≤1.05; practical regression >5% requires lower bound >1.05; otherwise unresolved.
Allocation requires upper difference bound within tolerance. Forks—not the
30 correlated measurement iterations—are the independent units.

Assumptions: round pairs are independent and representative conditional on order;
thermal/host drift may violate this. Six pairs give limited tail precision.
Intervals are **per-case exploratory**, not simultaneous guarantees across the
matrix. Fixed case order, shared host and JVM optimization variability remain;
bootstrap does not remove these. An interval crossing 1 is **not equivalence**.
No unchanged-control subtraction and no pooling with earlier campaigns.

### Outcomes

| Matched case | Baseline → candidate ns/op | Change, fork-bootstrap 95% interval | B/op baseline → candidate |
|---|---:|---:|---:|
| encode COLLISION4096 | 957.42 → 1055.13 | **+10.21% [+3.10%, +17.37%]** | 168 → 184 |
| encode NAME_HIT256 | 173.68 → 182.13 | **+4.87% [+3.55%, +6.21%]** | 208 → 208 |
| encode NAME_HIT4096 | 828.23 → 843.60 | +1.86% [-1.81%, +6.20%] | 208 → 208 |
| encode REPEATED4096 | 41.35 → 43.55 | +5.31% [-8.86%, +22.02%] | 20 → 28 |
| encode REPEATED256 | 41.64 → 41.21 | -1.03% [-8.87%, +6.13%] | 20 → 16 |
| encode CHURN256 | 144.77 → 152.96 | +5.65% [-8.34%, +22.74%] | 336 → 336 |
| encode REPEATED0 | 36.30 → 38.42 | +5.84% [-0.42%, +17.58%] | ~0 → 8 |
| encoder init4096 | 33.25 → 34.49 | +3.71% [+2.71%, +4.46%] | **744 → 752** |
| unchanged decode HUFFMAN4096 | 3634.96 → 3317.68 | -8.73% [-21.45%, +6.77%] | 2768 → 2768 |

* **Evidence of positive slowdowns remains:** COLLISION4096 and NAME_HIT256
  intervals exclude zero change under this model. Both fail to establish 5%
  noninferiority; neither lower bound exceeds 5%, so the magnitude of a practical
  >5% regression is not established. This supersedes any reassurance from the
  earlier reverse-order three-fork confirmation. Do not dismiss these as neutral.
* Timing NI is supported for **9/17 matched cases**: WORKING_SET, MIXED, CHURN,
  STATIC, SENSITIVE and HUFFMAN encode4096; COLLISION encode256; CHURN encode0;
  encoder init4096. Eight are unresolved. **No case proves a >5% timing regression**
  using this predeclared interval rule; this does not mean no regressions exist.
* **Initialization allocation is a definitive observed increase:** +8 B/context,
  difference interval [+8, +8], or +1.075%, above the 7.44 B tolerance. Timing
  NI alone therefore does not pass both gates. No silent implementation fix.
* Allocation is unresolved for REPEATED at all three matched sizes and
  COLLISION4096. COLLISION's +16 B/block interval is approximately [0, +32];
  fork allocations vary between JVM optimization modes. REPEATED4096's +8 B
  interval is [-16, +32]. The table0 REPEATED candidate has one 48 B/block
  fork and five approximately allocation-free forks. This is evidence of
  variability, not proof that the candidate inherently allocates 8 B every block.
* **8/17 matched cases support both analysis gates; blanket non-regression is
  not established.** Initialization fails allocation; others remain unresolved.
  An unchanged decoder still shows strong order variation (AB ratio 1.126,
  BA 0.756), cautioning against attributing all timing shifts to encoder code.
  COLLISION4096 is slower in both order groups (AB 1.142, BA 1.062); NAME_HIT256
  likewise (AB 1.062, BA 1.036). Full order and fork detail is retained.

### Repeated capacity and wire evidence

| Candidate encode scenario | 4096 → 65536 ns/block | 65536/4096 ratio [95% interval] | B/block | Wire B/block |
|---|---:|---:|---:|---:|
| WORKING_SET | 779.49 → 53.61 | 0.0688 [0.0638, 0.0737] | 208 → 24 | 47.141 → 9.984 |
| MIXED | 548.91 → 98.25 | 0.1790 [0.1734, 0.1850] | 208 → 103 | 48.216 → 24.223 |
| CHURN | 1428.35 → 208.07 | 0.1457 [0.1431, 0.1482] | 336 → 336 | 90.916 → 90.916 |
| COLLISION | 1055.13 → 238.78 | 0.2263 [0.1741, 0.2873] | 184 → 24 | 72.000 → 75.859 |

These compare **candidate capacities**, not implementation speedups. Capacity
intervals use ordinary paired bootstrap by round; 65536 always ran later, so
capacity timing retains order confounding. WORKING_SET/MIXED wire reductions
are **78.8%/49.8%**; CHURN has no compression benefit; COLLISION wire **worsens
5.36%** despite faster processing. Large-table initialization was not repeated;
the prior 8976 B/context result below remains the only such evidence.

New deterministic wire reports revalidate replay and exact byte identity of
baseline/candidate at 0, 256 and 4096 for all nine scenarios. Matched4096 wire
B/block: REPEATED 4; WORKING_SET 47.141; MIXED 48.216; CHURN 90.916;
NAME_HIT 51.458; COLLISION 72; STATIC 4; SENSITIVE 79.458; HUFFMAN 1524.
The measured table0 controls are REPEATED 68 and CHURN 90.916 B/block.
Wire figures exclude negotiation and HTTP/2 framing.

## Historical initial campaign (not pooled with the latest results)

100 cases, 300 fresh JVM forks; all nine scenarios, encode/decode and initialization.

Three 1-second warmups and three 1-second measurements per fork; one thread;
JMH 1.36, GC profiler, `-Xms512m -Xmx512m`. Units: ns/four-field block and
B/block; initialization is ns/context and B/context. ± is JMH 99.9% score error.

Run order: baseline256, candidate256, baseline4096, candidate4096, candidate65536.
Baseline revision: `014ef8d7031f9f1015020095421a659ced36cc8a`.
Candidate: same revision plus `candidate.patch`, including the reviewer admission fix.
A final requested rebuild produced all 8099 class files byte-identical to the measured
candidate jar. Earlier pre-review results were discarded, not included here.

## Matched capacity

### 256 bytes

| Operation/scenario | Baseline ns ± | Candidate ns ± | Change | B/op baseline → candidate |
|---|---:|---:|---:|---:|
| decoder init | 55.66 ± 0.12 | 55.15 ± 0.14 | -0.9% | 688.0 → 688.0 |
| encoder init | 34.03 ± 0.30 | 34.33 ± 0.62 | +0.9% | 744.0 → 752.0 |
| decode REPEATED | 16.78 ± 3.14 | 15.73 ± 2.78 | -6.2% | 48.0 → 48.0 |
| decode WORKING_SET | 62.30 ± 2.53 | 60.36 ± 0.63 | -3.1% | 393.8 → 393.8 |
| decode MIXED | 63.43 ± 3.83 | 61.22 ± 3.74 | -3.5% | 395.2 → 395.2 |
| decode CHURN | 108.48 ± 1.46 | 99.83 ± 20.55 | -8.0% | 655.2 → 655.2 |
| decode NAME_HIT | 67.82 ± 20.28 | 62.39 ± 3.09 | -8.0% | 399.6 → 399.6 |
| decode COLLISION | 73.05 ± 3.82 | 69.77 ± 8.94 | -4.5% | 400.0 → 400.0 |
| decode STATIC | 13.43 ± 0.12 | 13.44 ± 0.20 | +0.1% | 48.0 → 48.0 |
| decode SENSITIVE | 56.13 ± 0.15 | 56.03 ± 0.31 | -0.2% | 527.6 → 527.6 |
| decode HUFFMAN | 2733.46 ± 146.68 | 2929.31 ± 67.64 | +7.2% | 2896.0 → 2896.0 |
| encode REPEATED | 42.54 ± 8.58 | 45.15 ± 9.99 | +6.1% | 24.0 → 32.0 |
| encode WORKING_SET | 178.10 ± 2.97 | 179.90 ± 1.43 | +1.0% | 208.0 → 208.0 |
| encode MIXED | 172.32 ± 3.13 | 178.52 ± 3.20 | +3.6% | 208.0 → 208.0 |
| encode CHURN | 144.40 ± 34.92 | 143.89 ± 32.35 | -0.3% | 336.0 → 336.0 |
| encode NAME_HIT | 154.94 ± 56.40 | 182.99 ± 4.80 | +18.1% | 208.0 → 208.0 |
| encode COLLISION | 126.23 ± 7.90 | 122.96 ± 0.28 | -2.6% | 208.0 → 208.0 |
| encode STATIC | 69.68 ± 1.00 | 69.63 ± 1.66 | -0.1% | 48.0 → 48.0 |
| encode SENSITIVE | 52.14 ± 0.97 | 51.14 ± 0.80 | -1.9% | 48.0 → 48.0 |
| encode HUFFMAN | 3189.57 ± 34.32 | 3173.52 ± 63.61 | -0.5% | 0.0 → 0.0 |

### 4096 bytes

| Operation/scenario | Baseline ns ± | Candidate ns ± | Change | B/op baseline → candidate |
|---|---:|---:|---:|---:|
| decoder init | 47.08 ± 0.39 | 47.08 ± 0.47 | +0.0% | 640.0 → 640.0 |
| encoder init | 32.97 ± 0.30 | 34.33 ± 0.11 | +4.1% | 744.0 → 752.0 |
| decode REPEATED | 14.49 ± 0.40 | 14.40 ± 0.20 | -0.6% | 48.0 → 48.0 |
| decode WORKING_SET | 65.72 ± 0.45 | 63.15 ± 3.84 | -3.9% | 393.8 → 393.8 |
| decode MIXED | 62.45 ± 3.50 | 60.41 ± 1.29 | -3.3% | 395.2 → 395.2 |
| decode CHURN | 83.39 ± 1.03 | 98.19 ± 18.84 | +17.7% | 655.2 → 655.2 |
| decode NAME_HIT | 61.36 ± 3.04 | 59.65 ± 0.43 | -2.8% | 399.6 → 399.6 |
| decode COLLISION | 62.20 ± 0.37 | 62.72 ± 1.05 | +0.8% | 400.0 → 400.0 |
| decode STATIC | 13.48 ± 0.24 | 13.52 ± 0.13 | +0.3% | 48.0 → 48.0 |
| decode SENSITIVE | 55.95 ± 0.25 | 56.22 ± 0.35 | +0.5% | 527.6 → 527.6 |
| decode HUFFMAN | 2978.12 ± 210.88 | 3211.95 ± 259.61 | +7.9% | 2768.0 → 2768.0 |
| encode REPEATED | 44.43 ± 10.45 | 40.71 ± 9.65 | -8.4% | 32.0 → 16.0 |
| encode WORKING_SET | 755.64 ± 44.71 | 775.31 ± 61.63 | +2.6% | 208.0 → 208.0 |
| encode MIXED | 544.00 ± 12.64 | 530.69 ± 47.64 | -2.4% | 208.0 → 208.0 |
| encode CHURN | 1410.10 ± 24.59 | 1410.43 ± 24.72 | +0.0% | 336.0 → 336.0 |
| encode NAME_HIT | 831.14 ± 36.86 | 834.90 ± 56.93 | +0.5% | 208.0 → 208.0 |
| encode COLLISION | 963.95 ± 27.70 | 1141.23 ± 62.20 | +18.4% | 176.0 → 208.0 |
| encode STATIC | 69.40 ± 0.69 | 69.61 ± 0.88 | +0.3% | 48.0 → 48.0 |
| encode SENSITIVE | 51.30 ± 0.85 | 50.77 ± 0.50 | -1.0% | 48.0 → 48.0 |
| encode HUFFMAN | 3328.64 ± 221.31 | 3263.91 ± 85.57 | -1.9% | 208.0 → 208.0 |

## Focused reverse-order confirmation

Completed 2026-10-10, 14:20:25–14:23:32 UTC, using the existing isolated jars
whose SHA-256 hashes match `environment.json`; no rebuilds or implementation
edits. Homebrew OpenJDK 21.0.12, JMH 1.36, one thread, GC profiler,
`-Xms512m -Xmx512m`. Each case used **3 fresh forks, 5 × 1s warmup and
5 × 1s measurement**: 6 cases / 18 forks / 90 measured iterations.
All runs were sequential: candidate NAME_HIT encode256, COLLISION encode4096,
HUFFMAN decode4096, then baseline in the same case order. No parallel builds
or tests were launched. This reverses the original baseline-first ordering.

| Operation/scenario/table bytes | Baseline ns ± | Candidate ns ± | Change | B/block baseline → candidate |
|---|---:|---:|---:|---:|
| encode NAME_HIT / 256 | 175.01 ± 4.51 | 178.18 ± 1.49 | +1.8% | 208.0 → 208.0 |
| encode COLLISION / 4096 | 975.79 ± 9.84 | 960.39 ± 2.87 | -1.6% | 160.0 → 160.0 |
| decode HUFFMAN / 4096 (unchanged decoder control) | 3859.77 ± 632.70 | 3780.37 ± 725.24 | -2.1% | 2768.0 → 2768.0 |

Units remain ns/four-field block; ± is JMH's 99.9% score error, not an
uncertainty bound on the percentage difference. Raw results and compressed
logs are `confirmation-{candidate,baseline}-{encode-NAME_HIT-256,encode-COLLISION-4096,decode-HUFFMAN-4096}.{json,log.gz}`.

### Interpretation and acceptance verdict

* **The original large encoder regressions were not reproduced.** NAME_HIT's
  +18.1% became +1.8%, with overlapping score intervals; this does not establish
  a persistent slowdown or equivalence. COLLISION's +18.4% reversed to -1.6%
  in this campaign. Do not average the two campaigns into a claimed speedup.
* COLLISION allocation is now 160 B/block for both jars, versus 176 → 208 in
  the original run. The differing observed allocation across campaigns is
  consistent with JVM optimization variability, but its cause was not isolated;
  the original allocation delta is not a stable implementation-cost finding.
* The unchanged HUFFMAN decoder control is noisy: candidate fork means were
  2862.91, 4127.11, 4351.09 ns/block; baseline means were 4179.36, 4341.46,
  3058.49. Its original +7.9% shift reversed to -2.1%, with wide overlapping
  intervals. Run-order reversal does not eliminate host/JIT variability and
  does not justify subtracting the control delta from encoder results.
* **Acceptance: the blanket regression-free performance goal is not established;
  do not claim it met.** This confirmation weakens the evidence for the two
  original large encoder regressions, but does not prove their absence under
  other runs or validate the unrerun matrix. The capacity/wire-size benefit
  remains demonstrated separately, not a matched-capacity speedup. Acceptance
  requiring non-regression needs a defined tolerance and more controlled,
  interleaved/repeated evidence, including other concerning matrix cases.

Reproduction (run sequentially with VERSION=candidate, then baseline; for each
version use OP/SCENARIO/SIZE = encode/NAME_HIT/256, encode/COLLISION/4096,
decode/HUFFMAN/4096):

```sh
export JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home
export PATH="$JAVA_HOME/bin:$PATH"
java -jar /tmp/hpack-${VERSION}.jar ".*HpackStateBenchmark\\.${OP}$" \
  -p scenario=${SCENARIO} -p tableSize=${SIZE} \
  -f 3 -wi 5 -w 1s -i 5 -r 1s -t 1 -prof gc -foe true \
  -jvmArgs '-Xms512m -Xmx512m' -rf json \
  -rff microbench/results/hpack/confirmation-${VERSION}-${OP}-${SCENARIO}-${SIZE}.json
```

## Candidate 65536 bytes

Capacity experiment, not a same-capacity speedup against baseline 4096.

| Operation/scenario | ns/op ± | B/op |
|---|---:|---:|
| decoder init | 46.81 ± 0.25 | 640.0 |
| encoder init | 326.98 ± 7.29 | 8976.0 |
| decode REPEATED | 14.55 ± 0.24 | 48.0 |
| decode WORKING_SET | 35.16 ± 0.36 | 48.0 |
| decode MIXED | 52.19 ± 9.45 | 168.3 |
| decode CHURN | 112.72 ± 0.48 | 655.2 |
| decode NAME_HIT | 63.40 ± 2.80 | 399.6 |
| decode COLLISION | 36.28 ± 0.37 | 303.5 |
| decode STATIC | 13.38 ± 0.09 | 48.0 |
| decode SENSITIVE | 55.83 ± 0.13 | 527.6 |
| decode HUFFMAN | 3537.78 ± 960.97 | 2768.0 |
| encode REPEATED | 39.66 ± 8.79 | 16.0 |
| encode WORKING_SET | 55.01 ± 8.15 | 32.0 |
| encode MIXED | 96.83 ± 6.70 | 103.0 |
| encode CHURN | 209.99 ± 8.23 | 336.0 |
| encode NAME_HIT | 177.50 ± 1.92 | 208.0 |
| encode COLLISION | 279.37 ± 80.18 | 40.0 |
| encode STATIC | 70.54 ± 1.22 | 48.0 |
| encode SENSITIVE | 51.84 ± 0.65 | 48.0 |
| encode HUFFMAN | 3259.19 ± 118.12 | 208.0 |

## Steady-state wire bytes per four-field block

Collected outside timing from the fully validated second 2048-block corpus cycle;
third-cycle byte identity and two decoder replay cycles are checked by setup.
No table negotiation or HTTP/2 framing bytes included. CSV files preserve totals.

| Scenario | Baseline/candidate 256 | Baseline/candidate 4096 | Candidate 65536 |
|---|---:|---:|---:|
| REPEATED | 4.000 | 4.000 | 4.000 |
| WORKING_SET | 47.141 | 47.141 | 9.984 |
| MIXED | 48.216 | 48.216 | 24.223 |
| CHURN | 90.916 | 90.916 | 90.916 |
| NAME_HIT | 51.458 | 51.458 | 51.458 |
| COLLISION | 72.000 | 72.000 | 75.859 |
| STATIC | 4.000 | 4.000 | 4.000 |
| SENSITIVE | 79.458 | 79.458 | 79.458 |
| HUFFMAN | 1552.000 | 1524.000 | 1524.000 |
