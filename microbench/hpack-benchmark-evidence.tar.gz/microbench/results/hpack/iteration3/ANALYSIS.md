# Iteration3 fork-level analysis

255 fresh JVM forks / 1275 measured iterations. All forks retained. 100000 bootstrap resamples, seed20261010. Matched six pairs stratified AB/BA; capacity/history three rounds use ordinary paired round resampling. Per-case95% intervals, not simultaneous. Three-fork capacity intervals are exploratory with poor tail resolution. +5% NI is an analysis margin, not acceptance. Nonsignificance is not equivalence.

## Matched baseline → iteration3

| Case | Reference → candidate ns/op | Change [fork95%] | B/op reference → candidate | ΔB/op [fork95%] | Timing; allocation |
|---|---:|---:|---:|---:|---|
| encode/REPEATED/4096 | 42.65 → 48.84 | +14.53% [+3.99, +27.26] | 24.00 → 44.00 | [+4.00, +36.00] | unresolved; increase |
| encode/WORKING_SET/4096 | 761.37 → 723.89 | -4.92% [-6.56, -3.23] | 208.00 → 208.00 | [-0.00, -0.00] | NI supported; within tolerance |
| encode/MIXED/4096 | 534.20 → 501.54 | -6.12% [-8.19, -2.74] | 208.00 → 208.00 | [-0.00, -0.00] | NI supported; within tolerance |
| encode/CHURN/4096 | 1411.60 → 1420.33 | +0.62% [-0.16, +1.41] | 336.00 → 336.00 | [-0.00, +0.00] | NI supported; within tolerance |
| encode/NAME_HIT/4096 | 833.83 → 809.61 | -2.90% [-5.24, -0.78] | 208.00 → 208.00 | [-0.00, -0.00] | NI supported; within tolerance |
| encode/COLLISION/4096 | 992.36 → 991.73 | -0.06% [-5.52, +3.22] | 168.00 → 160.00 | [-24.00, +0.00] | NI supported; within tolerance |
| encode/STATIC/4096 | 69.14 → 70.23 | +1.57% [+0.50, +2.66] | 48.00 → 48.00 | [+0.00, +0.00] | NI supported; within tolerance |
| encode/SENSITIVE/4096 | 51.30 → 51.04 | -0.52% [-1.71, +0.41] | 48.00 → 48.00 | [-0.00, +0.00] | NI supported; within tolerance |
| encode/HUFFMAN/4096 | 3502.07 → 3296.92 | -5.86% [-9.22, -2.34] | 208.00 → 208.00 | [-0.00, -0.00] | NI supported; within tolerance |
| encode/REPEATED/256 | 47.02 → 47.50 | +1.02% [-9.15, +10.74] | 40.00 → 40.00 | [-16.00, +16.00] | unresolved; unresolved |
| encode/CHURN/256 | 159.51 → 147.76 | -7.37% [-22.88, +15.96] | 336.00 → 336.00 | [-0.00, +0.00] | unresolved; within tolerance |
| encode/NAME_HIT/256 | 175.47 → 111.73 | -36.32% [-37.56, -35.09] | 208.00 → 208.00 | [-0.00, -0.00] | NI supported; within tolerance |
| encode/COLLISION/256 | 127.34 → 139.92 | +9.88% [-1.85, +27.70] | 208.00 → 200.00 | [-24.00, +0.00] | unresolved; within tolerance |
| encoder/INIT/4096 | 33.37 → 28.07 | -15.86% [-16.24, -15.47] | 744.00 → 656.00 | [-88.00, -88.00] | NI supported; within tolerance |
| decode/HUFFMAN/4096 | 3353.57 → 3705.97 | +10.51% [-3.98, +27.79] | 2768.00 → 2768.00 | [-0.00, +0.00] | unresolved; within tolerance |

## Lower capacity (reference64KiB; same candidate implementation)

| Case | Reference → candidate ns/op | Change [fork95%] | B/op reference → candidate | ΔB/op [fork95%] | Timing; allocation |
|---|---:|---:|---:|---:|---|
| capacity/WORKING_SET128/65536→16384 | 54.72 → 54.55 | -0.32% [-0.48, -0.05] | 48.00 → 48.00 | [-0.00, +0.00] | NI supported; within tolerance |
| capacity/WORKING_SET128/65536→32768 | 54.72 → 54.43 | -0.54% [-1.29, +0.20] | 48.00 → 48.00 | [-0.00, +0.00] | NI supported; within tolerance |
| capacity/WORKING_SET384/65536→16384 | 49.38 → 125.44 | +154.02% [+114.46, +180.87] | 16.00 → 205.50 | [+157.50, +205.50] | regression >5%; increase |
| capacity/WORKING_SET384/65536→32768 | 49.38 → 44.73 | -9.42% [-23.06, -0.49] | 16.00 → 0.00 | [-48.00, -0.00] | NI supported; within tolerance |
| capacity/WORKING_SET/65536→16384 | 45.71 → 126.11 | +175.92% [+173.39, +178.04] | 0.00 → 208.00 | [+208.00, +208.00] | regression >5%; increase |
| capacity/WORKING_SET/65536→32768 | 45.71 → 55.17 | +20.70% [+0.87, +31.41] | 0.00 → 32.00 | [+0.00, +48.00] | unresolved; unresolved |
| capacity/WORKING_SET768/65536→16384 | 50.66 → 129.88 | +156.36% [+115.26, +186.22] | 16.00 → 208.00 | [+160.00, +208.00] | regression >5%; increase |
| capacity/WORKING_SET768/65536→32768 | 50.66 → 125.07 | +146.85% [+107.49, +174.09] | 16.00 → 198.00 | [+150.00, +198.00] | regression >5%; increase |
| capacity/INIT/65536→16384 | 318.67 → 176.33 | -44.67% [-44.74, -44.56] | 8880.00 → 2736.00 | [-6144.00, -6144.00] | NI supported; within tolerance |
| capacity/INIT/65536→32768 | 318.67 → 269.47 | -15.44% [-16.02, -14.89] | 8880.00 → 4784.00 | [-4096.00, -4096.00] | NI supported; within tolerance |

## Capacity absolute results and wire

| Scenario | Capacity | ns/op | B/op | Wire B/block |
|---|---:|---:|---:|---:|
| WORKING_SET128 | 16384 | 54.55 | 48.00 | 5.969 |
| WORKING_SET128 | 32768 | 54.43 | 48.00 | 5.969 |
| WORKING_SET128 | 65536 | 54.72 | 48.00 | 5.969 |
| WORKING_SET384 | 16384 | 125.44 | 205.50 | 46.215 |
| WORKING_SET384 | 32768 | 44.73 | 0.00 | 9.354 |
| WORKING_SET384 | 65536 | 49.38 | 16.00 | 9.354 |
| WORKING_SET | 16384 | 126.11 | 208.00 | 47.141 |
| WORKING_SET | 32768 | 55.17 | 32.00 | 9.984 |
| WORKING_SET | 65536 | 45.71 | 0.00 | 9.984 |
| WORKING_SET768 | 16384 | 129.88 | 208.00 | 47.409 |
| WORKING_SET768 | 32768 | 125.07 | 198.00 | 45.087 |
| WORKING_SET768 | 65536 | 50.66 | 16.00 | 10.740 |
| INIT | 16384 | 176.33 | 2736.00 | — |
| INIT | 32768 | 269.47 | 4784.00 | — |
| INIT | 65536 | 318.67 | 8880.00 | — |

## Candidate4096 fresh → growThenShrink (before insertion)

| Case | Reference → candidate ns/op | Change [fork95%] | B/op reference → candidate | ΔB/op [fork95%] | Timing; allocation |
|---|---:|---:|---:|---:|---|
| history/REPEATED | 46.73 → 37.25 | -20.27% [-27.55, -2.45] | 32.00 → 0.00 | [-48.00, +0.00] | NI supported; within tolerance |
| history/CHURN | 1471.56 → 176.40 | -88.01% [-90.02, -86.93] | 336.00 → 336.00 | [-0.00, -0.00] | NI supported; within tolerance |
| history/COLLISION | 1114.55 → 1111.63 | -0.26% [-7.73, +5.50] | 192.00 → 176.00 | [-48.00, +0.00] | unresolved; within tolerance |

## Matched header traversal control

| Case | Reference → candidate ns/op | Change [fork95%] | B/op reference → candidate | ΔB/op [fork95%] | Timing; allocation |
|---|---:|---:|---:|---:|---|
| traverseHeaders/REPEATED/4096 | 6.15 → 6.20 | +0.69% [-0.47, +2.27] | 0.00 → 0.00 | [-0.00, -0.00] | NI supported; within tolerance |

## Allocation modes and order sensitivity

No slow forks discarded. Approximate0/24/48B repeated modes are consistent with iterator escape-analysis differences, not allocation-stack proof. Traversal allocations cannot be mechanically subtracted. Historical iteration2 is not a direct randomized extraction comparison.

| Case | AB ratio | BA ratio | Reference allocation forks | Candidate allocation forks |
|---|---:|---:|---|---|
| encode/REPEATED/4096 | 1.1264 | 1.1661 | 48.0, 0.0, 48.0, 48.0, 0.0, 0.0 | 48.0, 48.0, 48.0, 48.0, 48.0, 24.0 |
| encode/WORKING_SET/4096 | 0.9513 | 0.9503 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 |
| encode/MIXED/4096 | 0.9497 | 0.9282 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 |
| encode/CHURN/4096 | 1.0143 | 0.9982 | 336.0, 336.0, 336.0, 336.0, 336.0, 336.0 | 336.0, 336.0, 336.0, 336.0, 336.0, 336.0 |
| encode/NAME_HIT/4096 | 0.9623 | 0.9797 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 |
| encode/COLLISION/4096 | 1.0334 | 0.9675 | 160.0, 160.0, 160.0, 160.0, 160.0, 208.0 | 160.0, 160.0, 160.0, 160.0, 160.0, 160.0 |
| encode/STATIC/4096 | 1.0102 | 1.0212 | 48.0, 48.0, 48.0, 48.0, 48.0, 48.0 | 48.0, 48.0, 48.0, 48.0, 48.0, 48.0 |
| encode/SENSITIVE/4096 | 0.9963 | 0.9933 | 48.0, 48.0, 48.0, 48.0, 48.0, 48.0 | 48.0, 48.0, 48.0, 48.0, 48.0, 48.0 |
| encode/HUFFMAN/4096 | 0.9624 | 0.9215 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 |
| encode/REPEATED/256 | 1.1131 | 0.9174 | 48.0, 48.0, 0.0, 48.0, 48.0, 48.0 | 48.0, 48.0, 48.0, 48.0, 48.0, 0.0 |
| encode/CHURN/256 | 0.7647 | 1.1194 | 336.0, 336.0, 336.0, 336.0, 336.0, 336.0 | 336.0, 336.0, 336.0, 336.0, 336.0, 336.0 |
| encode/NAME_HIT/256 | 0.6390 | 0.6346 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 |
| encode/COLLISION/256 | 1.2614 | 0.9423 | 208.0, 208.0, 208.0, 208.0, 208.0, 208.0 | 208.0, 208.0, 208.0, 208.0, 208.0, 160.0 |
| encoder/INIT/4096 | 0.8417 | 0.8410 | 744.0, 744.0, 744.0, 744.0, 744.0, 744.0 | 656.0, 656.0, 656.0, 656.0, 656.0, 656.0 |
| decode/HUFFMAN/4096 | 1.2750 | 0.9677 | 2768.0, 2768.0, 2768.0, 2768.0, 2768.0, 2768.0 | 2768.0, 2768.0, 2768.0, 2768.0, 2768.0, 2768.0 |
| traverseHeaders/REPEATED/4096 | 0.9969 | 1.0169 | 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 | 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 |
