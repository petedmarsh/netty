# Iteration3 premeasurement plan

Budget: at most 55 minutes from started.json, sequential builds and measurements only. No production or benchmark-source edits. Both reactor builds use identical new benchmark sources; prior jars preserved. Homebrew JDK21; Maven wrapper and isolated /tmp/hpack-maven-repository, package (never install), benchmark-jar,!mac, HPACK tests enabled. PATH mvn shim unavailable; use ./mvnw.

Priority: 15 matched cases: original nine encode scenarios4096; REPEATED/CHURN/NAME_HIT/COLLISION256; INIT4096; unchanged decode HUFFMAN4096. Six adjacent alternating AB/BA pairs per case, 180 fresh JVM forks. Each fork: 5x1s warmup, 5x1s measurement, one thread, 512MiB heap, GC profiler. No optional zero-table timing.

Capacity: candidate only WORKING_SET128/384/(historical512)/768 at actual16384/32768/65536, plus init each capacity, three forks/case. Rotate capacity ordering across rounds. These are negotiated effective capacities on identical64KiB-cap implementation, NOT separately compiled hard-cap variants or evidence lower cap simplifies common path.

History: candidate4096 REPEATED/CHURN/COLLISION fresh versus growThenShrink=true, three adjacent alternating pairs. Traversal: baseline/candidate REPEATED4096 six AB/BA pairs. Total255 forks/1275 measured iterations. Extras only if budget permits; do not sacrifice priority matrix. Verify all deterministic fixtures, intentional unsupported baseline capacity rejection, jar/source hashes and packaged classes before timing.

Analysis: fork means are independent units; paired order-stratified bootstrap100000 resamples (three-round diagnostics unstratified), two-sided per-case95% intervals, not simultaneous coverage. +5% practical timing noninferiority margin and max(1B/op,1% baseline) allocation tolerance are analysis conventions, not user acceptance. Positive lower interval evidences slowdown; >5% lower interval is convincing practical regression and warrants rejection. Inconclusive != equivalent. Preserve all forks and allocation modes; no subtracting control costs. Capacity three-fork intervals are exploratory, not reliable equivalence tests. Wire bytes, allocation and timing all inform recommendation. New-source baseline is primary comparator; historical iteration2 is not a randomized direct iteration3 comparison and cannot isolate extraction causality.

Host process inspection denied; no competing work launched by this session, external host idleness cannot be certified. Final verification and analysis may run after measurements, never concurrently with timings.
