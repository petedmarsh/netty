#!/usr/bin/env python3
"""Fork-level analysis; numpy required. No iteration-level pseudoreplication."""
import csv, datetime, json, pathlib
import numpy as np
P=pathlib.Path(__file__).resolve().parent
rng=np.random.default_rng(20261010); N=100000
strat=np.concatenate([rng.choice([0,2,4],(N,3)),rng.choice([1,3,5],(N,3))],axis=1)
three=rng.integers(0,3,(N,3))
commands=[json.loads(x) for x in (P/'commands.jsonl').read_text().splitlines()]
ends=[json.loads(x) for x in (P/'completed.jsonl').read_text().splitlines()]
assert len(commands)==len(ends)==255
forks=[]
for c in commands:
    d=json.loads((P/(c['case']+'.json')).read_text())[0]
    assert d['forks']==1 and d['warmupIterations']==d['measurementIterations']==5
    assert d['warmupTime']==d['measurementTime']=='1 s' and d['threads']==1
    t=d['primaryMetric']['rawData']; a=d['secondaryMetrics']['·gc.alloc.rate.norm']['rawData']
    assert len(t)==len(a)==1 and len(t[0])==len(a[0])==5
    forks.append(dict(c,ns=float(np.mean(t[0])),B=float(np.mean(a[0]))))
def load(group,v,op,s,size,h=False):
    rows=[f for f in forks if (f['group'],f['version'],f['op'],f['scenario'],f['size'],f['history'])==(group,v,op,s,size,h)]
    rows.sort(key=lambda f:f['round'])
    return np.array([x['ns'] for x in rows]),np.array([x['B'] for x in rows])
def compare(a,b,idx):
    at,aa=a; bt,ba=b
    ci=np.quantile(bt[idx].mean(axis=1)/at[idx].mean(axis=1),[.025,.975])
    aci=np.quantile(ba[idx].mean(axis=1)-aa[idx].mean(axis=1),[.025,.975])
    tol=max(1,float(aa.mean())*.01)
    return dict(reference_ns=float(at.mean()),candidate_ns=float(bt.mean()),ratio=float(bt.mean()/at.mean()),ratio_ci95=ci.tolist(),reference_B=float(aa.mean()),candidate_B=float(ba.mean()),allocation_delta_ci95=aci.tolist(),time_status='NI supported' if ci[1]<=1.05 else 'regression >5%' if ci[0]>1.05 else 'unresolved',allocation_status='within tolerance' if aci[1]<=tol else 'increase' if aci[0]>tol else 'unresolved',reference_time_forks=at.tolist(),candidate_time_forks=bt.tolist(),reference_alloc_forks=aa.tolist(),candidate_alloc_forks=ba.tolist())
wire={}
for v in ['baseline','candidate','candidate-32768','history']:
    wire[v]={(int(x['tableSize']),x['scenario']):float(x['bytesPerBlock']) for x in csv.DictReader((P/f'wire-{v}.csv').open())}
wire['candidate'].update(wire['candidate-32768'])
assert all(wire['candidate'][k]==v for k,v in wire['baseline'].items())
results={}; lines=['# Iteration3 fork-level analysis','','255 fresh JVM forks / 1275 measured iterations. All forks retained. 100000 bootstrap resamples, seed20261010. Matched six pairs stratified AB/BA; capacity/history three rounds use ordinary paired round resampling. Per-case95% intervals, not simultaneous. Three-fork capacity intervals are exploratory with poor tail resolution. +5% NI is an analysis margin, not acceptance. Nonsignificance is not equivalence.','']
def table(title,rows):
    lines.extend(['## '+title,'','| Case | Reference → candidate ns/op | Change [fork95%] | B/op reference → candidate | ΔB/op [fork95%] | Timing; allocation |','|---|---:|---:|---:|---:|---|'])
    for key,x in rows:
        lo,hi=x['ratio_ci95']; al,ah=x['allocation_delta_ci95']
        lines.append(f'| {key} | {x["reference_ns"]:.2f} → {x["candidate_ns"]:.2f} | {(x["ratio"]-1)*100:+.2f}% [{(lo-1)*100:+.2f}, {(hi-1)*100:+.2f}] | {x["reference_B"]:.2f} → {x["candidate_B"]:.2f} | [{al:+.2f}, {ah:+.2f}] | {x["time_status"]}; {x["allocation_status"]} |')
    lines.append('')
matched=[]
for c in commands:
    if c['group']!='matched': continue
    op,s,size=c['op'],c['scenario'],c['size']; key=f'{op}/{s}/{size}'
    if key in results: continue
    x=compare(load('matched','baseline',op,s,size),load('matched','candidate',op,s,size),strat)
    results[key]=x; matched.append((key,x))
table('Matched baseline → iteration3',matched)
cap=[]
for s in ['WORKING_SET128','WORKING_SET384','WORKING_SET','WORKING_SET768','INIT']:
    op='encoder' if s=='INIT' else 'encode'
    for size in [16384,32768]:
        key=f'capacity/{s}/65536→{size}'
        x=compare(load('capacity','candidate',op,s,65536),load('capacity','candidate',op,s,size),three)
        results[key]=x; cap.append((key,x))
table('Lower capacity (reference64KiB; same candidate implementation)',cap)
lines+=['## Capacity absolute results and wire','','| Scenario | Capacity | ns/op | B/op | Wire B/block |','|---|---:|---:|---:|---:|']
for s in ['WORKING_SET128','WORKING_SET384','WORKING_SET','WORKING_SET768','INIT']:
    for size in [16384,32768,65536]:
        t,a=load('capacity','candidate','encoder' if s=='INIT' else 'encode',s,size)
        w='—' if s=='INIT' else f'{wire["candidate"][(size,s)]:.3f}'
        lines.append(f'| {s} | {size} | {t.mean():.2f} | {a.mean():.2f} | {w} |')
lines.append('')
hist=[]
for s in ['REPEATED','CHURN','COLLISION']:
    key='history/'+s
    x=compare(load('history','candidate','encode',s,4096),load('history','candidate','encode',s,4096,True),three)
    results[key]=x; hist.append((key,x))
    assert wire['history'][(4096,s)]==wire['candidate'][(4096,s)]
table('Candidate4096 fresh → growThenShrink (before insertion)',hist)
key='traverseHeaders/REPEATED/4096'
x=compare(load('traversal','baseline','traverseHeaders','REPEATED',4096),load('traversal','candidate','traverseHeaders','REPEATED',4096),strat)
results[key]=x; table('Matched header traversal control',[(key,x)])
lines+=['## Allocation modes and order sensitivity','','No slow forks discarded. Approximate0/24/48B repeated modes are consistent with iterator escape-analysis differences, not allocation-stack proof. Traversal allocations cannot be mechanically subtracted. Historical iteration2 is not a direct randomized extraction comparison.','', '| Case | AB ratio | BA ratio | Reference allocation forks | Candidate allocation forks |','|---|---:|---:|---|---|']
for key,x in matched+[(key,x)]:
    a=np.array(x['reference_time_forks']); b=np.array(x['candidate_time_forks'])
    lines.append(f'| {key} | {b[::2].mean()/a[::2].mean():.4f} | {b[1::2].mean()/a[1::2].mean():.4f} | '+', '.join(f'{v:.1f}' for v in x['reference_alloc_forks'])+' | '+', '.join(f'{v:.1f}' for v in x['candidate_alloc_forks'])+' |')
start=commands[0]['start']; end=ends[-1]['end']
meta=dict(start=start,end=end,elapsed_seconds=(datetime.datetime.fromisoformat(end)-datetime.datetime.fromisoformat(start)).total_seconds(),forks=255,measured_iterations=1275,replicates=N,seed=20261010,numpy=np.__version__)
(P/'analysis.json').write_text(json.dumps(dict(metadata=meta,cases=results),indent=2)+'\n')
(P/'forks.json').write_text(json.dumps(forks,indent=2)+'\n')
(P/'ANALYSIS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(meta,indent=2)); print('\n'.join(lines[:70]))
