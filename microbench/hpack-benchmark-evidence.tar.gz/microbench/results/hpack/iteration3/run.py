#!/usr/bin/env python3
"""Sequential iteration3 campaign; refuses overwrites. See PLAN.md."""
import datetime, gzip, hashlib, json, pathlib, platform, shlex, subprocess, time, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[4]
OUT=pathlib.Path(__file__).resolve().parent
JAVA='/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin/java'
JARS={'baseline':'/tmp/hpack-iteration3-baseline.jar','candidate':'/tmp/hpack-iteration3.jar'}
SCENARIOS=['REPEATED','WORKING_SET','MIXED','CHURN','NAME_HIT','COLLISION','STATIC','SENSITIVE','HUFFMAN']
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def verify():
    preserved=json.loads((OUT/'preserved-jars.json').read_text())
    assert all(sha(p)==h for p,h in preserved.items())
    assert subprocess.check_output(['git','diff','--','codec-http2'],cwd=ROOT)==(OUT/'candidate.patch').read_bytes()
    sources={}; checks={}
    for name in ['HpackStateBenchmark','HpackInitializationBenchmark']:
        p=pathlib.Path('microbench/src/main/java/io/netty/handler/codec/http2')/(name+'.java')
        assert (ROOT/p).read_bytes()==(pathlib.Path('/tmp/netty-hpack-baseline')/p).read_bytes()
        sources[str(p)]=sha(ROOT/p)
    for version,tree in [('baseline',pathlib.Path('/tmp/netty-hpack-baseline')),('candidate',ROOT)]:
        z=zipfile.ZipFile(JARS[version]); n=0
        for module in ['codec-http2','microbench']:
            base=tree/module/'target/classes'
            for p in base.rglob('*.class'):
                name=str(p.relative_to(base))
                if name.endswith('module-info.class'): continue
                assert z.read(name)==p.read_bytes(),name
                n+=1
        checks[version]=n
    return dict(verified_at=stamp(),jars={k:sha(v) for k,v in JARS.items()},preserved_jars=preserved,
        sources=sources,matching_classes=checks,host=platform.platform(),jdk=subprocess.run([JAVA,'-version'],capture_output=True,text=True).stderr,
        head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        baseline_head=subprocess.check_output(['git','-C','/tmp/netty-hpack-baseline','rev-parse','HEAD'],text=True).strip(),
        encoder_sha256=sha(ROOT/'codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java'),patch_sha256=sha(OUT/'candidate.patch'))
def validate():
    for version,sizes in [('baseline',['0','256','4096']),('candidate',['0','256','4096','16384','65536'])]:
        args=[JAVA,'-cp',JARS[version],'io.netty.handler.codec.http2.HpackStateBenchmark']+sizes
        with (OUT/('wire-'+version+'.csv')).open('w') as f: subprocess.run(args,stdout=f,check=True)
    # MIXED32768 (not a requested timing case) fails periodicity after all four
    # requested working-set fixtures have fully validated. Preserve the failure.
    with (OUT/'wire-candidate-32768.csv').open('w') as f, (OUT/'fixture-32768-failure.log').open('w') as err:
        r=subprocess.run([JAVA,'-cp',JARS['candidate'],'io.netty.handler.codec.http2.HpackStateBenchmark','32768'],stdout=f,stderr=err)
    assert r.returncode!=0
    import csv
    rows=list(csv.DictReader((OUT/'wire-candidate-32768.csv').open()))
    assert [x['scenario'] for x in rows]==['REPEATED','WORKING_SET','WORKING_SET128','WORKING_SET384','WORKING_SET768']
    assert 'Non-periodic HPACK corpus at 0' in (OUT/'fixture-32768-failure.log').read_text()
    with (OUT/'wire-history.csv').open('w') as f:
        subprocess.run([JAVA,'-cp',JARS['candidate'],'io.netty.handler.codec.http2.HpackStateBenchmark','--growThenShrink','4096'],stdout=f,check=True)
    with (OUT/'baseline-unsupported.log').open('w') as f:
        r=subprocess.run([JAVA,'-cp',JARS['baseline'],'io.netty.handler.codec.http2.HpackStateBenchmark','16384'],stdout=f,stderr=subprocess.STDOUT)
    assert r.returncode!=0
    for v in JARS:
        with (OUT/(v+'-listing.txt')).open('w') as f: subprocess.run([JAVA,'-jar',JARS[v],'-l','.*Hpack.*Benchmark.*'],stdout=f,check=True)
def run(group,r,v,op,s,size,history=False):
    deadline=json.loads((OUT/'started.json').read_text())['epoch']+3300
    assert time.time()+15<deadline,'55-minute budget exhausted'
    stem=f'{group}-r{r}-{v}-{op}-{s}-{size}-'+('grown' if history else 'fresh')
    target=OUT/(stem+'.json'); assert not target.exists(),stem
    bench='.*HpackInitializationBenchmark.encoder$' if s=='INIT' else '.*HpackStateBenchmark.'+op+'$'
    args=[JAVA,'-jar',JARS[v],bench,'-p','tableSize='+str(size)]
    if s!='INIT': args+=['-p','scenario='+s,'-p','growThenShrink='+str(history).lower()]
    args+=['-f','1','-wi','5','-w','1s','-i','5','-r','1s','-t','1','-prof','gc','-foe','true','-jvmArgs','-Xms512m -Xmx512m','-rf','json','-rff',str(target)]
    with (OUT/'commands.jsonl').open('a') as f: f.write(json.dumps(dict(start=stamp(),group=group,round=r,version=v,op=op,scenario=s,size=size,history=history,case=stem,argv=args,shell=shlex.join(args)))+'\n')
    log=OUT/(stem+'.log')
    with log.open('w') as f: subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=ROOT,check=True,timeout=90)
    data=json.loads(target.read_text()); assert len(data)==1
    assert len(data[0]['primaryMetric']['rawData'])==1 and len(data[0]['primaryMetric']['rawData'][0])==5
    with gzip.open(str(log)+'.gz','wb') as f: f.write(log.read_bytes())
    log.unlink()
    with (OUT/'completed.jsonl').open('a') as f: f.write(json.dumps(dict(case=stem,end=stamp()))+'\n')
    print(stamp(),stem,round(data[0]['primaryMetric']['score'],3),flush=True)
if __name__=='__main__':
    (OUT/'provenance-initial.json').write_text(json.dumps(verify(),indent=2))
    validate()
    cases=[('encode',s,4096) for s in SCENARIOS]+[('encode',s,256) for s in ['REPEATED','CHURN','NAME_HIT','COLLISION']]+[('encoder','INIT',4096),('decode','HUFFMAN',4096)]
    for r in range(1,7):
        for op,s,size in cases:
            for v in (['baseline','candidate'] if r%2 else ['candidate','baseline']): run('matched',r,v,op,s,size)
    for r in range(1,4):
        sizes=[16384,32768,65536]; sizes=sizes[r-1:]+sizes[:r-1]
        for s in ['WORKING_SET128','WORKING_SET384','WORKING_SET','WORKING_SET768','INIT']:
            for size in sizes: run('capacity',r,'candidate','encoder' if s=='INIT' else 'encode',s,size)
    for r in range(1,4):
        for s in ['REPEATED','CHURN','COLLISION']:
            for hist in ([False,True] if r%2 else [True,False]): run('history',r,'candidate','encode',s,4096,hist)
    for r in range(1,7):
        for v in (['baseline','candidate'] if r%2 else ['candidate','baseline']): run('traversal',r,v,'traverseHeaders','REPEATED',4096)
    (OUT/'provenance-final.json').write_text(json.dumps(verify(),indent=2))
    print('COMPLETE',stamp(),flush=True)
