#!/bin/bash
# Reproduction commands used in this campaign. Run from checkout root.
# Do not overwrite preserved measured jars; choose new paths for a rerun.
set -euo pipefail
export JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home
export PATH="$JAVA_HOME/bin:$PATH"
BASELINE=/tmp/netty-hpack-baseline
cp microbench/src/main/java/io/netty/handler/codec/http2/Hpack{State,Initialization}Benchmark.java "$BASELINE/microbench/src/main/java/io/netty/handler/codec/http2/"
# Each command runs sequentially; package avoids SNAPSHOT installation contamination.
(cd "$BASELINE"; ./mvnw -Dmaven.repo.local=/tmp/hpack-maven-repository -pl microbench -am '-Pbenchmark-jar,!mac' '-Dtest=Hpack*Test' -Dsurefire.failIfNoSpecifiedTests=false package)
# Campaign copied baseline microbench/target/microbenchmarks.jar to /tmp/hpack-iteration3-baseline.jar.
./mvnw -Dmaven.repo.local=/tmp/hpack-maven-repository -pl microbench -am '-Pbenchmark-jar,!mac' '-Dtest=Hpack*Test' -Dsurefire.failIfNoSpecifiedTests=false package
# Campaign copied candidate microbench/target/microbenchmarks.jar to /tmp/hpack-iteration3.jar.
# AFTER timing (never concurrently):
./mvnw -Dmaven.repo.local=/tmp/hpack-maven-repository -pl codec-http2 -am '-P!mac' '-Dtest=io.netty.handler.codec.http2.*Test' -Dsurefire.failIfNoSpecifiedTests=false test
./mvnw -Dmaven.repo.local=/tmp/hpack-maven-repository -pl codec-http2 -am '-P!mac' '-Dtest=Hpack*Test' -Dsurefire.failIfNoSpecifiedTests=false -Dio.netty.leakDetection.level=paranoid test
