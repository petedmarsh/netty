#!/usr/bin/env python3
"""Run only after the coordinator has stopped ALL other tests/builds/benchmarks."""
import argparse, datetime, hashlib, json, os, pathlib, shlex, shutil, subprocess, zipfile
HERE = pathlib.Path(__file__).resolve().parent
WORK = pathlib.Path('/tmp/netty-hpack-distribution')
JAVA_HOME = pathlib.Path('/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home')
ENC = pathlib.Path('codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java')
BENCH = pathlib.Path('microbench/src/main/java/io/netty/handler/codec/http2')
SCENARIOS = ['CHURN', 'NAME_HIT', 'REPEATED', 'COLLISION']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def execute(args, cwd, log):
    args = list(map(str, args))
    with (WORK / 'commands.jsonl').open('a') as f:
        f.write(json.dumps(dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                               cwd=str(cwd), argv=args, shell=shlex.join(args))) + '\n')
    env = dict(os.environ, JAVA_HOME=str(JAVA_HOME), PATH=str(JAVA_HOME / 'bin') + ':' + os.environ['PATH'])
    with log.open('w') as out:
        subprocess.run(args, cwd=cwd, env=env, stdout=out, stderr=subprocess.STDOUT, check=True)
def verify(manifest):
    for name, v in manifest['variants'].items():
        tree = pathlib.Path(v['tree'])
        assert sha(tree / ENC) == v['encoder_sha256'], name
        actual = subprocess.check_output(['git', 'diff', '--', 'codec-http2'], cwd=tree)
        assert hashlib.sha256(actual).hexdigest() == v['patch_sha256'], name
        for source, digest in manifest['benchmark_sha256'].items():
            assert sha(tree / BENCH / source) == digest, name

def build(manifest):
    for name, v in manifest['variants'].items():
        tree = pathlib.Path(v['tree']); out = WORK / 'artifacts' / name
        out.mkdir(parents=True, exist_ok=True)
        if (out / 'verified.json').exists():
            verified = json.loads((out / 'verified.json').read_text())
            assert sha(out / 'microbenchmarks.jar') == verified['jar_sha256']
            assert verified['variant'] == v
            print('Retaining already verified jar', name, flush=True)
            continue
        common = ['./mvnw', '-Dmaven.repo.local=/tmp/hpack-maven-repository',
                  '-Dsurefire.failIfNoSpecifiedTests=false', '-DskipTests=false']
        execute(common + ['-pl', 'codec-http2', '-am', '-P!mac',
                          '-Dtest=io.netty.handler.codec.http2.*Test', 'test'], tree, out / 'http2-tests.log')
        execute(common + ['-pl', 'microbench', '-am', '-Pbenchmark-jar,!mac',
                          '-Dtest=Hpack*Test', '-Dio.netty.leakDetection.level=paranoid', 'package'],
                tree, out / 'build-paranoid.log')
        jar = out / 'microbenchmarks.jar'
        shutil.copyfile(tree / 'microbench/target/microbenchmarks.jar', jar)
        # Reactor build, no overlays: verify packaged codec/benchmark bytecode against outputs.
        with zipfile.ZipFile(jar) as z:
            count = 0
            for module in ['codec-http2', 'microbench']:
                classes = tree / module / 'target/classes'
                for p in classes.rglob('*.class'):
                    relative = p.relative_to(classes).as_posix()
                    if relative.endswith('module-info.class'): continue
                    assert z.read(relative) == p.read_bytes(), relative
                    count += 1
        probe = out / 'probe'; probe.mkdir(exist_ok=True)
        execute([JAVA_HOME / 'bin/javac', '-cp', jar, '-d', probe, HERE / 'WireCheck.java'],
                tree, out / 'probe-compile.log')
        execute([JAVA_HOME / 'bin/java', '-cp', str(probe) + os.pathsep + str(jar),
                 'io.netty.handler.codec.http2.WireCheck', v['buckets'], v['mode']], tree, out / 'wire.csv')
        # JVM warnings may precede the probe output; compare precisely the four scenario lines.
        wire = [line for line in (out / 'wire.csv').read_text().splitlines()
                if line.split(',')[0] in SCENARIOS]
        assert len(wire) == 4
        if name != '64-raw':
            reference = json.loads((WORK / 'artifacts/64-raw/verified.json').read_text())['wire']
            assert wire == reference, 'wire mismatch: ' + name
        (out / 'verified.json').write_text(json.dumps(dict(jar_sha256=sha(jar),
            matching_classes=count, wire=wire, variant=v), indent=2) + '\n')
        print('Built/tested/wire verified', name, flush=True)
    verify(manifest)

def campaign(manifest):
    variants = list(manifest['variants'])
    hashes = {}
    for name in variants:
        out = WORK / 'artifacts' / name
        hashes[name] = json.loads((out / 'verified.json').read_text())['jar_sha256']
        assert sha(out / 'microbenchmarks.jar') == hashes[name]
    results = WORK / 'results'; results.mkdir(exist_ok=True)
    # Six cyclic rotations: every variant occupies each position once per scenario.
    for r in range(6):
        order = variants[r:] + variants[:r]
        for scenario in SCENARIOS[r % 4:] + SCENARIOS[:r % 4]:
            for name in order:
                stem = f'r{r + 1}-{name}-{scenario}'
                target = results / (stem + '.json')
                assert not target.exists(), 'refusing overwrite: ' + stem
                jar = WORK / 'artifacts' / name / 'microbenchmarks.jar'
                assert sha(jar) == hashes[name]
                execute([JAVA_HOME / 'bin/java', '-jar', jar, '.*HpackStateBenchmark.encode$',
                         '-p', 'tableSize=4096', '-p', 'growThenShrink=false', '-p', 'scenario=' + scenario,
                         '-f', '1', '-wi', '5', '-w', '1s', '-i', '5', '-r', '1s', '-t', '1',
                         '-prof', 'gc', '-foe', 'true', '-jvmArgs', '-Xms512m -Xmx512m',
                         '-rf', 'json', '-rff', target], WORK, results / (stem + '.log'))
                rows = json.loads(target.read_text())
                assert len(rows) == 1 and len(rows[0]['primaryMetric']['rawData']) == 1
                assert len(rows[0]['primaryMetric']['rawData'][0]) == 5
                print(stem, rows[0]['primaryMetric']['score'], flush=True)
    verify(manifest)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['build', 'campaign'])
    parser.add_argument('--exclusive-host-confirmed', action='store_true', required=True)
    args = parser.parse_args()
    manifest = json.loads((WORK / 'manifest.json').read_text())
    # This lock protects only this experiment. Coordinator confirmation covers other agents.
    lock = WORK / 'runner.lock'
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    try:
        verify(manifest)
        (build if args.phase == 'build' else campaign)(manifest)
    finally:
        os.close(fd); lock.unlink()
