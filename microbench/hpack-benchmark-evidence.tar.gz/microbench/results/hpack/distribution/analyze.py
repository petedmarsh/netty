#!/usr/bin/env python3
"""Paired round-level factorial contrasts; negative time deltas are improvements."""
import json, math, pathlib, statistics
WORK = pathlib.Path('/tmp/netty-hpack-distribution')
SCENARIOS = ['CHURN', 'NAME_HIT', 'REPEATED', 'COLLISION']
def values(variant, scenario, metric='primaryMetric'):
    result = []
    for r in range(1, 7):
        row, = json.loads((WORK / 'results' / f'r{r}-{variant}-{scenario}.json').read_text())
        # This JMH 1.36 build prefixes profiler metric names with a middle dot.
        metrics = {key.lstrip('\u00b7'): value for key, value in row['secondaryMetrics'].items()}
        result.append(row['primaryMetric']['score'] if metric == 'primaryMetric' else
                      metrics[metric]['score'])
    return result
def contrast(a, b):
    logs = [math.log(y / x) for x, y in zip(a, b)]
    mean = statistics.mean(logs)
    # Student t(5), six independent forks per cell; exploratory, no multiple-test correction.
    margin = 2.570582 * statistics.stdev(logs) / math.sqrt(6)
    return '%.2f%% [%.2f, %.2f]' % tuple(100 * math.expm1(x) for x in [mean, mean-margin, mean+margin])
lines = ['# Distribution factorial results', '',
         'Six round-paired independent forks/cell. Time deltas: negative is faster.',
         '95% t intervals on log ratios; exploratory, unadjusted for multiple comparisons.',
         'No conclusion from a single fork or overlapping/noisy interval.', '']
for scenario in SCENARIOS:
    lines += ['## ' + scenario, '', '| Variant | Mean ns/block | Mean B/block |', '|---|---:|---:|']
    for buckets in [64, 256, 1024]:
        for mode in ['raw', 'mixed']:
            v = f'{buckets}-{mode}'
            lines.append('| %s | %.3f | %.3f |' % (v, statistics.mean(values(v, scenario)),
                          statistics.mean(values(v, scenario, 'gc.alloc.rate.norm'))))
    lines += ['', '### Mixing at fixed bucket count']
    for b in [64, 256, 1024]:
        lines.append('- %d mixed vs raw: %s' % (b, contrast(values(f'{b}-raw', scenario),
                                                            values(f'{b}-mixed', scenario))))
    lines += ['', '### Buckets at fixed hash mapping']
    for mode in ['raw', 'mixed']:
        for b in [256, 1024]:
            lines.append('- %d vs 64, %s: %s' % (b, mode, contrast(values(f'64-{mode}', scenario),
                                                                        values(f'{b}-{mode}', scenario))))
    lines += ['', '### Interaction (mixing ratio at larger size / mixing ratio at 64)']
    base = [m/r for r,m in zip(values('64-raw', scenario), values('64-mixed', scenario))]
    for b in [256, 1024]:
        large = [m/r for r,m in zip(values(f'{b}-raw', scenario), values(f'{b}-mixed', scenario))]
        lines.append('- %d: %s' % (b, contrast(base, large)))
    lines.append('')
report = '\n'.join(lines) + '\n'
(WORK / 'ANALYSIS.md').write_text(report)
print(report)
