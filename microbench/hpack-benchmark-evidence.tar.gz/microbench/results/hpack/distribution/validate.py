#!/usr/bin/env python3
"""Validate completed factorial and archive evidence without large jars/worktrees."""
import datetime, gzip, hashlib, json, pathlib, shutil, xml.etree.ElementTree as ET
import run
w = run.WORK
here = pathlib.Path(__file__).resolve().parent
m = json.loads((w / 'manifest.json').read_text())
run.verify(m)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
expected = {f'r{r}-{v}-{s}' for r in range(1, 7) for v in m['variants'] for s in run.SCENARIOS}
assert {p.stem for p in (w / 'results').glob('*.json')} == expected
for stem in expected:
    row, = json.loads((w / 'results' / (stem + '.json')).read_text())
    assert row['params'] == dict(tableSize='4096', growThenShrink='false', scenario=stem.split('-')[-1])
    assert row['forks'] == row['threads'] == 1
    assert row['warmupIterations'] == row['measurementIterations'] == 5
    assert row['warmupTime'] == row['measurementTime'] == '1 s'
    assert row['jvmArgs'] == ['-Xms512m', '-Xmx512m']
    assert row['jdkVersion'].startswith('21.')
    assert row['primaryMetric']['scoreUnit'] == 'ns/op'
    assert len(row['primaryMetric']['rawData']) == 1
    assert len(row['primaryMetric']['rawData'][0]) == 5
    assert row['secondaryMetrics']['·gc.alloc.rate.norm']['scoreUnit'] == 'B/op'
    assert '# Run complete.' in (w / 'results' / (stem + '.log')).read_text()
reference = None
validation = {}
for name, v in m['variants'].items():
    out = w / 'artifacts' / name
    verified = json.loads((out / 'verified.json').read_text())
    assert sha(out / 'microbenchmarks.jar') == verified['jar_sha256']
    assert verified['variant'] == v
    assert verified['matching_classes'] > 0
    if reference is None: reference = verified['wire']
    assert verified['wire'] == reference
    for log in ('http2-tests.log', 'build-paranoid.log'):
        assert 'BUILD SUCCESS' in (out / log).read_text()
    reports = list((pathlib.Path(v['tree']) / 'codec-http2/target/surefire-reports').glob('TEST-*.xml'))
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    for p in reports:
        root = ET.parse(p).getroot()
        for key in totals: totals[key] += int(root.attrib[key])
    assert totals['tests'] > 1000 and totals['failures'] == totals['errors'] == 0
    validation[name] = dict(surefire=totals, jar_sha256=verified['jar_sha256'], matching_classes=verified['matching_classes'])
archive = here / 'evidence'
archive.mkdir(exist_ok=True)
for p in w.glob('*.json*'): shutil.copyfile(p, archive / p.name)
for p in w.glob('*.patch'): shutil.copyfile(p, archive / p.name)
shutil.copytree(w / 'benchmarks', archive / 'benchmarks', dirs_exist_ok=True)
shutil.copyfile(w / 'ANALYSIS.md', here / 'ANALYSIS.md')
for folder in ('results', 'artifacts'):
    for p in (w / folder).rglob('*'):
        if not p.is_file() or p.suffix not in ('.json', '.log', '.csv'): continue
        dest = archive / p.relative_to(w)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if p.suffix == '.log':
            dest.with_suffix('.log.gz').write_bytes(gzip.compress(p.read_bytes(), mtime=0))
        else: shutil.copyfile(p, dest)
for name, v in m['variants'].items():
    for p in (pathlib.Path(v['tree']) / 'codec-http2/target/surefire-reports').glob('TEST-*.xml'):
        dest = archive / 'artifacts' / name / 'surefire' / (p.name + '.gz')
        dest.parent.mkdir(exist_ok=True)
        dest.write_bytes(gzip.compress(p.read_bytes(), mtime=0))
record = dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), forks=144,
              measurement_iterations=720, variants=validation, wire=reference,
              evidence_sha256={str(p.relative_to(archive)): sha(p) for p in sorted(archive.rglob('*')) if p.is_file() and p.name != 'validation.json'})
(archive / 'validation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k != 'evidence_sha256'}, indent=2))
