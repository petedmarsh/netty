package io.netty.handler.codec.http2;

import io.netty.buffer.ByteBuf;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.MessageDigest;

/** Untimed, exact-byte corpus fingerprint and physical configuration assertions. */
public final class WireCheck {
    private static Object field(Object object, String name) throws Exception {
        Field f = object.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(object);
    }
    public static void main(String[] args) throws Exception {
        int buckets = Integer.parseInt(args[0]);
        boolean mixed = args[1].equals("mixed");
        for (String scenario : new String[] {"CHURN", "NAME_HIT", "REPEATED", "COLLISION"}) {
            HpackStateBenchmark benchmark = new HpackStateBenchmark();
            benchmark.tableSize = 4096;
            benchmark.scenario = HpackStateBenchmark.Scenario.valueOf(scenario);
            benchmark.growThenShrink = false;
            try {
                benchmark.setup(); // Validates decoded fields and steady-state replay.
                HpackEncoder encoder = (HpackEncoder) field(benchmark, "encoder");
                if (encoder.getMaxHeaderTableSize() != 4096 ||
                    ((Object[]) field(encoder, "nameEntries")).length != buckets ||
                    ((Object[]) field(encoder, "nameValueEntries")).length != buckets) {
                    throw new AssertionError("Wrong physical configuration");
                }
                Method bucket = HpackEncoder.class.getDeclaredMethod("bucket", int.class);
                Method mix = HpackEncoder.class.getDeclaredMethod("mixHash", int.class);
                bucket.setAccessible(true);
                mix.setAccessible(true);
                for (int h : new int[] {0, 1, -1, 1234567, Integer.MIN_VALUE, 0x12345678}) {
                    int hash = mixed ? (Integer) mix.invoke(null, h) : h;
                    if ((Integer) bucket.invoke(encoder, h) != (hash & (buckets - 1))) {
                        throw new AssertionError("Wrong bucket mapping");
                    }
                }
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                long total = 0;
                for (ByteBuf block : (ByteBuf[]) field(benchmark, "wire")) {
                    int length = block.writerIndex();
                    // Include block boundaries, not just concatenated payload.
                    for (int shift = 24; shift >= 0; shift -= 8) digest.update((byte) (length >>> shift));
                    for (int i = 0; i < length; ++i) digest.update(block.getByte(i));
                    total += length;
                }
                StringBuilder hex = new StringBuilder();
                for (byte b : digest.digest()) hex.append(String.format("%02x", b & 255));
                System.out.println(scenario + ",4096," + total + "," + hex);
            } finally {
                benchmark.tearDown();
            }
        }
    }
}
