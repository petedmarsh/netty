#!/usr/bin/env python3
"""Recorded fixture-only adaptation for large raw variants; no security tests removed."""
import hashlib, json, pathlib, shutil, subprocess
work = pathlib.Path('/tmp/netty-hpack-distribution')
manifest = json.loads((work / 'manifest.json').read_text())
assert not (work / 'manifest.pre-test-adaptation.json').exists(), 'refusing repeated adaptation'
shutil.copyfile(work / 'manifest.json', work / 'manifest.pre-test-adaptation.json')
for name in ('256-raw', '1024-raw'):
    v = manifest['variants'][name]
    tree = pathlib.Path(v['tree'])
    path = tree / 'codec-http2/src/test/java/io/netty/handler/codec/http2/HpackEncoderTest.java'
    original = path.read_text()
    start = original.index('    @Test\n    public void testLargeTableManyEntriesAndEviction')
    end = original.index('    @Test\n    public void testGrowWithInheritedCollisionChain', start)
    block = original[start:end]
    block = block.replace('"value-" + i', 'distributedFixture(i)')
    block = block.replace('"value-3999"', 'distributedFixture(3999)').replace('"value-0"', 'distributedFixture(0)')
    block = block.replace('"x-name-" + i', 'distributedFixture(i)').replace('"x-name-0"', 'distributedFixture(0)')
    block += '''    // Distribution experiment only: sequential decimal fixtures concentrate raw hash buckets.
    // Keep 1200-entry reuse/eviction coverage with dispersed deterministic fixtures;
    // deliberately colliding admission/security tests below remain unchanged.
    private static String distributedFixture(int i) {
        return String.format(java.util.Locale.ROOT, "%012x", new Random(i).nextLong() & 0xffffffffffffL);
    }

'''
    path.write_text(original[:start] + block + original[end:])
    patch = subprocess.check_output(['git', 'diff', '--', 'codec-http2'], cwd=tree)
    test_patch = subprocess.check_output(['git', 'diff', '--', str(path.relative_to(tree))], cwd=tree)
    (work / (name + '.adapted.patch')).write_bytes(patch)
    (work / (name + '.test-adaptation.patch')).write_bytes(test_patch)
    v['original_patch_sha256'] = v['patch_sha256']
    v['patch_sha256'] = hashlib.sha256(patch).hexdigest()
    v['test_adaptation_sha256'] = hashlib.sha256(test_patch).hexdigest()
    v['test_source_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
(work / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
failed = work / 'artifacts/256-raw/http2-tests.log'
shutil.copyfile(failed, failed.with_name('http2-tests.pre-adaptation-failure.log'))
