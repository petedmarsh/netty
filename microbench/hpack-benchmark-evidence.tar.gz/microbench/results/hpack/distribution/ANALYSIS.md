# Distribution factorial results

Six round-paired independent forks/cell. Time deltas: negative is faster.
95% t intervals on log ratios; exploratory, unadjusted for multiple comparisons.
No conclusion from a single fork or overlapping/noisy interval.

## CHURN

| Variant | Mean ns/block | Mean B/block |
|---|---:|---:|
| 64-raw | 1436.106 | 336.001 |
| 64-mixed | 165.566 | 336.000 |
| 256-raw | 1450.673 | 336.001 |
| 256-mixed | 151.454 | 336.000 |
| 1024-raw | 1240.331 | 336.001 |
| 1024-mixed | 142.202 | 336.000 |

### Mixing at fixed bucket count
- 64 mixed vs raw: -88.47% [-88.69, -88.25]
- 256 mixed vs raw: -89.55% [-90.04, -89.03]
- 1024 mixed vs raw: -88.53% [-88.92, -88.13]

### Buckets at fixed hash mapping
- 256 vs 64, raw: 0.96% [-3.49, 5.61]
- 1024 vs 64, raw: -13.65% [-17.02, -10.14]
- 256 vs 64, mixed: -8.51% [-10.44, -6.54]
- 1024 vs 64, mixed: -14.11% [-16.52, -11.63]

### Interaction (mixing ratio at larger size / mixing ratio at 64)
- 256: -9.38% [-14.13, -4.37]
- 1024: -0.54% [-5.13, 4.27]

## NAME_HIT

| Variant | Mean ns/block | Mean B/block |
|---|---:|---:|
| 64-raw | 796.250 | 208.000 |
| 64-mixed | 143.630 | 208.000 |
| 256-raw | 794.972 | 208.000 |
| 256-mixed | 127.313 | 208.000 |
| 1024-raw | 539.545 | 208.000 |
| 1024-mixed | 108.613 | 208.000 |

### Mixing at fixed bucket count
- 64 mixed vs raw: -81.96% [-82.50, -81.41]
- 256 mixed vs raw: -83.98% [-84.34, -83.62]
- 1024 mixed vs raw: -79.87% [-80.16, -79.57]

### Buckets at fixed hash mapping
- 256 vs 64, raw: -0.16% [-1.81, 1.52]
- 1024 vs 64, raw: -32.23% [-34.13, -30.28]
- 256 vs 64, mixed: -11.35% [-12.53, -10.15]
- 1024 vs 64, mixed: -24.37% [-25.31, -23.43]

### Interaction (mixing ratio at larger size / mixing ratio at 64)
- 256: -11.21% [-13.03, -9.35]
- 1024: 11.60% [7.67, 15.66]

## REPEATED

| Variant | Mean ns/block | Mean B/block |
|---|---:|---:|
| 64-raw | 49.488 | 48.000 |
| 64-mixed | 41.422 | 20.000 |
| 256-raw | 47.437 | 40.000 |
| 256-mixed | 40.227 | 16.000 |
| 1024-raw | 47.500 | 40.000 |
| 1024-mixed | 41.954 | 24.000 |

### Mixing at fixed bucket count
- 64 mixed vs raw: -17.02% [-28.30, -3.97]
- 256 mixed vs raw: -15.84% [-29.21, 0.06]
- 1024 mixed vs raw: -12.01% [-24.84, 3.01]

### Buckets at fixed hash mapping
- 256 vs 64, raw: -4.26% [-10.65, 2.59]
- 1024 vs 64, raw: -4.20% [-10.26, 2.27]
- 256 vs 64, mixed: -2.89% [-23.17, 22.75]
- 1024 vs 64, mixed: 1.59% [-21.20, 30.97]

### Interaction (mixing ratio at larger size / mixing ratio at 64)
- 256: 1.43% [-19.82, 28.31]
- 1024: 6.04% [-20.68, 41.76]

## COLLISION

| Variant | Mean ns/block | Mean B/block |
|---|---:|---:|
| 64-raw | 993.678 | 168.000 |
| 64-mixed | 1013.344 | 176.000 |
| 256-raw | 979.747 | 160.000 |
| 256-mixed | 1006.606 | 168.000 |
| 1024-raw | 1026.704 | 184.000 |
| 1024-mixed | 1032.798 | 176.000 |

### Mixing at fixed bucket count
- 64 mixed vs raw: 1.94% [-4.07, 8.33]
- 256 mixed vs raw: 2.63% [-2.86, 8.43]
- 1024 mixed vs raw: 0.66% [-10.78, 13.56]

### Buckets at fixed hash mapping
- 256 vs 64, raw: -1.34% [-5.15, 2.61]
- 1024 vs 64, raw: 3.16% [-2.68, 9.34]
- 256 vs 64, mixed: -0.68% [-8.96, 8.35]
- 1024 vs 64, mixed: 1.86% [-7.82, 12.54]

### Interaction (mixing ratio at larger size / mixing ratio at 64)
- 256: 0.68% [-7.58, 9.67]
- 1024: -1.26% [-13.16, 12.27]

