# HPACK distribution factorial — completed

## Completed execution

All six isolated variants built and passed validation; all 144 sequential forks
(720 measurement iterations) completed on 2026-10-10 using Homebrew OpenJDK
21.0.12 and the user-granted exclusive host slot. No production root sources or
benchmark sources were edited. Worktrees/jars remain under
`/tmp/netty-hpack-distribution/{64,256,1024}-{raw,mixed}` and `artifacts/`.
The timing/build slot is released after this completed run.

Results: [ANALYSIS.md](ANALYSIS.md). Durable evidence under `evidence/` includes
144 raw JSONs, 144 compressed timing logs, manifests, exact commands/timestamps,
patches, build/test logs, Surefire XML, wire fingerprints and jar/class provenance.
`evidence/validation.json` records the validation outcome and evidence SHA256s.
Large jars remain in `/tmp`; they are not copied into the repository.

Executed sequentially from `/Users/pmarsh/src/netty` (do not rerun campaign into
existing results; it refuses overwrite):

```sh
python3 microbench/results/hpack/distribution/run.py build --exclusive-host-confirmed
python3 microbench/results/hpack/distribution/run.py campaign --exclusive-host-confirmed
python3 microbench/results/hpack/distribution/analyze.py
python3 microbench/results/hpack/distribution/validate.py
```

Do not run these commands concurrently. `build` is six sequential isolated
reactor builds (not overlays); it stops at any test/build/wire failure. `campaign`
is 144 sequential independent forks (6 variants × 4 scenarios × 6 rounds),
roughly 25–40 minutes including setup. No public API or runtime experiment knobs.
The preparation command was `python3 microbench/results/hpack/distribution/prepare.py`;
it refuses to overwrite the experiment. Do not rerun it on prepared directories.

## Provenance and exact intervention

- Upstream: `014ef8d703` (full commit in `manifest.json`).
- Pinned `/tmp/hpack-candidate-iteration2.patch`, SHA-256:
  `c9199c0869a31d5835261550d78d2cd91f2debf5ae01e9a706eebebd26cb3105`.
- Exact original encoder SHA-256:
  `ab96050bc0c247d7fc158631066b1a6eb19c4c19630044916c3c31b697b8f063`.
- `64-raw` encoder is byte-for-byte original iteration 2. Other variants alter
  only initial NameEntry array length (the value array follows it) and/or the
  bucket helper's mixing threshold. Original helper branch shape is retained:
  threshold 127 for original64/raw, 32767 for larger raw variants, 0 for mixed.
  `mixHash` is unchanged (xor-shift16, multiply 0x85ebca6b, xor-shift13).
- No edits to 64 KiB cap, >4096 admission predicate, chain limit16, eviction,
  entry layout, hash equality, integer encoding, or growth implementation.
- Experimental constructor overrides intentionally disregard arraySizeHint in
  256/1024 variants. Raw large variants also retain raw mapping after later
  growth, whereas original64/raw mixes after growth. These are **4096-only
  experiments**, not production proposals or large-table performance claims.
  WireCheck asserts actual table cap4096 and physical buckets after setup;
  `growThenShrink=false` explicitly, no 65536 preconditioning.
- Current root HpackStateBenchmark / HpackInitializationBenchmark were copied
  once into snapshots and all six trees. Manifest records source hashes.
  Future root/ring edits cannot change the experiment inputs.
- Full iteration2+variant patches and tiny iteration2-relative delta patches
  are in `/tmp/netty-hpack-distribution/*.patch`; all hashes in manifest.
  64/raw delta is empty by design.

JDK21 is pinned in run.py. Builds use a shared preexisting Maven dependency cache
`/tmp/hpack-maven-repository`, **package, never install**, and isolated reactor
outputs. No classes or jars are borrowed from mutable root targets. Every codec
and microbench packaged class is compared to its own reactor target (excluding
module-info descriptors intentionally omitted by shading). Jar SHA256 and
matching-class counts are written per variant. No overlay provenance ambiguity.
Commands, working directories and timestamps are appended to `commands.jsonl`.

## Validation gates (passed)

Each variant runs the full HTTP/2 test pattern in its isolated reactor, followed
by HPACK tests with paranoid leak detection during benchmark-jar packaging.
`-DskipTests=false` is explicit. Exact arguments are encoded in run.py and logged
in commands.jsonl. Logs are in `artifacts/<variant>/http2-tests.log` and
`build-paranoid.log`; Surefire reports remain in each worktree. Existing suite
skips are not changed or suppressed. Any new variant-specific failure must be
investigated, not bypassed or silently excluded.

An untimed external WireCheck probe uses reflection (no production API additions)
to assert 4096 cap, both bucket array lengths, and hash mapping. Benchmark setup
already validates three cycles of round-trip decode, periodic bytes, and two
replay cycles. The probe fingerprints all 2048 steady-state blocks including
length boundaries, comparing exact SHA256 and byte totals against original64/raw
for CHURN, NAME_HIT, REPEATED, COLLISION. All six must match before timing.
The probe is a separate classpath directory, never part of the timed jar.

## Decision plan

All scenarios use encode, tableSize4096, four fields/block, 1 thread, 512MiB fixed
heap, 5×1s warmup + 5×1s measurement, GC profiler. Each fork is an independent JVM.
Six cyclic variant-order rotations give every cell every within-scenario position
once; scenario order rotates too. Do not pool five within-fork iterations as five
independent samples. Initialization allocation is outside these timing results.

`analyze.py` produces `/tmp/netty-hpack-distribution/ANALYSIS.md`: ns/block and
B/block, paired-round mixing contrasts at fixed buckets, bucket contrasts at
fixed mapping, and ratio-of-ratios interactions. Six-fork log-ratio t intervals
are exploratory and unadjusted for multiple comparisons. Report each scenario
separately; no blanket winner from a noisy aggregate.

Questions this isolates:
- CHURN: does name/value bucket dispersion reduce lookup/eviction work enough to
  offset mixing and larger arrays?
- NAME_HIT: same four names, rotating values; distinguish value-chain benefit
  from name-hit cost.
- REPEATED: exact-hit hot-path control, potential mixing overhead.
- COLLISION: intentionally identical full hashes. Neither more buckets nor this
  mixer separates equal hashes; any time difference is overhead/cache/JIT, not
  collision elimination. Admission remains disabled at4096 in every cell.

## Observed conclusions at tableSize=4096

Mixing dominates bucket-count changes for CHURN and NAME_HIT. Round-paired
mixed/raw time changes (exploratory 95% intervals) are:

| Buckets | CHURN | NAME_HIT |
|---|---:|---:|
| 64 | -88.47% [-88.69, -88.25] | -81.96% [-82.50, -81.41] |
| 256 | -89.55% [-90.04, -89.03] | -83.98% [-84.34, -83.62] |
| 1024 | -88.53% [-88.92, -88.13] | -79.87% [-80.16, -79.57] |

At fixed mixed mapping, 1024 vs64 improves CHURN by14.11% and NAME_HIT by24.37%;
at fixed raw mapping, improvements are13.65% and32.23%. Merely moving raw64 to
raw256 has no clear benefit. These are workload-specific results, not a general
recommendation to allocate1024 buckets or a large-table production validation.

CHURN allocations remain336 B/block and NAME_HIT208 B/block in every cell.
REPEATED mean allocations (raw/mixed) are48/20,40/16,40/24 B/block for64,256,1024;
individual forks occupy roughly0/24/48 B/block modes. Its64-bucket mixed/raw time
change is-17.02% [-28.30,-3.97];256 and1024 intervals include zero. Allocation
and timing modes are consistent with JIT/escape-analysis variability; do not
claim a deterministic source-level allocation reduction.

COLLISION mixed/raw changes are+1.94%,+2.63%,+0.66%, all intervals include zero.
Allocation forks occupy160/208 B/block modes; cell means are in ANALYSIS.md.
Equal full hashes remain equal after mixing: there is no collision-elimination
claim. Initialization/array allocation is outside these steady-state timings.

All six variants produce identical exact wire SHA256 and byte totals over2048
blocks per scenario: CHURN186196, NAME_HIT105386, REPEATED8192, COLLISION147456.
The probe confirmed actual4096 cap, physical bucket sizes and mapping.

## Transparent test adaptation and analyzer repair

The first256-raw HTTP/2 run failed two1200-entry large-table tests (122 entries
retained). Sequential decimal fixtures concentrate raw hash buckets and trigger
the unchanged chain16 admission guard above4096. This was not a fixed64-bucket
white-box assertion failure. `adapt-tests.py` changed only the two reuse/eviction
tests in256-raw and1024-raw to deterministic seeded12-hex-character fixtures;
1200-entry retention, reuse, round-trip, resize and eviction assertions remain.
All deliberately colliding admission/security tests remain unchanged and ran.
This fixture adaptation does not make raw large-table distribution suitable for
production; the experiment only claims results at4096.

The original manifest and first failure log are preserved, as are exact test-only
and combined adapted patches. Encoder and benchmark hashes did not change.
Manifest `patch_sha256` for these two variants now covers the adapted test source;
`original_patch_sha256` retains the prepared patch hash. Build resume validates
already verified jars instead of rebuilding them. All variants finished with
1642 HTTP/2 tests, zero failures/errors, five existing skips; paranoid HPACK
packaging also passed. Each jar matched1461 reactor-produced classes.

The completed campaign initially exposed an analyzer compatibility error:
this JMH1.36 build prefixes GC metric names with a middle dot. `analyze.py` now
normalizes that prefix; every original timing/allocation sample was retained.
No forks were discarded or rerun. `validate.py` independently checks the complete
factorial, parameters, iterations, success logs, jar/source hashes, wire equality
and Surefire results before archiving evidence.
