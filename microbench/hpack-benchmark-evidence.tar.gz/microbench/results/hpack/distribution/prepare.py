#!/usr/bin/env python3
"""Low-CPU preparation only; no compilation or timing."""
import hashlib, json, pathlib, subprocess, shutil, difflib
HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[3]
BASE = '014ef8d703'
ENC = pathlib.Path('codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java')
BENCH = pathlib.Path('microbench/src/main/java/io/netty/handler/codec/http2')
WORK = pathlib.Path('/tmp/netty-hpack-distribution')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*args, cwd=ROOT): return subprocess.check_output(args, cwd=cwd, text=True)
def main():
    assert not WORK.exists(), 'refusing to overwrite prepared experiment'
    WORK.mkdir()
    patch = WORK / 'iteration2.patch'
    shutil.copyfile('/tmp/hpack-candidate-iteration2.patch', patch)
    assert sha(patch) == 'c9199c0869a31d5835261550d78d2cd91f2debf5ae01e9a706eebebd26cb3105'
    snapshots = WORK / 'benchmarks'; snapshots.mkdir()
    for name in ['HpackStateBenchmark.java', 'HpackInitializationBenchmark.java']:
        shutil.copyfile(ROOT / BENCH / name, snapshots / name)
    variants = {}
    for buckets in [64, 256, 1024]:
        for mode in ['raw', 'mixed']:
            name = f'{buckets}-{mode}'; tree = WORK / name
            run('git', 'worktree', 'add', '--detach', str(tree), BASE)
            run('git', 'apply', str(patch), cwd=tree)
            original = (tree / ENC).read_text()
            assert hashlib.sha256(original.encode()).hexdigest() == 'ab96050bc0c247d7fc158631066b1a6eb19c4c19630044916c3c31b697b8f063'
            source = original
            if buckets != 64:
                old = 'new NameEntry[findNextPositivePowerOfTwo(max(2, min(arraySizeHint, 128)))]'
                assert source.count(old) == 1
                source = source.replace(old, f'new NameEntry[{buckets}]')
            # Retain the original branch shape and mixHash implementation. Never touch cap/admission.
            if mode == 'mixed' or buckets != 64:
                old = 'hashMask <= 127 ? h : mixHash(h)'
                assert source.count(old) == 1
                source = source.replace(old, 'hashMask <= %d ? h : mixHash(h)' %
                                        (0 if mode == 'mixed' else 32767))
            (tree / ENC).write_text(source)
            for p in snapshots.iterdir(): shutil.copyfile(p, tree / BENCH / p.name)
            delta = WORK / (name + '.delta.patch')
            delta.write_text(''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True),
                                                       fromfile='a/' + str(ENC), tofile='b/' + str(ENC))))
            full = WORK / (name + '.patch')
            full.write_text(run('git', 'diff', '--', 'codec-http2', cwd=tree))
            run('git', 'diff', '--check', cwd=tree)
            variants[name] = dict(tree=str(tree), buckets=buckets, mode=mode,
                                  encoder_sha256=sha(tree / ENC), patch_sha256=sha(full), delta_sha256=sha(delta))
    manifest = dict(base=run('git','rev-parse',BASE).strip(), patch_sha256=sha(patch),
                    benchmark_sha256={p.name:sha(p) for p in snapshots.iterdir()}, variants=variants)
    (WORK / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    shutil.copyfile(WORK / 'manifest.json', HERE / 'manifest.json')
    print('Sources ready:', WORK, '(builds/tests/timing NOT run)')
if __name__ == '__main__': main()
