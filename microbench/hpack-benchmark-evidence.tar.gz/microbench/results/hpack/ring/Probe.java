package io.netty.handler.codec.http2;
import io.netty.buffer.ByteBuf;
import java.lang.reflect.*;
import java.security.MessageDigest;
import java.util.*;

/** Explicit compressed-oops structural accounting, excluding shared text/corpus and output buffers. */
public final class Probe {
    static Object field(Object o,String name) throws Exception {
        Field f=o.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(o);
    }
    static int width(Class<?> c) { return !c.isPrimitive()?4:c==long.class||c==double.class?8:c==int.class||c==float.class?4:c==short.class||c==char.class?2:1; }
    static long align(long n) { return (n+7)&~7L; }
    static long[] account(Object o,IdentityHashMap<Object,Boolean> seen) throws Exception {
        if(o==null||o==HpackUtil.HUFFMAN_CODES||o==HpackUtil.HUFFMAN_CODE_LENGTHS||seen.put(o,true)!=null) return new long[3];
        Class<?> c=o.getClass();long[] result=new long[3];
        if(c.isArray()) {
            result[0]=result[1]=align(16L+(long)Array.getLength(o)*width(c.getComponentType()));result[2]=1;
            if(!c.getComponentType().isPrimitive() && !(o instanceof CharSequence[])) for(int i=0;i<Array.getLength(o);i++) add(result,account(Array.get(o,i),seen));
            return result;
        }
        if(!c.getName().startsWith("io.netty.handler.codec.http2.Hpack")) return result;
        long bytes=12;
        for(Class<?> k=c;k!=Object.class;k=k.getSuperclass()) for(Field f:k.getDeclaredFields()) {
            if(Modifier.isStatic(f.getModifiers()))continue;
            bytes+=width(f.getType()); f.setAccessible(true);
            if(!f.getType().isPrimitive()) add(result,account(f.get(o),seen));
        }
        result[0]+=align(bytes);result[2]++; return result;
    }
    static void add(long[] a,long[] b) {for(int i=0;i<3;i++)a[i]+=b[i];}
    static String arrays(Object o) throws Exception {
        StringBuilder s=new StringBuilder("{");
        for(Field f:o.getClass().getDeclaredFields()) if(!Modifier.isStatic(f.getModifiers())&&f.getType().isArray()) {
            f.setAccessible(true);Object a=f.get(o);if(s.length()>1)s.append(',');s.append('"').append(f.getName()).append("\":").append(a==null?0:Array.getLength(a));
        }
        return s.append('}').toString();
    }
    static void memory(String scenario,int table,HpackEncoder encoder,String extra) throws Exception {
        long[] size=account(encoder,new IdentityHashMap<Object,Boolean>());
        String ring="";
        try {ring=",\"oldest\":"+field(encoder,"oldest")+",\"entryCount\":"+field(encoder,"entryCount");}catch(NoSuchFieldException ignored) { }
        System.out.println("{\"scenario\":\""+scenario+"\",\"table\":"+table+",\"structuralBytes\":"+size[0]+",\"arrayBytes\":"+size[1]+",\"objects\":"+size[2]+",\"arrays\":"+arrays(encoder)+ring+extra+"}");
    }
    public static void main(String[] args) throws Exception {
        int[] tables=args[0].equals("upstream")?new int[]{256,4096}:new int[]{256,4096,65536};
        for(int table:tables) {
            memory("EMPTY",table,HpackStateBenchmark.newEncoder(table),"");
            HpackEncoder first=HpackStateBenchmark.newEncoder(table);
            ByteBuf output=io.netty.buffer.Unpooled.buffer(16384,16384);
            Http2Headers headers=new DefaultHttp2Headers(false);
            for(int i=0;i<4;i++)headers.add("x-first-"+i,"first-value-"+i);
            try {first.encodeHeaders(3,output,headers,Http2HeadersEncoder.NEVER_SENSITIVE);memory("FIRST_BLOCK",table,first,"");}finally{output.release();}
        }
        for(int table:tables) {
            String[] scenarios=table==4096?new String[]{"CHURN","NAME_HIT","REPEATED","COLLISION","WORKING_SET","MIXED","STATIC","SENSITIVE","HUFFMAN"}:table==256?new String[]{"REPEATED","NAME_HIT","COLLISION"}:new String[]{"WORKING_SET128","WORKING_SET384","WORKING_SET768","CHURN"};
            for(String scenario:scenarios) {
                HpackStateBenchmark b=new HpackStateBenchmark();b.tableSize=table;b.scenario=HpackStateBenchmark.Scenario.valueOf(scenario);
                try {
                    b.setup();HpackEncoder e=(HpackEncoder)field(b,"encoder");
                    if(table<=4096&&!args[0].equals("upstream")) {
                        if(Array.getLength(field(e,"nameEntries"))!=64||Array.getLength(field(e,"nameValueEntries"))!=64)throw new AssertionError("buckets");
                        Method bucket=HpackEncoder.class.getDeclaredMethod("bucket",int.class);bucket.setAccessible(true);
                        Method mix=HpackEncoder.class.getDeclaredMethod("mixHash",int.class);mix.setAccessible(true);
                        for(int h:new int[]{0,1,-1,1234567,Integer.MIN_VALUE,0x12345678}) {
                            int expected=(args[0].endsWith("Mixed")?(Integer)mix.invoke(null,h):h)&63;
                            if((Integer)bucket.invoke(e,h)!=expected)throw new AssertionError("mapping");
                        }
                    }
                    MessageDigest d=MessageDigest.getInstance("SHA-256");long total=0;
                    for(ByteBuf block:(ByteBuf[])field(b,"wire")) {int n=block.writerIndex();for(int shift=24;shift>=0;shift-=8)d.update((byte)(n>>>shift));for(int i=0;i<n;i++)d.update(block.getByte(i));total+=n;}
                    StringBuilder hex=new StringBuilder();for(byte x:d.digest())hex.append(String.format("%02x",x&255));
                    memory(scenario,table,e,",\"bytes\":"+total+",\"wire\":\""+hex+"\"");
                    // More than 2048-slot maximum ring capacity in insertions for churning large sets.
                    Field oldest=null;
                    try {oldest=HpackEncoder.class.getDeclaredField("oldest");oldest.setAccessible(true);}catch(NoSuchFieldException ignored) { }
                    int previous=oldest==null?0:oldest.getInt(e);int wraps=0;
                    for(int i=0;i<32768;i++) {
                        b.encode();
                        if(oldest!=null) {int current=oldest.getInt(e);if(current<previous)wraps++;previous=current;}
                    }
                    if(oldest!=null&&table==65536&&scenario.equals("CHURN")&&wraps<1)throw new AssertionError("No observed ring wrap");
                    memory(scenario+"_AFTER32768",table,e,",\"observedOldestWraps\":"+wraps);
                } finally {b.tearDown();}
            }
        }
    }
}
