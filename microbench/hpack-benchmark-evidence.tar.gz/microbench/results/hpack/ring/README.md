# Ring prototype campaign — complete; do not promote ring

Completed 2026-10-11 00:17:52 UTC: **237 independent JVM forks, 1,185 measured
iterations**, about 42 minutes timing and 51m13s from initial preparation
(23:26:38 UTC) through timing completion. Final evidence validation finished
within approximately54 minutes of preparation. Full results: [ANALYSIS.md](ANALYSIS.md).
During this campaign root production and benchmark sources were not edited.
Subsequently, root was restored to the exact measured **linkedMixed64** candidate;
**ring is rejected on performance**, not retained as production. The ring patches,
test and all raw results remain preserved here. See the
[retention/provenance report](../linkedMixed-retained/README.md) for current tests
and upstream comparisons. No commit or new timing was performed during restoration.
Exclusive performance slot is released after this completed campaign.

## Decision

**Retain linkedMixed (iteration2 + always-mixed initial64), not the ring.**
The campaign recommendation was subsequently applied with explicit user authorization.
It is not a blanket upstream non-regression claim. Distribution previously
identified mixing as the dominant improvement; this matched experiment shows
where the ring adds something beyond mixing and where it gives it back.

Matched ringMixed versus linkedMixed at64 buckets:

- CHURN4096 improves **10.10%**, paired95% interval **[1.70,17.79]% faster**;
  allocation336→48 B/block. NAME_HIT4096 is only3.47% faster, interval crosses zero,
  while allocation208→48 B/block. Most of the large improvement versus upstream
  is mixing, not the ring. Raw-policy comparisons misleadingly make the ring
  look more compelling (CHURN−40.89%, NAME_HIT−35.42%).
- Exact hits regress: **REPEATED4096 +23.10% [6.38,42.45]**, 40.40→49.38ns/block;
  **REPEATED256 +19.70% [2.08,40.35]**. Fork allocation modes differ (4096 means
  linked16/ring44B; 256 linked0/ring24B). These are JIT/escape-analysis modes,
  not evidence that an exact lookup explicitly allocates ring entries. No
  allocation-mode filtering or fork removal was done.
- **NAME_HIT256 +17.88% [16.80,18.97]**, **COLLISION256 +57.14% [31.27,88.10]**.
  COLLISION4096 estimate+8.90%, interval[-15.30,+40.02] is inconclusive, not proof
  of either regression or equivalence. Mixing cannot separate equal full hashes.
- WORKING_SET4096+14.16% [10.56,17.88]. Other five-scenario controls have three
  forks: mixed/static/sensitive/Huffman comparisons are mostly inconclusive.
- Constructor4096 allocation is **656B for both ring and linked** (upstream744B).
  Ring constructor is29.76% faster, but a fresh encoder plus its first four-field
  dynamic block costs **1376B versus992B**, and **182.44 versus161.92ns**:
  **+12.67% [11.45,13.91]**. Lazy slots defer cost; they do not remove it.
  This is repeated fresh-context first-block work, not cold JVM startup latency.
- At65536, CHURN/wrap improves23.14% [19.10,26.97]% and336→48B/block. Retained
  working sets128/384/768 show no ring exact-hit advantage (point estimates
  +5.76/+11.47/+10.64%). Upstream is deliberately absent: it clamps65536 to4096,
  and the unchanged benchmark correctly rejects that unsupported configuration.

## Memory: lower churn allocation is not universally lower retention

Reflection accounts for **populated** backing arrays and reachable structural
entry nodes. Explicit assumptions: compressed4B references/class pointers,
16B array headers,8B alignment, int4B/boolean1B. JVM flags were captured.
Array byte totals are exact under these assumptions. Object totals use
align8(12 + all nonstatic field widths), not JVM-specific field placement or JOL;
call them modeled estimates, not exact heap sizes. Shared name/value texts,
corpus/headers/output and shared HpackUtil Huffman constant arrays are excluded.
The probe originally followed those shared Huffman arrays; this was corrected
before final analysis, removing1328B incorrectly attributed to each upstream
encoder. Allocation results were unaffected.

At4096 ring/linked modeled total retained bytes are CHURN5024/6272,
NAME_HIT5024/4104, COLLISION5024/3448, and four exact-hit entries1328/944.
Ring pays for two reference arrays, six int slot arrays and one boolean array,
rounded to a power of two, even when names are heavily shared. It saves distinct
name/value node objects on CHURN but **retains more for repeated names and small
populated tables**. First insertion allocates16 slots:672B of slot arrays;
first four linked insertions retain288B in nodes, explaining the384B difference.

At65536 CHURN, ring arrays75952B / modeled total76064B versus linked arrays8224B /
total99056B. At128/384/768 retained values, modeled totals are12704/25376/42272B
versus13584/23824/39184B. Power-of-two spare slot capacity matters. Full array
lengths, occupancy and oldest slot before/after32768 extra blocks are in probes.
Do not infer all workloads save retained memory from the GC allocation reduction.

## Fairness, validation and security

Five isolated reactor builds under `/tmp/netty-hpack-ring`: ringRaw (root as-is),
ringMixed (only bucket threshold127→0), linkedRaw (distribution64raw, byte-identical
iteration2 encoder), linkedMixed (distribution64mixed), and upstream014ef8d703.
No root target overlays; all jars rebuilt using package, never install. Every
packaged codec/microbench class was compared to its own reactor output. All three
benchmark sources are byte-identical across all five jars, hashes in manifest.
FirstUseBenchmark.java is isolated in this experiment and each worktree.

At256/4096 the probe asserts both64-bucket arrays and raw/mixed mapping for all
four candidates. At65536 both matched candidates grow to1024 mixed buckets.
Bucket growth, local64KiB cap, admission>4096, chain16, sensitive handling and wire
rules were unchanged. Full HTTP/2 tests passed: ring1645, linked1642, existing
five skips each; paranoid HPACK127/124 respectively. Upstream's own suite also
passed. Ring wrap/growth/security tests run in both ring variants. Full logs and
Surefire reports are retained. Exact wire digests/lengths match all five variants
for all9 scenarios4096 plus REPEATED/NAME_HIT/COLLISION256; all four supported
variants match at65536 for128/384/768 working sets and CHURN. Fixture setup checks
three decoded cycles, periodic captured bytes and two replay cycles. The probe
also executes32768 extra blocks, observing **64 oldest-index wraps** in ring
CHURN65536 without backing growth; the full test suite exercises wrapped growth,
every byte limit, shrink/clear and sensitive entries.

All237 timing forks use one thread, GC profiler,5×1s warmup +5×1s measurement,
fixed512MiB heap, pinned Homebrew OpenJDK21.0.12. Important matched cases have six
rounds with all six three-variant permutations; remaining9-scenario coverage,
init/first-use,64KiB and raw-policy contrasts have three forks. Three-way3-fork
cells use rotations. Two-way3-fork cells have AB/BA/AB: transparently imperfect
balance; their intervals are low-powered. CHURN65536 was added after the first
three batches once its wire/periodicity probe passed; its three paired rounds
therefore run later than other large-table cases. No samples were discarded.

## Reproduction and durable evidence

`run.py`, `Probe.java`, `FirstUseBenchmark.java`, `analyze.py`, `validate.py`,
patches, manifest hashes, commands.jsonl, schedule, raw JSON/logs, test/build logs,
probe outputs and JVM flags live here. Large jars/worktrees stay in `/tmp`.
`root-codec.patch` plus HpackEncoderRingTest.java preserve the prototype including
the untracked ring test; per-variant patches contain tracked codec changes.
Original existing distribution and iteration2 jars are untouched.

Executed commands are fully timestamped in commands.jsonl. Driver commands:

```sh
python3 microbench/results/hpack/ring/run.py prepare build probe
# Build's first attempt failed new FirstUseBenchmark checkstyle; fixed copyright,
# explicit imports and braces, then rebuilt all five with all checks enabled.
python3 microbench/results/hpack/ring/run.py build probe
# Initial upstream65536 probe correctly failed unsupported cap; documented above.
# Campaign executes at most40 new forks per bounded call; six calls completed237.
python3 microbench/results/hpack/ring/run.py campaign
python3 microbench/results/hpack/ring/analyze.py
python3 microbench/results/hpack/ring/validate.py
```

Do not rerun prepare/build over completed artifacts. Campaign resumes only
validated completed JSON/log pairs; it never overwrites timing results. First
checkstyle failure and unsupported-upstream probe failure logs are retained.
No benchmark checks, tests, warnings or wire guards were disabled.
