/*
 * Copyright 2026 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package io.netty.handler.codec.http2;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.microbench.util.AbstractMicrobenchmark;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Param;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.TearDown;

import java.util.concurrent.TimeUnit;

@State(Scope.Thread)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
public class FirstUseBenchmark extends AbstractMicrobenchmark {
    @Param({"4096"})
    public int tableSize;
    private ByteBuf output;
    private Http2Headers headers;

    @Setup
    public void setup() {
        output = Unpooled.buffer(16384, 16384);
        headers = new DefaultHttp2Headers(false);
        for (int i = 0; i < 4; i++) {
            headers.add("x-first-" + i, "first-value-" + i);
        }
    }

    @Benchmark
    public Object firstBlock() throws Http2Exception {
        HpackEncoder encoder = HpackStateBenchmark.newEncoder(tableSize);
        output.clear();
        encoder.encodeHeaders(3, output, headers, Http2HeadersEncoder.NEVER_SENSITIVE);
        return encoder;
    }

    @TearDown
    public void close() {
        output.release();
    }
}
