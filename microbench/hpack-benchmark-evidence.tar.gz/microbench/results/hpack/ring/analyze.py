#!/usr/bin/env python3
"""Fork-level paired log-ratio intervals; never count within-fork samples as independent."""
import collections, hashlib, json, math, pathlib, statistics as s
P=pathlib.Path(__file__).resolve().parent
cells=collections.defaultdict(dict)
def alloc(row): return next(v['score'] for k,v in row['secondaryMetrics'].items() if k.lstrip('·')=='gc.alloc.rate.norm')
for group,r,name,scenario,table,kind in json.loads((P/'schedule.json').read_text()):
    row=json.loads((P/'raw'/f'{group}-r{r}-{name}-{scenario}-{table}.json').read_text())[0]
    cells[group,scenario,table,name][r]=(row['primaryMetric']['score'],alloc(row))
def contrast(group,scenario,table,a,b):
    aa=cells[group,scenario,table,a];bb=cells[group,scenario,table,b]
    rounds=sorted(aa.keys()&bb.keys());x=[math.log(aa[r][0]/bb[r][0]) for r in rounds];n=len(x)
    mu=s.mean(x); half={3:4.30265273,6:2.57058184}[n]*s.stdev(x)/math.sqrt(n)
    return [100*math.expm1(v) for v in (mu,mu-half,mu+half)]
def fmt(c): return f'{c[0]:+.2f}% [{c[1]:+.2f}, {c[2]:+.2f}]'
lines=['# HPACK ring campaign — completed','', '237 independent sequential JVM forks / 1,185 measured iterations. All forks: GC profiler, 5×1 s warmup and 5×1 s measurement, one thread, fixed 512 MiB heap, JDK 21.0.12. Four fields/block. Lower is better.','', 'Six-round matched important cells use all six permutations of ringMixed/linkedMixed/upstream. Three-round three-way cells use cyclic rotations; two-way cells use AB/BA/AB (one extra AB, not perfectly balanced). Ratios below are paired-round geometric timing ratios with Student-t 95% intervals on log ratios (df=5 or2). They are exploratory, not multiple-comparison adjusted. Table means use arithmetic fork means. GC profiler bytes include harness/JIT escape-analysis modes.','']
summary=[]
for group in ['focus','small','rest','large','init','first','raw']:
    entries=sorted({(sc,t) for g,sc,t,n in cells if g==group})
    names=['ringRaw','linkedRaw'] if group=='raw' else ['ringMixed','linkedMixed'] if group=='large' else ['ringMixed','linkedMixed','upstream']
    lines+=['## '+group,'','| Scenario / bytes | '+ ' | '.join(n+' ns / B per op' for n in names)+' | Ring vs linked 95% CI |'+(' Ring vs upstream 95% CI |' if len(names)==3 else ''),'|---|'+'---:|'*(len(names)+1+(len(names)==3))]
    for sc,t in entries:
        text=[f'{sc} / {t}']
        for n in names:
            v=list(cells[group,sc,t,n].values());text.append(f'{s.mean(x[0] for x in v):.2f} / {s.mean(x[1] for x in v):.2f}')
        c=contrast(group,sc,t,names[0],names[1]);text.append(fmt(c))
        if len(names)==3:text.append(fmt(contrast(group,sc,t,names[0],names[2])))
        lines.append('| '+' | '.join(text)+' |')
        summary.append(dict(group=group,scenario=sc,table=t,ring_vs_linked=c))
    lines+=['']
lines+=['## Exact-hit allocation modes','','Fork means (B/block), preserved rather than averaged away:','']
for table,group in [(4096,'focus'),(256,'small')]:
    for n in ['ringMixed','linkedMixed','upstream']:
        lines.append(f'- REPEATED {table} {n}: '+', '.join(f'{v[1]:.2f}' for _,v in sorted(cells[group,'REPEATED',table,n].items())))
lines+=['','## Populated retained structural memory','','Explicit modeled accounting: compressed references/class pointers, 8-byte object alignment, array header16B, reference/int element4B, boolean1B. Array byte totals are exact under these assumptions; object totals approximate field packing as align8(12 + field widths), so are **not JOL-measured heap sizes**. Identity traversal includes encoder-owned Hpack entry nodes/sentinels/Huffman helper arrays; excludes shared CharSequence objects/backing text, headers, corpus and output buffers. It does not measure transient allocation. See Probe.java and raw *-probe.jsonl.','', '| State / table | ringMixed arrays / modeled total B | linkedMixed arrays / modeled total B | upstream arrays / modeled total B |','|---|---:|---:|---:|']
probes={n:{(r['scenario'],r['table']):r for r in [json.loads(l) for l in (P/(n+'-probe.jsonl')).read_text().splitlines() if l.startswith('{')]} for n in ['ringMixed','linkedMixed','upstream']}
for sc,t in [('EMPTY',4096),('FIRST_BLOCK',4096),('CHURN',4096),('NAME_HIT',4096),('REPEATED',4096),('COLLISION',4096),('WORKING_SET128',65536),('WORKING_SET384',65536),('WORKING_SET768',65536),('CHURN',65536),('CHURN_AFTER32768',65536)]:
    row=[f'{sc} / {t}']
    for n in probes:
        r=probes[n].get((sc,t));row.append(f"{r['arrayBytes']} / {r['structuralBytes']}" if r else 'unsupported')
    lines.append('| '+' | '.join(row)+' |')
(P/'ANALYSIS.md').write_text('\n'.join(lines)+'\n')
(P/'contrasts.json').write_text(json.dumps(summary,indent=2)+'\n')
print('\n'.join(lines))
