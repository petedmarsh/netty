#!/usr/bin/env python3
"""Isolated sequential campaign. No root production edits; never overwrite raw results."""
import datetime, hashlib, json, os, pathlib, shlex, shutil, subprocess, sys, zipfile, time
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parents[3]
WORK=pathlib.Path('/tmp/netty-hpack-ring')
JAVA_HOME=pathlib.Path('/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home')
ENC=pathlib.Path('codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java')
BENCH=pathlib.Path('microbench/src/main/java/io/netty/handler/codec/http2')
NAMES=['ringRaw','ringMixed','linkedRaw','linkedMixed','upstream']
PRIMARY=['ringMixed','linkedMixed','upstream']
FOCUS=['CHURN','NAME_HIT','REPEATED','COLLISION']
REST=['WORKING_SET','MIXED','STATIC','SENSITIVE','HUFFMAN']
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def execute(args,cwd,log):
    args=list(map(str,args)); log.parent.mkdir(parents=True,exist_ok=True)
    with (HERE/'commands.jsonl').open('a') as f: f.write(json.dumps(dict(time=stamp(),cwd=str(cwd),argv=args,shell=shlex.join(args)))+'\n')
    env=dict(os.environ,JAVA_HOME=str(JAVA_HOME),PATH=str(JAVA_HOME/'bin')+':'+os.environ['PATH'])
    with log.open('w') as out: subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
def prepare():
    WORK.mkdir(exist_ok=False)
    manifest={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'started':stamp(),'variants':{}}
    (HERE/'root-codec.patch').write_bytes(subprocess.check_output(['git','diff','--','codec-http2'],cwd=ROOT))
    shutil.copyfile(ROOT/'codec-http2/src/test/java/io/netty/handler/codec/http2/HpackEncoderRingTest.java',HERE/'HpackEncoderRingTest.java')
    for name in NAMES:
        tree=WORK/name
        execute(['git','worktree','add','--detach',tree,manifest['head']],ROOT,HERE/'build'/f'{name}-worktree.log')
        if name.startswith('ring'):
            execute(['git','apply',HERE/'root-codec.patch'],tree,HERE/'build'/f'{name}-apply.log')
            shutil.copyfile(HERE/'HpackEncoderRingTest.java',tree/'codec-http2/src/test/java/io/netty/handler/codec/http2/HpackEncoderRingTest.java')
            if name=='ringMixed':
                p=tree/ENC; s=p.read_text(); assert s.count('hashMask <= 127 ? h : mixHash(h)')==1
                p.write_text(s.replace('hashMask <= 127 ? h : mixHash(h)','hashMask <= 0 ? h : mixHash(h)'))
        elif name.startswith('linked'):
            patch=pathlib.Path('/tmp/netty-hpack-distribution')/('64-mixed.patch' if name=='linkedMixed' else '64-raw.patch')
            execute(['git','apply',patch],tree,HERE/'build'/f'{name}-apply.log')
        for source in ['HpackStateBenchmark.java','HpackInitializationBenchmark.java']:
            shutil.copyfile(ROOT/BENCH/source,tree/BENCH/source)
        shutil.copyfile(HERE/'FirstUseBenchmark.java',tree/BENCH/'FirstUseBenchmark.java')
        patch=HERE/(name+'.patch'); patch.write_bytes(subprocess.check_output(['git','diff','--','codec-http2'],cwd=tree))
        manifest['variants'][name]={'tree':str(tree),'encoder_sha256':sha(tree/ENC),'patch_sha256':sha(patch)}
    manifest['sources']={s:sha(WORK/NAMES[0]/BENCH/s) for s in ['HpackStateBenchmark.java','HpackInitializationBenchmark.java','FirstUseBenchmark.java']}
    (HERE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def build():
    m=json.loads((HERE/'manifest.json').read_text())
    for name in NAMES:
        tree=WORK/name; out=HERE/'build'; jar=WORK/(name+'.jar')
        common=['./mvnw','-Dmaven.repo.local=/tmp/hpack-maven-repository','-Dsurefire.failIfNoSpecifiedTests=false','-DskipTests=false']
        execute(common+['-pl','codec-http2','-am','-P!mac','-Dtest=io.netty.handler.codec.http2.*Test','test'],tree,out/f'{name}-http2.log')
        execute(common+['-pl','microbench','-am','-Pbenchmark-jar,!mac','-Dtest=Hpack*Test','-Dio.netty.leakDetection.level=paranoid','package'],tree,out/f'{name}-package.log')
        shutil.copyfile(tree/'microbench/target/microbenchmarks.jar',jar)
        count=0
        with zipfile.ZipFile(jar) as z:
            for module in ['codec-http2','microbench']:
                base=tree/module/'target/classes'
                for p in base.rglob('*.class'):
                    rel=p.relative_to(base).as_posix()
                    if rel.endswith('module-info.class'): continue
                    assert z.read(rel)==p.read_bytes(),rel
                    count+=1
        assert sha(tree/ENC)==m['variants'][name]['encoder_sha256']
        assert all(sha(tree/BENCH/s)==h for s,h in m['sources'].items())
        m['variants'][name].update(jar=str(jar),jar_sha256=sha(jar),matching_classes=count)
        (HERE/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
        reports=HERE/'tests'/name
        shutil.copytree(tree/'codec-http2/target/surefire-reports',reports)
        print('BUILT',name,stamp(),flush=True)
def probe():
    out=WORK/'probe';out.mkdir(exist_ok=True)
    execute([JAVA_HOME/'bin/javac','-cp',WORK/'ringMixed.jar','-d',out,HERE/'Probe.java'],WORK,HERE/'probe-compile.log')
    for name in NAMES:
        execute([JAVA_HOME/'bin/java','-Xms512m','-Xmx512m','-cp',str(out)+os.pathsep+str(WORK/(name+'.jar')),'io.netty.handler.codec.http2.Probe',name],WORK,HERE/(name+'-probe.jsonl'))
    rows={n:[json.loads(l) for l in (HERE/(n+'-probe.jsonl')).read_text().splitlines() if l.startswith('{')] for n in NAMES}
    wires={n:{(r['scenario'],r['table']):(r['wire'],r['bytes']) for r in rr if 'wire' in r} for n,rr in rows.items()}
    assert all(all(w[k]==v for k,v in wires['upstream'].items()) for w in wires.values()),'wire mismatch'
    assert all(wires[n]==wires['ringMixed'] for n in NAMES if n!='upstream'),'large wire mismatch'
    print('WIRE AND MEMORY PROBES PASS',flush=True)
def campaign():
    m=json.loads((HERE/'manifest.json').read_text()); cells=[]
    # All 6 permutations for three-way comparisons, balanced positions and pair precedence.
    orders=[PRIMARY,PRIMARY[::-1],[PRIMARY[1],PRIMARY[2],PRIMARY[0]],[PRIMARY[0],PRIMARY[2],PRIMARY[1]],[PRIMARY[2],PRIMARY[0],PRIMARY[1]],[PRIMARY[1],PRIMARY[0],PRIMARY[2]]]
    groups=[('focus',FOCUS,4096,6,PRIMARY,'state'),('small',['REPEATED','NAME_HIT','COLLISION'],256,6,PRIMARY,'state'),('rest',REST,4096,3,PRIMARY,'state'),('large',['WORKING_SET128','WORKING_SET384','WORKING_SET768','CHURN'],65536,3,['ringMixed','linkedMixed'],'state'),('init',['encoder'],4096,3,PRIMARY,'init'),('first',['firstBlock'],4096,3,PRIMARY,'first'),('raw',FOCUS,4096,3,['ringRaw','linkedRaw'],'state')]
    # Interleave campaign groups by round rather than finish one variant first.
    for r in range(6):
        for group,scenarios,table,rounds,variants,kind in groups:
            if r>=rounds: continue
            order=orders[r] if variants==PRIMARY else (variants if r%2==0 else variants[::-1])
            if rounds==3 and variants==PRIMARY: order=PRIMARY[r:]+PRIMARY[:r]
            sc=scenarios[r%len(scenarios):]+scenarios[:r%len(scenarios)]
            for scenario in sc:
                for name in order: cells.append((group,r+1,name,scenario,table,kind))
    (HERE/'schedule.json').write_text(json.dumps(cells,indent=2)+'\n')
    executed=0
    for group,r,name,scenario,table,kind in cells:
        stem=f'{group}-r{r}-{name}-{scenario}-{table}'; target=HERE/'raw'/(stem+'.json')
        if target.exists():
            prior=json.loads(target.read_text())
            assert len(prior)==1 and len(prior[0]['primaryMetric']['rawData'][0])==5
            assert '# Run complete.' in (HERE/'raw'/(stem+'.log')).read_text()
            continue
        if executed>=int(os.environ.get('RING_MAX_FORKS','40')): return
        jar=WORK/(name+'.jar'); assert sha(jar)==m['variants'][name]['jar_sha256']
        benchmark={'state':'.*HpackStateBenchmark.encode$','init':'.*HpackInitializationBenchmark.encoder$','first':'.*FirstUseBenchmark.firstBlock$'}[kind]
        args=[JAVA_HOME/'bin/java','-jar',jar,benchmark,'-p','tableSize='+str(table)]
        if kind=='state': args+=['-p','growThenShrink=false','-p','scenario='+scenario]
        args+=['-f','1','-wi','5','-w','1s','-i','5','-r','1s','-t','1','-prof','gc','-foe','true','-jvmArgs','-Xms512m -Xmx512m','-rf','json','-rff',target]
        execute(args,WORK,HERE/'raw'/(stem+'.log'))
        rows=json.loads(target.read_text());assert len(rows)==1 and len(rows[0]['primaryMetric']['rawData'][0])==5
        executed+=1
        print(stem,rows[0]['primaryMetric']['score'],stamp(),flush=True)
    assert subprocess.check_output(['git','diff','--','codec-http2'],cwd=ROOT)==(HERE/'root-codec.patch').read_bytes()
    (HERE/'completed.json').write_text(json.dumps({'completed':stamp(),'forks':len(cells),'measurement_iterations':len(cells)*5},indent=2)+'\n')
if __name__=='__main__':
    for phase in sys.argv[1:]: globals()[phase]()
