/*
 * Copyright 2026 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package io.netty.handler.codec.http2;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class HpackEncoderRingTest {
    @Test
    void everyByteLimitGrowingAndShrinking() throws Exception {
        HpackEncoder encoder = new HpackEncoder();
        HpackDecoder decoder = new HpackDecoder(65536);
        ByteBuf out = Unpooled.buffer();
        try {
            for (int direction : new int[] { 1, -1 }) {
                for (int step = 0; step <= 65536; ++step) {
                    int capacity = direction == 1 ? step : 65536 - step;
                    decoder.setMaxHeaderTableSize(capacity);
                    encoder.setMaxHeaderTableSize(capacity);
                    roundTrip(encoder, decoder, out, "x-name-" + (step % 37), "v-" + step, false);
                    assertTrue(encoder.size() <= capacity);
                    if (step % 127 == 0 || capacity == 0) {
                        assertRing(encoder);
                    }
                }
            }
            assertEquals(0, encoder.length());
            assertRing(encoder);
        } finally {
            out.release();
        }
    }

    @Test
    void wrappedGrowthDuplicateNamesSensitiveAndClear() throws Exception {
        HpackEncoder encoder = new HpackEncoder();
        HpackDecoder decoder = new HpackDecoder(65536);
        ByteBuf out = Unpooled.buffer();
        Random random = new Random(0xfeed);
        try {
            // Repeatedly fill and wrap each ring size before growing a populated ring.
            for (int capacity : new int[] { 256, 1024, 4096, 8192, 16384, 32768, 65536, 100, 65536 }) {
                decoder.setMaxHeaderTableSize(capacity);
                encoder.setMaxHeaderTableSize(capacity);
                for (int i = 0; i < 5000; ++i) {
                    String name = i % 5 == 0 ? "content-type" : "x-" + random.nextInt(50);
                    String value = "v-" + random.nextInt(2000);
                    roundTrip(encoder, decoder, out, name, value, i % 7 == 0);
                    if (i % 97 == 0) {
                        assertRing(encoder);
                    }
                }
                assertRing(encoder);
            }
            encoder.setMaxHeaderTableSize(0);
            assertRing(encoder);
            assertEquals(0, encoder.length());
            encoder.setMaxHeaderTableSize(65536);
            // Coalesced SETTINGS 0 -> 65536 must clear the peer as well as local stale handles.
            roundTrip(encoder, decoder, out, "x-reused", "v", false);
            assertEquals(1, encoder.length());
            assertRing(encoder);
        } finally {
            out.release();
        }
    }

    @Test
    void slotsStayLazyUntilDynamicInsertion() throws Exception {
        HpackEncoder encoder = new HpackEncoder();
        ByteBuf out = Unpooled.buffer();
        try {
            for (int capacity : new int[] { 0, 65536, 4096 }) {
                encoder.setMaxHeaderTableSize(capacity);
                encoder.encodeHeaders(1, out, new DefaultHttp2Headers().method("GET"),
                        Http2HeadersEncoder.NEVER_SENSITIVE);
                encoder.encodeHeaders(1, out, new DefaultHttp2Headers().add("x-secret", "v"),
                        Http2HeadersEncoder.ALWAYS_SENSITIVE);
                assertNull(field(encoder, "names"));
                out.clear();
            }
            encoder.encodeHeaders(1, out, new DefaultHttp2Headers().add("x-first", "v"),
                    Http2HeadersEncoder.NEVER_SENSITIVE);
            assertEquals(16, ((Object[]) field(encoder, "names")).length);
            assertRing(encoder);
        } finally {
            out.release();
        }
    }

    private static void roundTrip(HpackEncoder encoder, HpackDecoder decoder, ByteBuf out,
                                  String name, String value, boolean sensitive) throws Exception {
        Http2Headers headers = new DefaultHttp2Headers().add(name, value);
        int previousLength = encoder.length();
        long previousSize = encoder.size();
        encoder.encodeHeaders(1, out, headers, sensitive ? Http2HeadersEncoder.ALWAYS_SENSITIVE :
                Http2HeadersEncoder.NEVER_SENSITIVE);
        Http2Headers decoded = new DefaultHttp2Headers();
        decoder.decode(1, out, decoded, true);
        assertEquals(headers, decoded);
        assertEquals(encoder.length(), decoder.length());
        assertEquals(encoder.size(), decoder.size());
        if (sensitive) {
            assertEquals(previousLength, encoder.length());
            assertEquals(previousSize, encoder.size());
        }
        out.clear();
    }

    private static Object field(HpackEncoder encoder, String name) throws Exception {
        Field field = HpackEncoder.class.getDeclaredField(name);
        field.setAccessible(true);
        return field.get(encoder);
    }

    private static void assertRing(HpackEncoder encoder) throws Exception {
        CharSequence[] names = (CharSequence[]) field(encoder, "names");
        if (names == null) {
            assertEquals(0, encoder.length());
            return;
        }
        CharSequence[] values = (CharSequence[]) field(encoder, "values");
        boolean[] representatives = (boolean[]) field(encoder, "nameRepresentative");
        int oldest = (Integer) field(encoder, "oldest");
        int count = encoder.length();
        assertTrue(names.length <= 2048);
        assertEquals(0, names.length & (names.length - 1));
        boolean[] live = new boolean[names.length];
        Map<String, Integer> newestNames = new HashMap<String, Integer>();
        long size = 0;
        for (int i = 0; i < count; ++i) {
            int slot = (oldest + i) & (names.length - 1);
            live[slot] = true;
            assertNotNull(names[slot]);
            assertNotNull(values[slot]);
            size += HpackHeaderField.sizeOf(names[slot], values[slot]);
            HpackHeaderField entry = encoder.getHeaderField(count - 1 - i);
            assertEquals(names[slot], entry.name);
            assertEquals(values[slot], entry.value);
            if (HpackStaticTable.getIndex(names[slot]) == HpackStaticTable.NOT_FOUND) {
                newestNames.put(names[slot].toString(), slot);
            }
        }
        assertEquals(size, encoder.size());
        for (int slot = 0; slot < names.length; ++slot) {
            if (!live[slot]) {
                assertNull(names[slot]);
                assertNull(values[slot]);
                assertFalse(representatives[slot]);
            } else {
                assertEquals(Integer.valueOf(slot).equals(newestNames.get(names[slot].toString())),
                        representatives[slot]);
            }
        }
        assertChains(encoder, "nameValueEntries", "valueNext", "valuePrev", live);
        assertChains(encoder, "nameEntries", "nameNext", "namePrev", representatives);
    }

    private static void assertChains(HpackEncoder encoder, String headsField, String nextField,
                                     String prevField, boolean[] expected) throws Exception {
        int[] heads = (int[]) field(encoder, headsField);
        int[] next = (int[]) field(encoder, nextField);
        int[] prev = (int[]) field(encoder, prevField);
        boolean[] seen = new boolean[expected.length];
        for (int head : heads) {
            int previous = 0;
            for (int handle = head; handle != 0; handle = next[handle - 1]) {
                int slot = handle - 1;
                assertTrue(slot >= 0 && slot < expected.length);
                assertTrue(expected[slot]);
                assertFalse(seen[slot], "cycle or duplicate chain membership");
                seen[slot] = true;
                assertEquals(previous, prev[slot]);
                previous = handle;
            }
        }
        for (int slot = 0; slot < expected.length; ++slot) {
            assertEquals(expected[slot], seen[slot]);
            if (!expected[slot]) {
                assertEquals(0, next[slot]);
                assertEquals(0, prev[slot]);
            }
        }
    }
}
