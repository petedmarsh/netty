# HPACK ring campaign — completed

237 independent sequential JVM forks / 1,185 measured iterations. All forks: GC profiler, 5×1 s warmup and 5×1 s measurement, one thread, fixed 512 MiB heap, JDK 21.0.12. Four fields/block. Lower is better.

Six-round matched important cells use all six permutations of ringMixed/linkedMixed/upstream. Three-round three-way cells use cyclic rotations; two-way cells use AB/BA/AB (one extra AB, not perfectly balanced). Ratios below are paired-round geometric timing ratios with Student-t 95% intervals on log ratios (df=5 or2). They are exploratory, not multiple-comparison adjusted. Table means use arithmetic fork means. GC profiler bytes include harness/JIT escape-analysis modes.

## focus

| Scenario / bytes | ringMixed ns / B per op | linkedMixed ns / B per op | upstream ns / B per op | Ring vs linked 95% CI | Ring vs upstream 95% CI |
|---|---:|---:|---:|---:|---:|
| CHURN / 4096 | 156.82 / 48.00 | 174.31 / 336.00 | 1463.93 / 336.00 | -10.10% [-17.79, -1.70] | -89.32% [-90.28, -88.27] |
| COLLISION / 4096 | 1131.04 / 40.00 | 1011.33 / 168.00 | 962.61 / 168.00 | +8.90% [-15.30, +40.02] | +14.31% [-12.31, +49.01] |
| NAME_HIT / 4096 | 134.62 / 48.00 | 139.60 / 208.00 | 843.86 / 208.00 | -3.47% [-9.21, +2.63] | -84.04% [-84.67, -83.39] |
| REPEATED / 4096 | 49.38 / 44.00 | 40.40 / 16.00 | 42.88 / 24.00 | +23.10% [+6.38, +42.45] | +15.88% [-3.14, +38.63] |

## small

| Scenario / bytes | ringMixed ns / B per op | linkedMixed ns / B per op | upstream ns / B per op | Ring vs linked 95% CI | Ring vs upstream 95% CI |
|---|---:|---:|---:|---:|---:|
| COLLISION / 256 | 208.21 / 48.00 | 131.24 / 208.00 | 123.45 / 200.00 | +57.14% [+31.27, +88.10] | +67.20% [+41.95, +96.95] |
| NAME_HIT / 256 | 121.10 / 48.00 | 102.73 / 208.00 | 167.64 / 208.00 | +17.88% [+16.80, +18.97] | -26.70% [-40.06, -10.36] |
| REPEATED / 256 | 44.38 / 24.00 | 36.72 / 0.00 | 42.39 / 24.00 | +19.70% [+2.08, +40.35] | +4.83% [-20.01, +37.39] |

## rest

| Scenario / bytes | ringMixed ns / B per op | linkedMixed ns / B per op | upstream ns / B per op | Ring vs linked 95% CI | Ring vs upstream 95% CI |
|---|---:|---:|---:|---:|---:|
| HUFFMAN / 4096 | 3267.95 / 48.00 | 3252.39 / 208.00 | 3458.49 / 208.00 | +0.49% [-5.60, +6.98] | -5.51% [-10.37, -0.39] |
| MIXED / 4096 | 132.79 / 48.00 | 134.23 / 208.00 | 536.48 / 208.00 | -0.95% [-18.88, +20.94] | -75.21% [-78.76, -71.06] |
| SENSITIVE / 4096 | 51.71 / 48.00 | 51.73 / 48.00 | 51.28 / 48.00 | -0.04% [-3.66, +3.73] | +0.84% [-0.33, +2.02] |
| STATIC / 4096 | 71.02 / 48.00 | 70.75 / 48.00 | 69.26 / 48.00 | +0.38% [-0.44, +1.21] | +2.54% [-2.54, +7.88] |
| WORKING_SET / 4096 | 121.16 / 48.00 | 106.14 / 208.00 | 756.92 / 208.00 | +14.16% [+10.56, +17.88] | -83.99% [-85.32, -82.53] |

## large

| Scenario / bytes | ringMixed ns / B per op | linkedMixed ns / B per op | Ring vs linked 95% CI |
|---|---:|---:|---:|
| CHURN / 65536 | 151.53 / 48.00 | 197.15 / 336.00 | -23.14% [-26.97, -19.10] |
| WORKING_SET128 / 65536 | 58.36 / 48.00 | 55.18 / 48.00 | +5.76% [+4.81, +6.72] |
| WORKING_SET384 / 65536 | 59.39 / 48.00 | 53.77 / 32.00 | +11.47% [-32.99, +85.42] |
| WORKING_SET768 / 65536 | 61.38 / 48.00 | 55.91 / 32.00 | +10.64% [-23.49, +60.00] |

## init

| Scenario / bytes | ringMixed ns / B per op | linkedMixed ns / B per op | upstream ns / B per op | Ring vs linked 95% CI | Ring vs upstream 95% CI |
|---|---:|---:|---:|---:|---:|
| encoder / 4096 | 19.77 / 656.00 | 28.14 / 656.00 | 33.13 / 744.00 | -29.76% [-33.10, -26.25] | -40.32% [-45.21, -35.00] |

## first

| Scenario / bytes | ringMixed ns / B per op | linkedMixed ns / B per op | upstream ns / B per op | Ring vs linked 95% CI | Ring vs upstream 95% CI |
|---|---:|---:|---:|---:|---:|
| firstBlock / 4096 | 182.44 / 1376.00 | 161.92 / 992.00 | 178.94 / 1080.00 | +12.67% [+11.45, +13.91] | +1.95% [+0.85, +3.07] |

## raw

| Scenario / bytes | ringRaw ns / B per op | linkedRaw ns / B per op | Ring vs linked 95% CI |
|---|---:|---:|---:|
| CHURN / 4096 | 877.45 / 32.00 | 1484.31 / 336.00 | -40.89% [-49.89, -30.28] |
| COLLISION / 4096 | 1034.70 / 32.00 | 1029.56 / 176.00 | -1.02% [-44.10, +75.24] |
| NAME_HIT / 4096 | 508.10 / 48.00 | 786.80 / 208.00 | -35.42% [-36.23, -34.60] |
| REPEATED / 4096 | 50.50 / 40.00 | 41.15 / 16.00 | +23.94% [-16.02, +82.91] |

## Exact-hit allocation modes

Fork means (B/block), preserved rather than averaged away:

- REPEATED 4096 ringMixed: 48.00, 24.00, 48.00, 48.00, 48.00, 48.00
- REPEATED 4096 linkedMixed: 48.00, 0.00, 48.00, 0.00, 0.00, 0.00
- REPEATED 4096 upstream: 48.00, 48.00, 0.00, 24.00, 0.00, 24.00
- REPEATED 256 ringMixed: 0.00, 48.00, 0.00, 48.00, 48.00, 0.00
- REPEATED 256 linkedMixed: 0.00, 0.00, 0.00, 0.00, 0.00, 0.00
- REPEATED 256 upstream: 48.00, 0.00, 48.00, 48.00, 0.00, 0.00

## Populated retained structural memory

Explicit modeled accounting: compressed references/class pointers, 8-byte object alignment, array header16B, reference/int element4B, boolean1B. Array byte totals are exact under these assumptions; object totals approximate field packing as align8(12 + field widths), so are **not JOL-measured heap sizes**. Identity traversal includes encoder-owned Hpack entry nodes/sentinels/Huffman helper arrays; excludes shared CharSequence objects/backing text, headers, corpus and output buffers. It does not measure transient allocation. See Probe.java and raw *-probe.jsonl.

| State / table | ringMixed arrays / modeled total B | linkedMixed arrays / modeled total B | upstream arrays / modeled total B |
|---|---:|---:|---:|
| EMPTY / 4096 | 544 / 656 | 544 / 656 | 544 / 744 |
| FIRST_BLOCK / 4096 | 1216 / 1328 | 544 / 944 | 544 / 1032 |
| CHURN / 4096 | 4912 / 5024 | 544 / 6272 | 544 / 6360 |
| NAME_HIT / 4096 | 4912 / 5024 | 544 / 4104 | 544 / 4192 |
| REPEATED / 4096 | 1216 / 1328 | 544 / 944 | 544 / 1032 |
| COLLISION / 4096 | 4912 / 5024 | 544 / 3448 | 544 / 3536 |
| WORKING_SET128 / 65536 | 12592 / 12704 | 8224 / 13584 | unsupported |
| WORKING_SET384 / 65536 | 25264 / 25376 | 8224 / 23824 | unsupported |
| WORKING_SET768 / 65536 | 42160 / 42272 | 8224 / 39184 | unsupported |
| CHURN / 65536 | 75952 / 76064 | 8224 / 99056 | unsupported |
| CHURN_AFTER32768 / 65536 | 75952 / 76064 | 8224 / 99056 | unsupported |
