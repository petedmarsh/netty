#!/usr/bin/env python3
"""Reproduce fork-level bootstrap tables; requires numpy."""
import csv, datetime, hashlib, json, pathlib
import numpy as np
from run import CASES, CAPACITY
P=pathlib.Path(__file__).resolve().parent
rng=np.random.default_rng(20261010)
N=100000
# Preserve three AB and three BA pairs in every resample.
strat=np.concatenate([rng.choice([0,2,4],(N,3)),rng.choice([1,3,5],(N,3))],axis=1)
ordinary=rng.integers(0,6,(N,6))
wire={}
for v in ['baseline','candidate']:
    with (P/f'wire-{v}.csv').open() as f:
        wire[v]={(int(r['tableSize']),r['scenario']):float(r['bytesPerBlock']) for r in csv.DictReader(f)}
assert all(wire['candidate'][k]==v for k,v in wire['baseline'].items())
def load(version,case):
    op,s,size=case; times=[]; alloc=[]
    for r in range(1,7):
        d=json.loads((P/f'r{r}-{version}-{op}-{s}-{size}.json').read_text())[0]
        assert d['forks']==1 and d['warmupIterations']==5 and d['measurementIterations']==5
        assert d['warmupTime']=='1 s' and d['measurementTime']=='1 s' and d['threads']==1
        a=d['primaryMetric']['rawData']; b=d['secondaryMetrics']['·gc.alloc.rate.norm']['rawData']
        assert len(a)==len(b)==1 and len(a[0])==len(b[0])==5
        times.append(np.mean(a[0])); alloc.append(np.mean(b[0]))
    return np.array(times),np.array(alloc)
def interval(x): return np.quantile(x,[.025,.975]).tolist()
def analyze(a,b,indices):
    at,aa=a; bt,ba=b
    ci=interval(bt[indices].mean(axis=1)/at[indices].mean(axis=1))
    aci=interval(ba[indices].mean(axis=1)-aa[indices].mean(axis=1))
    threshold=max(1,float(aa.mean())*.01)
    status='NI supported' if ci[1]<=1.05 else 'regression >5%' if ci[0]>1.05 else 'unresolved'
    astat='within tolerance' if aci[1]<=threshold else 'increase' if aci[0]>threshold else 'unresolved'
    return dict(baseline_ns=float(at.mean()),candidate_ns=float(bt.mean()),ratio=float(bt.mean()/at.mean()),ratio_ci95=ci,
        baseline_B=float(aa.mean()),candidate_B=float(ba.mean()),allocation_delta_ci95=aci,allocation_tolerance=threshold,
        time_status=status,allocation_status=astat,
        AB_ratio=float(bt[::2].mean()/at[::2].mean()),BA_ratio=float(bt[1::2].mean()/at[1::2].mean()),
        reference_time_forks=at.tolist(),candidate_time_forks=bt.tolist(),reference_alloc_forks=aa.tolist(),candidate_alloc_forks=ba.tolist())
results={}; lines=['# Iteration2 campaign: generated fork-level analysis','', 'Time: ns/block; allocation: B/block (INIT per context). Ratios candidate/reference, two-sided 95% fork-bootstrap intervals. NI = timing noninferiority under the predeclared +5% analysis margin, not user acceptance.','', '| Case | Baseline ns | Candidate ns | Change [95% interval] | Time verdict | B/op baseline → candidate | Δ B/op [95% interval] | Allocation verdict | Wire B/block |','|---|---:|---:|---:|---|---:|---:|---|---:|']
for case in CASES:
    op,s,size=case; key=f'{op}/{s}/{size}'; x=analyze(load('baseline',case),load('candidate',case),strat); results[key]=x
    lo,hi=x['ratio_ci95']; al,ah=x['allocation_delta_ci95']; w='—' if s=='INIT' else f'{wire["candidate"][(size,s)]:.3f}'
    lines.append(f'| {key} | {x["baseline_ns"]:.2f} | {x["candidate_ns"]:.2f} | {(x["ratio"]-1)*100:+.2f}% [{(lo-1)*100:+.2f}, {(hi-1)*100:+.2f}] | {x["time_status"]} | {x["baseline_B"]:.3f} → {x["candidate_B"]:.3f} | [{al:+.3f}, {ah:+.3f}] | {x["allocation_status"]} | {w} |')
lines+=['','## Capacity (reference is candidate4096, not baseline)','', '| Scenario | 4096 ns → 65536 ns | Time ratio [95% interval] | B/block 4096 → 65536 | Wire B/block 4096 → 65536 |','|---|---:|---:|---:|---:|']
for case in CAPACITY:
    op,s,size=case; x=analyze(load('candidate',(op,s,4096)),load('candidate',case),ordinary); results[f'capacity/{s}']=x
    lo,hi=x['ratio_ci95']
    lines.append(f'| {s} | {x["baseline_ns"]:.2f} → {x["candidate_ns"]:.2f} | {x["ratio"]:.4f} [{lo:.4f}, {hi:.4f}] | {x["baseline_B"]:.3f} → {x["candidate_B"]:.3f} | {wire["candidate"][(4096,s)]:.3f} → {wire["candidate"][(65536,s)]:.3f} |')
lines+=['','## Order sensitivity (matched cases only)','', '| Case | AB ratio (3 pairs) | BA ratio (3 pairs) |','|---|---:|---:|']
for key,x in results.items():
    if not key.startswith('capacity'): lines.append(f'| {key} | {x["AB_ratio"]:.4f} | {x["BA_ratio"]:.4f} |')
lines+=['','## Individual fork means','', 'Rounds 1–6; AB/BA/AB/BA/AB/BA. Capacity reference is candidate4096. Allocation details also retained in analysis.json.','']
for key,x in results.items():
    lines += [f'### {key}', '', '| Round | Reference ns | Candidate ns | Reference B/op | Candidate B/op |','|---|---:|---:|---:|---:|']
    for i in range(6): lines.append(f'| {i+1} | {x["reference_time_forks"][i]:.3f} | {x["candidate_time_forks"][i]:.3f} | {x["reference_alloc_forks"][i]:.3f} | {x["candidate_alloc_forks"][i]:.3f} |')
    lines+=['']
commands=[json.loads(s) for s in (P/'commands.jsonl').read_text().splitlines()]
ends=[json.loads(s) for s in (P/'completed.jsonl').read_text().splitlines()]
assert len(commands)==len(ends)==228
start=commands[0]['start']; end=ends[-1]['end']; elapsed=(datetime.datetime.fromisoformat(end)-datetime.datetime.fromisoformat(start)).total_seconds()
meta=dict(seed=20261010,replicates=N,numpy=np.__version__,start=start,end=end,elapsed_seconds=elapsed,forks=228,measured_iterations=1140)
(P/'analysis.json').write_text(json.dumps(dict(metadata=meta,cases=results),indent=2)+'\n')
(P/'ANALYSIS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(meta,indent=2)); print('\n'.join(lines[:24]))
