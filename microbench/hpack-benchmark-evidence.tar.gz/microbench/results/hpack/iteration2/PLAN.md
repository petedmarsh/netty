# Iteration2 HPACK campaign (premeasurement plan)

Compare original upstream baseline with newly rebuilt iteration2 candidate; preserve old candidate jar and all prior evidence. See provenance-initial.json for SHA256, source and packaged-class verification. Candidate patch is local candidate.patch (iteration2 handoff c9199c0869a31d5835261550d78d2cd91f2debf5ae01e9a706eebebd26cb3105).

Homebrew OpenJDK21, sequential JVMs only, one thread, 512MiB heap, GC profiler, each fork 5x1s warmup and 5x1s measurement. Six paired independent forks per matched case; round order AB/BA/AB/BA/AB/BA. Complete six pairs of COLLISION4096, NAME_HIT256, encoder INIT4096 first. Then all remaining cases from balanced campaign (all nine encode4096 scenarios; REPEATED, CHURN, NAME_HIT, COLLISION256; REPEATED, CHURN0; HUFFMAN decode4096); candidate-only WORKING_SET, MIXED, CHURN, COLLISION65536. Total 228 JVM forks, 1140 measured iterations.

Analysis reuses balanced tooling: per-fork means, 100000 paired bootstrap resamples stratified by AB/BA order, two-sided 95% intervals, order-specific ratios, normalized allocation and wire sizes. +5% timing NI margin is an analyst-declared analysis threshold, NOT user acceptance. Allocation analysis tolerance max(1 B/op,1% baseline). Capacity comparisons against candidate4096 are descriptive, not upstream comparisons. No simultaneous builds/tests/measurements. No production edits. Prior results remain historical and unmodified.

Current source: fused lookup/admission and reintegrated Huffman helper. Historical iteration1 is not a head-to-head measurement. This analysis is not universal proof of non-regression.
