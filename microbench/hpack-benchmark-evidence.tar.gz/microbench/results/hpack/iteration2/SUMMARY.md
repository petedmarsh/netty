# Final iteration2 results

## Latest: final iteration2 versus upstream baseline

Completed 2026-10-10 **17:31:30–18:11:25 UTC (39m55s measurement)**: **228 fresh JVM forks / 1140 measured iterations**, all 17 matched cases and four candidate-only 65536 cases. Six alternating AB/BA pairs, 5×1s warmup and measurement, GC profiler, Homebrew JDK21, one thread, 512MiB heap. No production or benchmark Java edits; preserved all previous jars and evidence. New isolated jar: `/tmp/hpack-iteration2.jar`.

**Initialization savings remain; HUFFMAN and NAME_HIT support practical noninferiority, but blanket non-regression is NOT established.** Twelve of 17 matched cases support the predeclared +5% timing margin; five remain unresolved (REPEATED at 0/256/4096, COLLISION4096, decode HUFFMAN control). None establishes a >5% regression, but REPEATED256/4096 and COLLISION4096 have positive timing intervals. This is not universal proof or user acceptance.

Two-sided 95% intervals bootstrap six paired fork means, 100000 resamples stratified by AB/BA; iterations are not independent replicates. Allocation tolerance is max(1 B/op, 1% baseline). These are analysis conventions; intervals are per-case, not simultaneous family-wide guarantees. No forks discarded or historical data pooled. This session launched no concurrent measurement/build/test workloads; external host idleness is not certified.

| Matched case | Baseline → iteration2 ns/op | Change [fork95%] | B/op baseline → iteration2 |
|---|---:|---:|---:|
| encode/HUFFMAN/4096 | 3348.21 → 3268.68 | -2.38% [-4.86, +0.25] | 208.0 → 208.0 |
| encode/REPEATED/4096 | 44.55 → 47.48 | +6.58% [+0.47, +17.34] | 32.0 → 40.0 |
| encode/REPEATED/256 | 42.62 → 47.50 | +11.44% [+0.98, +24.17] | 24.0 → 40.0 |
| encode/REPEATED/0 | 37.30 → 38.35 | +2.81% [-5.96, +14.16] | 4.0 → 8.0 |
| encode/COLLISION/4096 | 970.18 → 1013.41 | +4.46% [+1.77, +8.15] | 168.0 → 168.0 |
| encode/COLLISION/256 | 128.07 → 128.61 | +0.42% [-3.58, +4.54] | 208.0 → 208.0 |
| encode/NAME_HIT/4096 | 835.87 → 793.73 | -5.04% [-6.66, -3.38] | 208.0 → 208.0 |
| encode/NAME_HIT/256 | 173.80 → 110.92 | -36.18% [-37.32, -34.99] | 208.0 → 208.0 |
| encoder/INIT/4096 | 33.11 → 27.98 | -15.50% [-16.01, -15.13] | 744.0 → 656.0 |

INIT saves 88 B/context (11.83%), allocation delta interval [−88,−88]. REPEATED allocation delta intervals: 4096 [0,24], 256 [0,32], zero-table [−8,20] B/op; COLLISION4096 [−24,24]. Thus allocation neutrality is unresolved for these four cases despite equal COLLISION means. Other matched cases are within allocation tolerance. All matched wire sizes agree.

### 65536 capacity results (candidate only)

These compare iteration2 at 65536 with iteration2 at 4096, **not upstream**; no NAME_HIT65536 was in the requested original four-case matrix.

| Case | 4096 → 65536 ns/block | Ratio [fork95%] | B/block 4096 → 65536 |
|---|---:|---:|---:|
| WORKING_SET | 721.18 → 52.78 | 0.0732 [0.0652, 0.0814] | 208.0 → 24.0 |
| MIXED | 506.03 → 100.72 | 0.1990 [0.1910, 0.2061] | 208.0 → 103.0 |
| CHURN | 1450.19 → 199.67 | 0.1377 [0.1340, 0.1421] | 336.0 → 336.0 |
| COLLISION | 1013.41 → 222.58 | 0.2196 [0.2045, 0.2347] | 168.0 → 32.0 |

Capacity ratios are descriptive round-index bootstrap comparisons, not adjacent matched upstream AB/BA experiments. COLLISION wire size still increases 72 → 75.859 B/block; large-table capacity does not improve every compression outcome.

### Historical iteration1 and verification

Iteration1 (`optimized/`) measured HUFFMAN +5.73%, INIT −15.32%, COLLISION4096 −0.87%, NAME_HIT256 +3.26% against its own baseline. Current results are a separate campaign against upstream. They do not measure iteration2 versus iteration1, establish significance between iterations, or isolate the causal effects of Huffman reintegration/fused admission. Particularly large NAME_HIT256 changes warrant this caution. Fork/JIT/allocation modes and the variable unchanged decode control limit attribution.

Fresh reactor benchmark-jar build succeeded (124 HPACK tests). Full HTTP/2: **1642 tests, zero failures/errors, five existing skips**. Paranoid HPACK: **124 tests, zero failures/errors/skips**. Logs archived alongside raw results. Initial/final verification checks source patch, encoder and benchmark hashes, baseline/current packaged classes against compiled outputs, and preservation of earlier jars. `git diff --check` passed.

Iteration2 jar SHA256: `d2598337ee0876c8e44ad178e90825d9fb58c9784ad64bd0b4ed0a7c8149652c`.

Codec patch SHA256: `c9199c0869a31d5835261550d78d2cd91f2debf5ae01e9a706eebebd26cb3105`.

