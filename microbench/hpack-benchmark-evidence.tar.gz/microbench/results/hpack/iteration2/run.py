#!/usr/bin/env python3
"""Sequential independent-fork campaign. Run rounds 1 through 6, in order."""
import datetime, hashlib, json, pathlib, platform, shlex, subprocess, sys, time, zipfile
ROOT = pathlib.Path(__file__).resolve().parents[4]
OUT = pathlib.Path(__file__).resolve().parent
JAVA = '/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin/java'
SCENARIOS = ['REPEATED','WORKING_SET','MIXED','CHURN','NAME_HIT','COLLISION','STATIC','SENSITIVE','HUFFMAN']
CASES = [('encode',s,4096) for s in SCENARIOS] + [('encode',s,256) for s in ['REPEATED','CHURN','NAME_HIT','COLLISION']] + [('encode',s,0) for s in ['REPEATED','CHURN']] + [('encoder','INIT',4096),('decode','HUFFMAN',4096)]
CAPACITY = [('encode',s,65536) for s in ['WORKING_SET','MIXED','CHURN','COLLISION']]
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def cmd(*args): return subprocess.check_output(args,cwd=ROOT,text=True)
JARS={'baseline':'/tmp/hpack-baseline.jar','candidate':'/tmp/hpack-iteration2.jar'}
def verify():
    old=json.loads((OUT.parent/'environment.json').read_text())
    hashes={p:sha(p) for p in old['jars']}
    assert hashes==old['jars'], 'jar hash changed'
    encoder='codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java'
    assert sha(ROOT/encoder)=='ab96050bc0c247d7fc158631066b1a6eb19c4c19630044916c3c31b697b8f063'
    assert subprocess.check_output(['git','diff','--','codec-http2'],cwd=ROOT)==(OUT/'candidate.patch').read_bytes()
    sources={}
    for name in ['HpackStateBenchmark','HpackInitializationBenchmark']:
        p=pathlib.Path('microbench/src/main/java/io/netty/handler/codec/http2')/(name+'.java')
        assert (ROOT/p).read_bytes()==(pathlib.Path('/tmp/netty-hpack-baseline')/p).read_bytes()
        sources[str(p)]=sha(ROOT/p)
    checks={}
    for version,tree in [('baseline',pathlib.Path('/tmp/netty-hpack-baseline')),('candidate',ROOT)]:
        z=zipfile.ZipFile(JARS[version]); n=0
        for module in ['codec-http2','microbench']:
            base=tree/module/'target/classes'
            for p in base.rglob('*.class'):
                name=str(p.relative_to(base))
                if name.endswith('module-info.class'): continue # shaded module descriptors are deliberately excluded
                assert z.read(name)==p.read_bytes(), name
                n+=1
        checks[version]=n
    return dict(jars={v:sha(p) for v,p in JARS.items()}, preserved_jars=hashes,encoder_source_sha256=sha(ROOT/encoder),benchmark_sources=sources,
        matching_target_classes_excluding_module_info=checks,head=cmd('git','rev-parse','HEAD').strip(),
        baseline_status=cmd('git','-C','/tmp/netty-hpack-baseline','status','--short'),
        candidate_patch_sha256=sha(OUT/'candidate.patch'),host=platform.platform(),
        jdk=subprocess.run([JAVA,'-version'],capture_output=True,text=True).stderr,
        verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
if __name__=='__main__':
    round_=int(sys.argv[1]); assert 1<=round_<=6
    priority=[('encode','COLLISION',4096),('encode','NAME_HIT',256),('encoder','INIT',4096)]
    cases=priority if sys.argv[2]=='priority' else [c for c in CASES+CAPACITY if c not in priority]
    provenance=verify()
    (OUT/('provenance-round%d.json'%round_)).write_text(json.dumps(provenance,indent=2)+'\n')
    start=time.monotonic()
    for op,scenario,size in cases:
        versions=['baseline','candidate'] if round_%2 else ['candidate','baseline']
        if size==65536: versions=['candidate']
        for version in versions:
            stem=f'r{round_}-{version}-{op}-{scenario}-{size}'
            target=OUT/(stem+'.json'); assert not target.exists(), 'refusing overwrite'
            bench='.*HpackInitializationBenchmark.encoder$' if scenario=='INIT' else '.*HpackStateBenchmark.'+op+'$'
            args=[JAVA,'-jar',JARS[version],bench,'-p','tableSize='+str(size)]
            if scenario!='INIT': args+=['-p','scenario='+scenario]
            args+=['-f','1','-wi','5','-w','1s','-i','5','-r','1s','-t','1','-prof','gc','-foe','true','-jvmArgs','-Xms512m -Xmx512m','-rf','json','-rff',str(target)]
            stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
            with (OUT/'commands.jsonl').open('a') as f: f.write(json.dumps(dict(start=stamp,round=round_,case=stem,argv=args,shell=shlex.join(args)))+'\n')
            with (OUT/(stem+'.log')).open('w') as f: result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=ROOT)
            assert result.returncode==0, stem
            data=json.loads(target.read_text()); assert len(data)==1
            assert len(data[0]['primaryMetric']['rawData'])==1 and len(data[0]['primaryMetric']['rawData'][0])==5
            with (OUT/'completed.jsonl').open('a') as f: f.write(json.dumps(dict(case=stem,end=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n')
            print(stem,round(data[0]['primaryMetric']['score'],3),flush=True)
    print('round seconds',time.monotonic()-start,flush=True)
