#!/usr/bin/env python3
"""Verify retained source/classes and preservation; does not run timings."""
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[4]
HERE = pathlib.Path(__file__).resolve().parent
ENC = pathlib.Path('codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


original = pathlib.Path('/tmp/hpack-ring-before/extracted') / ENC
expected = original.read_bytes().replace(b'hashMask <= 127 ? h : mixHash(h)',
                                         b'hashMask <= 0 ? h : mixHash(h)')
assert (ROOT / ENC).read_bytes() == expected
manifest = json.loads((HERE.parent / 'ring/manifest.json').read_text())['variants']['linkedMixed']
assert sha(ROOT / ENC) == manifest['encoder_sha256']
jars = [pathlib.Path(manifest['jar']),
        pathlib.Path('/tmp/netty-hpack-distribution/artifacts/64-mixed/microbenchmarks.jar'),
        ROOT / 'microbench/target/microbenchmarks.jar']
assert sha(jars[0]) == manifest['jar_sha256']
base = ROOT / 'codec-http2/target/classes'
classes = [p for p in base.rglob('*.class') if p.name != 'module-info.class']
checks = {}
for jar in jars:
    with zipfile.ZipFile(jar) as z:
        for p in classes:
            assert z.read(p.relative_to(base).as_posix()) == p.read_bytes(), (jar, p)
    checks[str(jar)] = {'sha256': sha(jar), 'matching_codec_classes': len(classes)}
for tree in ['/tmp/netty-hpack-ring/linkedMixed', '/tmp/netty-hpack-distribution/64-mixed']:
    assert (pathlib.Path(tree) / ENC).read_bytes() == expected
    for p in classes:
        assert (pathlib.Path(tree) / 'codec-http2/target/classes' / p.relative_to(base)).read_bytes() == p.read_bytes()
previous = json.loads((HERE / 'before-sha256.json').read_text())
# Only these narrative documents intentionally change; all campaign evidence stays immutable.
allowed = {'microbench/HPACK.md', 'microbench/results/hpack/RESULTS.md',
           'microbench/results/hpack/ring/README.md'}
for path, digest in previous.items():
    if path not in allowed:
        assert sha(ROOT / path) == digest, path
counts = {}
for label in ['http2-final', 'paranoid-package']:
    suites = [ET.parse(p).getroot() for p in (HERE / (label + '-reports')).glob('TEST-*.xml')]
    if label == 'paranoid-package':
        suites = [s for s in suites if s.attrib['name'].split('.')[-1].startswith('Hpack')]
    counts[label] = {key: sum(int(s.attrib[key]) for s in suites)
                     for key in ['tests', 'failures', 'errors', 'skipped']}
    assert counts[label]['failures'] == counts[label]['errors'] == 0
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
result = {'encoder_sha256': sha(ROOT / ENC), 'jars': checks, 'tests': counts,
          'preserved_files': len(previous) - len(allowed), 'timings_run': False}
(HERE / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
