# Prototype concluded: linkedMixed64 retained, ring rejected

Root production is **linkedMixed64**, not ring. The retention campaign ran no new
timings; the final fork commit retains that implementation.
The original iteration2 codec source/test snapshot in `/tmp/hpack-ring-before/extracted`
was restored. The only subsequent production change is exactly the measured change:

```diff
-        return (hashMask <= 127 ? h : mixHash(h)) & hashMask;
+        return (hashMask <= 0 ? h : mixHash(h)) & hashMask;
```

All usable bucket arrays therefore mix uniformly, including initial64. The
historical nearby comment about small arrays retaining their original mapping was
left byte-identical during restoration, then corrected before the fork commit.
That final edit changes only two comment lines and preserves the 655-line source
layout. No other production changes.
The linked nodes, local64KiB cap, chain16 admission protection above4096, growth,
sensitive handling and wire semantics remain iteration2's.

## Tests and exact provenance

- Restored original `HpackEncoderTest.java`; its collision tests discover actual
  buckets reflectively and full-hash collisions remain full-hash collisions under
  mixing. No assertions removed, weakened or skipped. Added one explicit test
  checking mixed buckets at256/4096, growth to65536 and shrink to256, with expected
  masks63/63/1023/1023. This is the only test delta from the original snapshot.
- Removed ring-only test from the active codec suite only after verifying its
  byte-identical durable copy in `../ring/HpackEncoderRingTest.java` and verifying
  the original tracked root codec diff against `../ring/root-codec.patch`.
- Full HTTP/2 **1643 tests, zero failures/errors, five existing skips**;
  paranoid HPACK **125 tests, zero failures/errors/skips**. The added hashing test
  explains the +1 relative to the measured linked suites1642/124.
- Fresh clean root reactor test/build with pinned Homebrew OpenJDK21 and the
  campaign Maven repository. Every one of **276 compiled codec classes** matches
  both measured ring/distribution linkedMixed jars, their original reactor outputs,
  and the freshly packaged root benchmark jar. At restoration, encoder source was
  byte-identical in all three source trees: historical snapshot SHA256
  `e56fb8cbf2c9d40fed3b00775266bdccc038b29e06b020b08edb502f8fea1e04`.
  Ring measured jar SHA256 remains
  `c3555dc021ed9498b9b3e2bed3b464d4c84d24f49f64256a1f91b9383be6db86`
  (also recorded in verification.json).
- All3891 prior evidence/benchmark files outside the three deliberately updated
  narrative documents are SHA256-preserved. Ring/distribution patches, probes,
  raw forks, analyses and benchmark sources are untouched. Fresh root whole-jar
  hash differs as expected: this is not a claim of whole-jar identity (the ring
  campaign's isolated FirstUseBenchmark is not added to root production benchmarks).
- No encoder provenance mismatch: existing measurements apply to this exact
  production implementation; no timing rerun needed. This does not promise
  reproducible machine timings or establish blanket upstream non-regression.

Final comment-correction source SHA256 is
`0627492d26cd92449df1d6f87bda5cac0f8bb788c875d4b1bda4d4c24def8bad`.
It differs from the recorded snapshot **only in the two bucket comment lines**;
historical hashes and verification artifacts below remain unchanged. Final checks
and byte-for-byte compiled-class comparison are recorded separately in
`final-commit/verification.json` by `final-commit/validate.py`. The historical
`verify.py` intentionally checks the original snapshot, not the corrected comment.

`verification.json`, `verify.py`, `before-sha256.json`, full build logs and separate
Surefire report snapshots are retained here. Initial root validation stopped at
NoHttp scanning preserved Maven logs with HTTP diagnostic links, before tests.
To retain those logs unmodified without disabling any checks, `microbench/results`
was temporarily parked outside the checkout during validation and restored in a
finally block. Build output was captured there too. No check/plugin was bypassed.

Executed validation (JAVA_HOME `/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home`):

```sh
./mvnw -Dmaven.repo.local=/tmp/hpack-maven-repository -Dsurefire.failIfNoSpecifiedTests=false -DskipTests=false -pl codec-http2 -am '-P!mac' '-Dtest=io.netty.handler.codec.http2.*Test' clean test
./mvnw -Dmaven.repo.local=/tmp/hpack-maven-repository -Dsurefire.failIfNoSpecifiedTests=false -DskipTests=false -pl microbench -am '-Pbenchmark-jar,!mac' '-Dtest=Hpack*Test' -Dio.netty.leakDetection.level=paranoid package
python3 microbench/results/hpack/linkedMixed-retained/summarize.py
python3 microbench/results/hpack/linkedMixed-retained/verify.py
```

## Measured upstream comparison and limitations

[UPSTREAM.md](UPSTREAM.md) contains every supported matched linkedMixed/upstream
cell from the ring campaign, including allocation and paired95% timing intervals.
`summarize.py` derives these comparisons from existing raw forks, without modifying
original analyses or pooling historical campaigns.

At4096: CHURN1463.93→174.31ns (−88.12% paired); NAME_HIT843.86→139.60ns
(−83.47%); MIXED536.48→134.23ns; WORKING_SET756.92→106.14ns;
HUFFMAN3458.49→3252.39ns. Churn allocation stays336B/block; name-hit/mixed/
working-set/Huffman stays208B. REPEATED42.88→40.40ns is inconclusive.
COLLISION962.61→1011.33ns (+4.97%, interval[−0.41,+10.64]) is an unresolved
regression risk, not non-regression. Small-table COLLISION123.45→131.24ns
(+6.41%, [−0.46,+13.74]) likewise remains unresolved, allocation200→208B.
STATIC/SENSITIVE point estimates are slightly slower and intervals cross zero.
Constructor33.13→28.14ns,744→656B; fresh first block178.94→161.92ns,1080→992B.
First-block timings are repeated fresh-context work, not cold JVM startup.

The ring was rejected despite matched CHURN4096 being10.10% faster than linkedMixed
and allocating48 rather than336B/block: exact-hit REPEATED4096 regresses23.10%,
NAME_HIT25617.88%, COLLISION25657.14%, WORKING_SET409614.16%, and first block12.67%
with1376 rather than992B. Mixing, not ring structure, explains most gains versus
upstream. Ring retention is workload-dependent, not universally smaller.

Caveats:

- Entire campaign237 independent sequential JVM forks/1185 measurement iterations,
  one thread, GC profiler,5×1s warmup +5×1s measurement,512MiB heap, JDK21.0.12.
  Six paired rounds on important cells cover all three-variant permutations;
  remaining cells have three rounds/low power. Intervals use Student-t on paired
  log ratios (df5 or2), exploratory and not multiple-comparison adjusted. They
  differ from historical campaigns' bootstrap methods. Iterations are not
  independent forks; no samples discarded or allocation-mode filtered.
- GC allocation includes harness/iterator/JIT escape-analysis modes. REPEATED4096
  linked means16B versus upstream24B;256 means0B versus24B are not proof that exact
  lookup intrinsically allocates or a guaranteed memory advantage. See original
  per-fork modes in ring/ANALYSIS.md. Synthetic hash distribution drives large gains;
  mixing cannot separate equal full hashes. No real-traffic or host-idleness guarantee.
- Upstream clamps65536 to4096; its unchanged benchmark correctly rejects65536.
  There is **no upstream64KiB comparison**. LinkedMixed at65536: CHURN197.15ns/336B;
  retained working sets128/384/768:55.18/53.77/55.91ns and48/32/32B. Ring wins
  large churn23.14% but not exact-hit working sets. Large-table/raw two-way cells
  use AB/BA/AB, not perfect balance;65536 churn ran later after probe validation.
- Populated retention is modeled, not JOL-measured: compressed4B references/class
  pointers,16B array headers,8B alignment; approximate object field packing.
  Shared text/corpus/output/Huffman constants excluded. Linked/upstream modeled
  CHURN4096 totals6272/6360B, NAME_HIT4104/4192B, COLLISION3448/3536B,
  first four entries944/1032B. These are not transient allocation measurements.
- All five variants match wire digests at supported small/default cells; four
  candidates match at65536. Existing probes include decoded-cycle checks and
  ring wraps. Historical ring tests/results remain evidence, not active linked tests.
- Candidate selection is comparative, not blanket upstream non-inferiority.
  Collision, exact-hit and small static/sensitive uncertainty remains explicit.
