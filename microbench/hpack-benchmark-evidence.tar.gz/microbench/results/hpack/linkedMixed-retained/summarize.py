#!/usr/bin/env python3
"""Derive linkedMixed/upstream contrasts from preserved ring forks; no new timing."""
import collections
import json
import math
import pathlib
import statistics as s

HERE = pathlib.Path(__file__).resolve().parent
RING = HERE.parent / 'ring'
cells = collections.defaultdict(dict)
for group, r, name, scenario, table, kind in json.loads((RING / 'schedule.json').read_text()):
    if name not in ('linkedMixed', 'upstream'):
        continue
    row = json.loads((RING / 'raw' / f'{group}-r{r}-{name}-{scenario}-{table}.json').read_text())[0]
    allocation = next(v['score'] for k, v in row['secondaryMetrics'].items()
                      if k.lstrip('·') == 'gc.alloc.rate.norm')
    cells[group, scenario, table, name][r] = (row['primaryMetric']['score'], allocation)
lines = ['## LinkedMixed versus upstream, ring campaign only', '',
         'Arithmetic fork means, ns / allocated B per four-field block (constructor per encoder).',
         'Change is the paired geometric timing ratio, not the ratio of displayed arithmetic means.', '',
         '| Scenario / table bytes | Forks each | Upstream ns / B | linkedMixed ns / B | Change [95% interval] |',
         '|---|---:|---:|---:|---:|']
for group in ('focus', 'small', 'rest', 'init', 'first'):
    for scenario, table in sorted({(sc, t) for g, sc, t, name in cells if g == group}):
        a = cells[group, scenario, table, 'linkedMixed']
        b = cells[group, scenario, table, 'upstream']
        rounds = sorted(a.keys() & b.keys())
        x = [math.log(a[r][0] / b[r][0]) for r in rounds]
        n = len(x)
        mu = s.mean(x)
        half = {3: 4.30265273, 6: 2.57058184}[n] * s.stdev(x) / math.sqrt(n)
        delta, lo, hi = [100 * math.expm1(v) for v in (mu, mu - half, mu + half)]
        values = [f'{s.mean(v[0] for v in c.values()):.2f} / {s.mean(v[1] for v in c.values()):.2f}'
                  for c in (b, a)]
        lines.append(f'| {scenario} / {table} | {n} | ' + ' | '.join(values) +
                     f' | {delta:+.2f}% [{lo:+.2f}, {hi:+.2f}] |')
(HERE / 'UPSTREAM.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
