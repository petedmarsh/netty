#!/usr/bin/env python3
"""Validate final comment-only delta and compiled provenance, without new timings."""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
ENC = Path('codec-http2/src/main/java/io/netty/handler/codec/http2/HpackEncoder.java')


def sha(data):
    return hashlib.sha256(data).hexdigest()


manifest = json.loads((HERE.parent.parent / 'ring/manifest.json').read_text())['variants']['linkedMixed']
measured = (Path('/tmp/netty-hpack-ring/linkedMixed') / ENC).read_bytes()
current = (ROOT / ENC).read_bytes()
assert sha(measured) == manifest['encoder_sha256']
old = (b'// Small arrays retain their original mapping. Once grown, the array keeps the mixed\n'
       b'        // mapping even if SETTINGS shrinks the table\'s byte limit.')
new = (b'// All allocated arrays use mixed hashing, including small arrays.\n'
       b'        // SETTINGS changes to the table\'s byte limit do not change this mapping.')
assert measured.count(old) == 1
assert current == measured.replace(old, new)
assert len(current.splitlines()) == len(measured.splitlines()) == 655
base = ROOT / 'codec-http2/target/classes'
classes = sorted(p for p in base.rglob('*.class') if p.name != 'module-info.class')
assert len(classes) == 276
jars = [Path(manifest['jar']),
        Path('/tmp/netty-hpack-distribution/artifacts/64-mixed/microbenchmarks.jar'),
        ROOT / 'microbench/target/microbenchmarks.jar']
assert sha(jars[0].read_bytes()) == manifest['jar_sha256']
checks = {}
for jar in jars:
    with zipfile.ZipFile(jar) as archive:
        for p in classes:
            assert archive.read(p.relative_to(base).as_posix()) == p.read_bytes(), (jar, p)
    checks[str(jar)] = {'sha256': sha(jar.read_bytes()), 'matching_codec_classes': len(classes)}
counts = {}
for name, expected in [('http2', 1643), ('paranoid-package', 125)]:
    suites = [ET.parse(p).getroot() for p in (HERE / (name + '-reports')).glob('TEST-*.xml')]
    if name == 'paranoid-package':
        suites = [s for s in suites if s.attrib['name'].split('.')[-1].startswith('Hpack')]
    counts[name] = {key: sum(int(s.attrib[key]) for s in suites)
                    for key in ['tests', 'failures', 'errors', 'skipped']}
    assert counts[name] == {'tests': expected, 'failures': 0, 'errors': 0,
                            'skipped': 5 if name == 'http2' else 0}
previous = json.loads((HERE.parent / 'before-sha256.json').read_text())
allowed = {'microbench/HPACK.md', 'microbench/results/hpack/RESULTS.md',
           'microbench/results/hpack/ring/README.md'}
for path, digest in previous.items():
    if path not in allowed:
        assert sha((ROOT / path).read_bytes()) == digest, path
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
result = {'measured_encoder_sha256': sha(measured), 'final_encoder_sha256': sha(current),
          'source_delta': 'Two comment lines only; 655 lines preserved',
          'jars': checks, 'tests': counts, 'preserved_historical_files': len(previous) - len(allowed),
          'timings_run': False,
          'validation': 'Homebrew OpenJDK21; full HTTP2 clean test, paranoid HPACK benchmark reactor package; no checks bypassed. Evidence temporarily parked outside checkout for NoHttp, restored in finally.'}
(HERE / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
