import pathlib,json,subprocess,time,sys,hashlib,datetime
O=pathlib.Path(__file__).resolve().parent
J='/opt/homebrew/opt/openjdk@21/bin/java'
S=['REPEATED','WORKING_SET','MIXED','CHURN','NAME_HIT','COLLISION','STATIC','SENSITIVE','HUFFMAN']
CASES=[('encode',s,4096) for s in S]+[('encode',s,256) for s in ['REPEATED','CHURN','NAME_HIT','COLLISION']]+[('encode',s,0) for s in ['REPEATED','CHURN']]+[('encoder','INIT',4096),('decode','HUFFMAN',4096)]
r=int(sys.argv[1]);assert 1<=r<=6
meta=json.loads((O/'environment.json').read_text())
for v in ['baseline','candidate']:
 assert hashlib.sha256((O/v/'bench.jar').read_bytes()).hexdigest()==meta['versions'][v]['jar_sha256']
for op,s,size in CASES:
 for v in (['baseline','candidate'] if r%2 else ['candidate','baseline']):
  stem=f'r{r}-{v}-{op}-{s}-{size}'; dest=O/(stem+'.json');assert not dest.exists()
  b='.*HpackInitializationBenchmark.encoder$' if s=='INIT' else '.*HpackStateBenchmark.'+op+'$'
  args=[J,'-jar',str(O/v/'bench.jar'),b,'-p','tableSize='+str(size)]
  if s!='INIT':args+=['-p','scenario='+s,'-p','growThenShrink=false']
  args+=['-f','1','-wi','5','-w','1s','-i','5','-r','1s','-t','1','-prof','gc','-foe','true','-jvmArgs','-Xms512m -Xmx512m','-rf','json','-rff',str(dest)]
  with (O/'commands.jsonl').open('a') as f:f.write(json.dumps({'case':stem,'start':time.time(),'argv':args})+'\n')
  with (O/(stem+'.log')).open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True,cwd=O,timeout=50)
  data=json.loads(dest.read_text());assert len(data)==1 and len(data[0]['primaryMetric']['rawData'])==1 and len(data[0]['primaryMetric']['rawData'][0])==5
  with (O/'completed.jsonl').open('a') as f:f.write(json.dumps({'case':stem,'end':time.time()})+'\n')
  print(stem,round(data[0]['primaryMetric']['score'],3),flush=True)
