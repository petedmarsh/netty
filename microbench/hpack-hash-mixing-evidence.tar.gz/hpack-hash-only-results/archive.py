import pathlib,hashlib,tarfile,gzip,io,shutil
O=pathlib.Path(__file__).resolve().parent
D=pathlib.Path('/tmp/netty-hpack-hash-mixing/microbench')
shutil.copyfile(D/'HPACK-HASH-MIXING.md',O/'HPACK-HASH-MIXING.md')
files=sorted(p for p in O.rglob('*') if p.is_file() and p.name!='SHA256SUMS' and p.suffix in ['.java','.class','.py','.md','.json','.jsonl','.log','.patch','.csv','.txt'])
(O/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(O))+'\n' for p in files))
files=sorted(files+[O/'SHA256SUMS'])
dest=D/'hpack-hash-mixing-evidence.tar.gz'
with dest.open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in files:
    data=p.read_bytes(); info=tarfile.TarInfo('hpack-hash-only-results/'+str(p.relative_to(O)));info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;tar.addfile(info,io.BytesIO(data))
assert dest.stat().st_size<10_000_000
with tarfile.open(dest) as t:
 for p in files:assert t.extractfile('hpack-hash-only-results/'+str(p.relative_to(O))).read()==p.read_bytes()
print(dest,dest.stat().st_size,hashlib.sha256(dest.read_bytes()).hexdigest())
