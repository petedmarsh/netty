import pathlib,subprocess,json,hashlib,zipfile,re,time
O=pathlib.Path(__file__).resolve().parent; meta=json.loads((O/'environment.json').read_text());out={}
for v,tree in [('baseline','/tmp/netty-hpack-hash-baseline'),('candidate','/tmp/netty-hpack-hash-mixing')]:
 t=pathlib.Path(tree);d=O/v
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip()=='014ef8d7031f9f1015020095421a659ced36cc8a'
 assert subprocess.check_output(['git','diff','--','codec-http2'],cwd=t)==(d/'codec.patch').read_bytes()
 assert hashlib.sha256((d/'bench.jar').read_bytes()).hexdigest()==meta['versions'][v]['jar_sha256']
 for p,h in meta['versions'][v]['source_sha256'].items():
  source=t/pathlib.Path(p).relative_to('source');assert hashlib.sha256(source.read_bytes()).hexdigest()==h
 z=zipfile.ZipFile(d/'bench.jar');n=0
 for p in (d/'classes').rglob('*.class'):
  name=str(pathlib.Path(*p.relative_to(d/'classes').parts[1:]));assert z.read(name)==p.read_bytes();n+=1
 log=(d/'build.log').read_text();assert 'BUILD SUCCESS' in log
 summaries=[l for l in log.splitlines() if 'Tests run:' in l and 'Failures:' in l]
 assert not any(re.search(r'Failures: [1-9]|Errors: [1-9]',l) for l in summaries)
 subprocess.run(['git','diff','--check'],cwd=t,check=True)
 (d/'status.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=t,text=True))
 out[v]={'classes_verified':n,'build_test_summaries':summaries}
for name in ['HpackStateBenchmark','HpackInitializationBenchmark']:
 p=pathlib.Path('microbench/src/main/java/io/netty/handler/codec/http2')/(name+'.java')
 a=pathlib.Path('/tmp/netty-hpack-hash-baseline')/p;b=pathlib.Path('/tmp/netty-hpack-hash-mixing')/p
 assert a.read_bytes()==b.read_bytes()==subprocess.check_output(['git','show','9e11b3c42c:'+str(p)],cwd='/Users/pmarsh/src/netty')
 (O/(name+'.patch')).write_text(subprocess.run(['git','diff','--no-index','--','/dev/null',str(b)],capture_output=True,text=True).stdout)
assert (O/'baseline/wire.csv').read_bytes()==(O/'candidate/wire.csv').read_bytes()
assert len((O/'baseline/wire.csv').read_text().splitlines())==36
assert len(list(O.glob('r*-*.json')))==204
# Explicit allowlisted source/probe/script scan; no environment dumps, caches or credential files collected.
pattern=re.compile(r'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|(?:AKIA|ASIA)[A-Z0-9]{16}|gh[pousr]_[A-Za-z0-9]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}')
scanned=0
for p in O.rglob('*'):
 if p.is_file() and p.suffix in ['.java','.py','.md','.json','.jsonl','.log','.patch','.csv','.txt']:
  assert not pattern.search(p.read_text(errors='replace')),str(p);scanned+=1
out.update(wire_comparisons=36,independent_forks=204,source_safety_scan={'files':scanned,'matches':0,'note':'Heuristic secret-pattern scan, not a guarantee; evidence uses explicit allowlist, no caches or environment dump.'},finished=time.time(),minutes_since_build_start=(time.time()-meta['start'])/60)
(O/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['baseline','candidate']},indent=2))
