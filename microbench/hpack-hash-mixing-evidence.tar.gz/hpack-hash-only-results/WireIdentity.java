package io.netty.handler.codec.http2;
import io.netty.buffer.ByteBuf;
import java.lang.reflect.Field;
import java.security.MessageDigest;
public final class WireIdentity {
 public static void main(String[] args) throws Exception {
  Field f=HpackStateBenchmark.class.getDeclaredField("wire"); f.setAccessible(true);
  for(int size:new int[]{0,256,4096}) for(HpackStateBenchmark.Scenario s:HpackStateBenchmark.Scenario.values()) {
   HpackStateBenchmark b=new HpackStateBenchmark(); b.tableSize=size;b.scenario=s;
   try { b.setup(); MessageDigest md=MessageDigest.getInstance("SHA-256"); long total=0;
    for(ByteBuf block:(ByteBuf[])f.get(b)) {int n=block.writerIndex(); total+=n;
     md.update(new byte[]{(byte)(n>>>24),(byte)(n>>>16),(byte)(n>>>8),(byte)n});
     for(int i=0;i<n;i++)md.update(block.getByte(i));
    }
    StringBuilder hex=new StringBuilder(); for(byte x:md.digest())hex.append(String.format("%02x",x&255));
    System.out.println(size+","+s+","+total+","+hex);
   } finally {b.tearDown();}
  }
 }
}
