import pathlib,json,statistics,math,time
O=pathlib.Path(__file__).resolve().parent
S=['REPEATED','WORKING_SET','MIXED','CHURN','NAME_HIT','COLLISION','STATIC','SENSITIVE','HUFFMAN']
CASES=[('encode',s,4096) for s in S]+[('encode',s,256) for s in ['REPEATED','CHURN','NAME_HIT','COLLISION']]+[('encode',s,0) for s in ['REPEATED','CHURN']]+[('encoder','INIT',4096),('decode','HUFFMAN',4096)]
def ci(x):
 m=statistics.mean(x); h=2.5705818356*statistics.stdev(x)/math.sqrt(len(x));return [m,m-h,m+h]
def fmt(x):return f'{x[0]:.2f} [{x[1]:.2f}, {x[2]:.2f}]'
rows=[]; results=[]
for op,s,size in CASES:
 vals={};alloc={}
 for v in ['baseline','candidate']:
  data=[json.loads((O/f'r{r}-{v}-{op}-{s}-{size}.json').read_text())[0] for r in range(1,7)]
  assert all(d['forks']==1 and d['warmupIterations']==5 and d['measurementIterations']==5 for d in data)
  vals[v]=[statistics.mean(d['primaryMetric']['rawData'][0]) for d in data]
  alloc[v]=[next(m['score'] for k,m in d['secondaryMetrics'].items() if k.endswith('gc.alloc.rate.norm')) for d in data]
 a,b=vals['baseline'],vals['candidate'];pct=ci([100*(y/x-1) for x,y in zip(a,b)])
 res=dict(operation=op,scenario=s,capacity=size,fork_ns=vals,fork_alloc=alloc,baseline_ci=ci(a),candidate_ci=ci(b),paired_delta_ns_ci=ci([y-x for x,y in zip(a,b)]),paired_percent_ci=pct,allocation_ci={v:ci(x) for v,x in alloc.items()});results.append(res)
 rows.append(f'| {op}/{s}/{size} | {fmt(ci(a))} | {fmt(ci(b))} | {fmt(pct)} | {statistics.mean(alloc["baseline"]):.2f} → {statistics.mean(alloc["candidate"]):.2f} |')
(O/'fork-confidence.json').write_text(json.dumps(results,indent=2)+'\n')
meta=json.loads((O/'environment.json').read_text()); completed=[json.loads(l) for l in (O/'completed.jsonl').read_text().splitlines()];assert len(completed)==204
text='''# HPACK hash-mixing-only: fresh HEAD comparison

## Outcome

The isolated mixer substantially reduces time in four synthetic dynamic-table workloads at 4096 bytes: WORKING_SET, MIXED, CHURN and NAME_HIT. It does **not** establish a general HPACK speedup. Full-hash COLLISION is not fixed by bucket mixing. Other cases, including repeated hits, small-table workloads, initialization and unchanged decoder, have weaker or inconclusive evidence. No 64 KiB support is added: the upstream capacity cap and backing structures are unchanged.

## Isolation and verification

- Baseline and candidate HEAD: `014ef8d7031f9f1015020095421a659ced36cc8a` (freshly fetched snapshot supplied for this task; no newer upstream claim).
- Candidate branch: `perf/hpack-hash-mixing`. The uncommitted production patch changes only `HpackEncoder.bucket(int)`: xor-shift, multiply by `0x85ebca6b`, xor-shift and existing mask. The existing focused encoder tests are retained. No other codec changes imported or production edits made during this campaign.
- Identical `HpackStateBenchmark.java` / `HpackInitializationBenchmark.java` copied from root commit `9e11b3c42c`; defaults remain 0/256/4096. Root checkout left untouched. No commits, pushes or PRs.
- Fresh sequential `clean package` reactor builds, Homebrew OpenJDK 21.0.12, macOS arm64. Explicit Maven 3.9.11 and writable `/tmp/hpack-maven-repository`; `benchmark-jar,!mac` excludes irrelevant native kqueue packaging. HPACK tests run during both builds; neither build installs shared SNAPSHOT artifacts.
- 1461 codec-http2/microbench compiled classes per jar byte-compared with fresh target outputs (module descriptors deliberately excluded). Sources, compiled classes, patches, build commands/logs and SHA-256 provenance retained in raw evidence.
- Byte-identity assertion passed: length-delimited SHA-256 of all 2048 captured blocks for every one of 12 scenarios at each of 0/256/4096 (36 comparisons). Setup validates decoded fields, third-cycle periodicity and two captured-wire replay cycles. No grow/shrink or unsupported 65536 runs.

## Method and results

Exactly 17 cases × 6 matched fork pairs = **204 new JVM forks**, 1020 measured iterations. Per-case rounds alternate AB/BA, giving three ABBA blocks; A is baseline. One thread, each fork five 1-second warmups and five 1-second measurements, `-prof gc`, `-Xms512m -Xmx512m`, fail-on-error. Prior benchmark data were not reused.

One encode operation is a four-field header block. Initialization is one encoder construction/configuration. Decode is the unchanged HUFFMAN control. Each fork's five measurements are averaged first. Brackets below are **95% Student-t confidence intervals across six independent fork means** (df=5); percent change uses six paired per-round percentages, negative means faster. Percentages are not ratios of pooled means. No correction for 17 comparisons; intervals do not capture systematic machine bias. Allocation column is mean normalized B/op; per-fork values and allocation confidence intervals are in `fork-confidence.json`.

| Case / table bytes | HEAD ns/op [95% CI] | Mixer ns/op [95% CI] | Paired change % [95% CI] | HEAD → mixer B/op |
|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

## Interpretation and caveats

The four strongest 4096-byte improvements are much larger and more consistent than the controls' variability. These are deterministic synthetic name/value distributions, not sampled production traffic. WORKING_SET uses 512 identifiers; MIXED retains that fixture. NAME_HIT reuses names while values change. Hash mixing redistributes different full hashes; it cannot separate equal full hashes. The selected collision fixture explicitly checks equal full ASCII hashes.

Small effects are not reliable on this unpinned, non-dedicated macOS host. The unchanged decoder has large between-fork variability, and some encoder cases show distinct fast/slow fork clusters; do not infer a decoder benefit from this source change or hide these samples as outliers. CPU frequency, scheduling, thermals and JIT shape were not controlled. Five-second warmup is bounded, not proof of convergence. No real-traffic, multi-connection, cold-cache or HTTP/2 frame integration claims. Allocation varies discretely between forks in some cases: REPEATED/4096 averages 32 → 16 B/op, COLLISION/4096 160 → 168, and the unchanged table-zero REPEATED control 4 → approximately 0. These are genuine measured fork differences, not merely rounding noise, but the mixer changes no allocation sites. Different JIT escape-analysis outcomes are a plausible, unproven explanation; no compiler diagnostic campaign was run. Do not claim an allocation optimization from these averages. The four strong 4096-byte dynamic workloads retain equal allocations, and initialization remains 744 B/op.

## Evidence and reproduction

Raw evidence: `/tmp/hpack-hash-only-results`. `prepare.py`, `run.py`, `analyze.py`, `verify.py`, `PLAN.md`, exact command manifests, all 204 JSON/log pairs, both fresh jar hashes, source snapshots/patches, preserved compiled classes, wire probe and fork CIs are retained. Re-run `python3 run.py N` for N=1..6 only in a fresh results directory; runner refuses overwrites. Builds and forks must remain sequential.

The deterministic companion `hpack-hash-mixing-evidence.tar.gz` excludes large shaded jars (available in raw evidence), caches and credentials; includes measured codec/benchmark classes and all benchmark evidence. `SHA256SUMS` covers archived files. Source safety scan and final source/patch preservation assertions are recorded in `verification.json`. Supporting benchmark/doc/evidence files remain uncommitted; maintainers can decide whether to include them with the focused hash-mixing/test change or separately.

### Fresh jar SHA-256

'''
for v in ['baseline','candidate']:text+=f'- {v}: `{meta["versions"][v]["jar_sha256"]}`\n'
text+=f'\nBuild-start to final measurement: {(max(c["end"] for c in completed)-meta["start"])/60:.1f} minutes.\n'
pathlib.Path('/tmp/netty-hpack-hash-mixing/microbench/HPACK-HASH-MIXING.md').write_text(text)
print('\n'.join(rows))
