import pathlib,subprocess,os,hashlib,json,shutil,zipfile,time
O=pathlib.Path('/tmp/hpack-hash-only-results'); O.mkdir(exist_ok=False)
R=pathlib.Path('/Users/pmarsh/src/netty'); J='/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home'; M='/Users/pmarsh/.m2/wrapper/dists/apache-maven-3.9.11-bin/29aa128b/apache-maven-3.9.11/bin/mvn'
env=os.environ.copy(); env['JAVA_HOME']=J; env['PATH']=J+'/bin:'+env['PATH']
for k in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS']: assert not env.get(k),k
meta={'start':time.time(),'jdk':subprocess.run([J+'/bin/java','-version'],capture_output=True,text=True).stderr,'host':subprocess.check_output(['uname','-a'],text=True),'versions':{}}
for v,tree in [('baseline','/tmp/netty-hpack-hash-baseline'),('candidate','/tmp/netty-hpack-hash-mixing')]:
 t=pathlib.Path(tree); d=O/v; d.mkdir()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip()=='014ef8d7031f9f1015020095421a659ced36cc8a'
 for name in ['HpackStateBenchmark','HpackInitializationBenchmark']:
  p=pathlib.Path('microbench/src/main/java/io/netty/handler/codec/http2')/(name+'.java'); shutil.copyfile(R/p,t/p)
 patch=subprocess.check_output(['git','diff','--','codec-http2'],cwd=t); (d/'codec.patch').write_bytes(patch)
 args=[M,'-Dmaven.repo.local=/tmp/hpack-maven-repository','-pl','microbench','-am','-Pbenchmark-jar,!mac','-Dtest=Hpack*Test','-Dsurefire.failIfNoSpecifiedTests=false','clean','package']
 (d/'build-command.json').write_text(json.dumps(args))
 with (d/'build.log').open('w') as f: subprocess.run(args,cwd=t,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copyfile(t/'microbench/target/microbenchmarks.jar',d/'bench.jar')
 hashes={}; z=zipfile.ZipFile(d/'bench.jar'); n=0
 for module in ['codec-http2','microbench']:
  for p in (t/module/'target/classes').rglob('*.class'):
   rel=p.relative_to(t/module/'target/classes')
   if p.name=='module-info.class':continue
   assert z.read(str(rel))==p.read_bytes(),str(rel)
   dest=d/'classes'/module/rel; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dest); n+=1
  for p in (t/module/'src').rglob('*.java'):
   if module=='microbench' and p.name not in ['HpackStateBenchmark.java','HpackInitializationBenchmark.java']:continue
   dest=d/'source'/p.relative_to(t);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 for p in (d/'source').rglob('*.java'):hashes[str(p.relative_to(d))]=hashlib.sha256(p.read_bytes()).hexdigest()
 meta['versions'][v]={'jar_sha256':hashlib.sha256((d/'bench.jar').read_bytes()).hexdigest(),'source_sha256':hashes,'classes_checked':n}
 (O/'environment.json').write_text(json.dumps(meta,indent=2))
 print(v,'built',n,flush=True)
shutil.copyfile(__file__,O/'prepare.py')
